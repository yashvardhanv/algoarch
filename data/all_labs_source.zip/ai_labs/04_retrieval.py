"""Lab 04 — Retrieval: hybrid, fusion, reranking, query transformation.

Lesson 02 showed dense retrieval confidently returning the wrong document for an
exact identifier. Lesson 03 showed chunking moving recall 17 points. This lab
fixes the retrieval half properly and measures every step.

THE LADDER (each rung is measured, in order):

    1. dense only          bi-encoder cosine — the Lesson 01 baseline
    2. BM25 only           sparse lexical
    3. hybrid via RRF      fuse the two RANKED LISTS
    4. + cross-encoder     rerank the fused top-N
    5. + MMR               diversify so top-k isn't 4 copies of one fact
    6. + HyDE              transform the query itself (uses claude-shim)

METRIC DISCIPLINE CARRIED FORWARD FROM LESSON 03:
  * recall is reported at a FIXED CONTEXT BUDGET, not a fixed k, because k-based
    recall silently rewards configurations that retrieve more text
  * the gold set is 30 questions, not 12, because Lesson 03's 12-question set
    made every difference under 0.17 indistinguishable from noise

    python 04_retrieval.py ladder      # the whole ladder, measured  ← START HERE
    python 04_retrieval.py why         # per-query: who wins what, and why
    python 04_retrieval.py rrf         # how Reciprocal Rank Fusion actually works
    python 04_retrieval.py ann         # exact vs approximate: the silent tax
    python 04_retrieval.py hyde        # query transformation (uses claude-shim)
"""

from __future__ import annotations

import argparse
import pathlib
import re
import statistics
import sys
import time

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
CORPUS = HERE.parent.parent / "ai-engineer-roadmap.md"
BUDGET = 4000

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")


def rule(s: str) -> None:
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


# --------------------------------------------------------------------------- #
# GOLD SET — 30 questions, tagged by the retrieval skill they exercise.
#   ident  : rare exact token (BM25 territory)
#   para   : paraphrase, no lexical overlap (dense territory)
#   multi  : answer needs two ideas
#   plain  : ordinary lookup
# --------------------------------------------------------------------------- #

GOLD = [
    # --- identifier / rare-token queries: BM25 should dominate --------------
    ("HNSW", "ident", "HNSW vs. IVFFlat"),
    ("IVFFlat", "ident", "HNSW vs. IVFFlat"),
    ("What is RRF?", "ident", "Reciprocal Rank Fusion"),
    ("pgvector", "ident", "pgvector"),
    ("Cohen's kappa", "ident", "Cohen's kappa"),
    ("ColPali", "ident", "ColPali"),
    ("Garak", "ident", "Garak"),
    ("Temporal", "ident", "Temporal"),
    ("What is HyDE?", "ident", "HyDE"),
    ("ef_search", "ident", "ef_search"),
    ("QLoRA", "ident", "LoRA, QLoRA"),
    ("What does RAGAS measure?", "ident", "RAGAS"),
    # --- paraphrase: dense should dominate ---------------------------------
    ("How do I keep my agent from running in circles forever?", "para", "loop detection"),
    ("What stops a runaway bill from an automated attacker?", "para", "Denial-of-wallet"),
    ("How do I know if my grader is trustworthy?", "para", "uncalibrated judge"),
    ("What should I do when the model makes things up confidently?", "para", "hallucinate confidently"),
    ("How do I make the system admit it doesn't know?", "para", "escape hatch"),
    ("Why is my long prompt getting worse answers?", "para", "Lost in the middle"),
    ("What's the cheapest way to cut spend on a chat product?", "para", "Prompt caching"),
    ("How do I stop one bad tool result ruining the whole run?", "para", "error cascades"),
    ("Who should not be allowed to see which documents?", "para", "pre-filter by permissions"),
    ("How do I make a small model do a big model's job?", "para", "Distillation"),
    # --- multi-hop / conceptual --------------------------------------------
    ("What single change most improves a mediocre retrieval system?", "multi", "highest-ROI single upgrade"),
    ("Why can't I just use a longer context instead of retrieval?", "multi", "Long-context vs. RAG"),
    ("When should I not build an agent?", "multi", "not** to use an agent"),
    ("What breaks first when I scale my vector index?", "multi", "silent quality tax"),
    # --- plain lookup -------------------------------------------------------
    ("How big should my golden dataset be?", "plain", "50–200 examples"),
    ("What order should I try things before fine-tuning?", "plain", "then* fine-tune"),
    ("How do I handle tables in documents?", "plain", "serialize tables to markdown"),
    ("What is contextual retrieval?", "plain", "LLM-generated summary of the parent document"),
]


def check_gold(text: str) -> None:
    """Fail loudly if a gold answer isn't in the corpus verbatim.

    A gold set that silently references text which does not exist scores every
    system at zero on that question and looks like a retrieval failure. Validate
    the eval before you trust the eval.
    """
    missing = [(q, a) for q, _, a in GOLD if a not in text]
    if missing:
        print(f"{RED}GOLD SET BROKEN — {len(missing)} answer(s) not found verbatim:{RESET}")
        for q, a in missing:
            print(f"  {q!r} -> {a!r}")
        sys.exit(1)


# --------------------------------------------------------------------------- #
# Chunking — use Lesson 03's winner
# --------------------------------------------------------------------------- #

SEPS = ["\n## ", "\n### ", "\n\n", "\n", ". ", " "]


def chunk_recursive(text: str, size: int = 900) -> list[dict]:
    def _split(s, depth):
        if len(s) <= size or depth >= len(SEPS):
            return [s]
        sep = SEPS[depth]
        parts = [(sep if i else "") + p for i, p in enumerate(s.split(sep))]
        out, buf = [], ""
        for p in parts:
            if buf and len(buf) + len(p) > size:
                out.extend(_split(buf, depth + 1) if len(buf) > size else [buf])
                buf = p
            else:
                buf += p
        if buf:
            out.extend(_split(buf, depth + 1) if len(buf) > size else [buf])
        return out

    res, pos = [], 0
    for piece in _split(text, 0):
        if piece.strip():
            start = text.find(piece, max(0, pos - 60))
            res.append({"text": piece, "start": start if start >= 0 else pos})
            pos += len(piece)
    return res


# --------------------------------------------------------------------------- #
# Retrievers
# --------------------------------------------------------------------------- #

_bi = _ce = None


def bi_encoder():
    global _bi
    if _bi is None:
        from sentence_transformers import SentenceTransformer
        _bi = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    return _bi


def cross_encoder():
    """A cross-encoder scores (query, passage) TOGETHER — see Lesson 02 §7.

    ms-marco-MiniLM-L-6-v2 is ~80 MB, runs on CPU, and is trained exactly for
    "does this passage answer this query". It cannot precompute anything, which
    is why it only ever runs over a shortlist.
    """
    global _ce
    if _ce is None:
        from sentence_transformers import CrossEncoder
        _ce = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2", max_length=512)
    return _ce


def embed(texts: list[str]) -> np.ndarray:
    return bi_encoder().encode(texts, batch_size=64, convert_to_numpy=True,
                               normalize_embeddings=True).astype(np.float32)


def tok(s: str) -> list[str]:
    return [w for w in re.split(r"[^A-Za-z0-9_]+", s.lower()) if w]


class Index:
    def __init__(self, chunks: list[dict]):
        from rank_bm25 import BM25Okapi
        self.chunks = chunks
        self.texts = [c["text"] for c in chunks]
        self.vecs = embed(self.texts)
        self.bm25 = BM25Okapi([tok(t) for t in self.texts])

    def dense(self, q: str) -> np.ndarray:
        return self.vecs @ embed([q])[0]

    def sparse(self, q: str) -> np.ndarray:
        return np.asarray(self.bm25.get_scores(tok(q)), dtype=float)


def rrf(rankings: list[list[int]], k: int = 60) -> list[int]:
    """Reciprocal Rank Fusion.

        score(d) = Σ over lists  1 / (k + rank_in_that_list(d))

    Why this and not "average the two scores": BM25 returns unbounded positive
    numbers whose scale depends on corpus statistics; cosine returns [-1, 1].
    They are not on a common scale and never will be, so any weighted sum needs
    per-corpus tuning that silently rots.

    RRF throws the scores away and keeps only RANK, which is comparable by
    construction. k=60 is the constant from the original paper; it damps the
    influence of the very top ranks so one list cannot dominate. It needs no
    tuning, which is the entire point.
    """
    scores: dict[int, float] = {}
    for ranking in rankings:
        for rank, doc in enumerate(ranking, start=1):
            scores[doc] = scores.get(doc, 0.0) + 1.0 / (k + rank)
    return [d for d, _ in sorted(scores.items(), key=lambda kv: -kv[1])]


def mmr(order: list[int], vecs: np.ndarray, qv: np.ndarray,
        k: int, lam: float = 0.7) -> list[int]:
    """Maximal Marginal Relevance — pick the next doc that is relevant AND
    different from what you already picked.

        MMR = λ · sim(d, query) − (1−λ) · max sim(d, already_selected)

    Fixes the failure Lesson 01's `inspect` showed: near-duplicate chunks eating
    your whole top-k, so you retrieve the same fact four times and waste the
    budget you could have spent on the second half of the answer.
    """
    cand = list(order[: min(len(order), 50)])
    sel: list[int] = []
    while cand and len(sel) < k:
        best, best_score = None, -1e9
        for d in cand:
            rel = float(vecs[d] @ qv)
            div = max((float(vecs[d] @ vecs[s]) for s in sel), default=0.0)
            s = lam * rel - (1 - lam) * div
            if s > best_score:
                best, best_score = d, s
        sel.append(best)
        cand.remove(best)
    return sel + [d for d in order if d not in sel]


# --------------------------------------------------------------------------- #
# Pipelines — each returns a ranked list of chunk indices
# --------------------------------------------------------------------------- #

def p_dense(idx: Index, q: str) -> list[int]:
    return list(np.argsort(-idx.dense(q)))


def p_bm25(idx: Index, q: str) -> list[int]:
    return list(np.argsort(-idx.sparse(q)))


def p_hybrid(idx: Index, q: str) -> list[int]:
    d = list(np.argsort(-idx.dense(q)))[:100]
    s = list(np.argsort(-idx.sparse(q)))[:100]
    fused = rrf([[int(x) for x in d], [int(x) for x in s]])
    return fused + [i for i in range(len(idx.chunks)) if i not in set(fused)]


def p_hybrid_rerank(idx: Index, q: str, n: int = 30) -> list[int]:
    """Retrieve wide (hybrid top-30), rerank narrow (cross-encoder)."""
    cand = p_hybrid(idx, q)[:n]
    scores = cross_encoder().predict([(q, idx.texts[i]) for i in cand])
    ranked = [c for _, c in sorted(zip(scores, cand), key=lambda t: -t[0])]
    return ranked + [i for i in range(len(idx.chunks)) if i not in set(ranked)]


def p_hybrid_rerank_mmr(idx: Index, q: str) -> list[int]:
    order = p_hybrid_rerank(idx, q, n=30)
    return mmr(order, idx.vecs, embed([q])[0], k=8, lam=0.7)


PIPELINES = {
    "dense":          ("1. dense only        ←L01", p_dense),
    "bm25":           ("2. BM25 only", p_bm25),
    "hybrid":         ("3. hybrid (RRF)", p_hybrid),
    "hybrid+rerank":  ("4. hybrid + rerank", p_hybrid_rerank),
    "hybrid+rr+mmr":  ("5. hybrid + rerank + MMR", p_hybrid_rerank_mmr),
}


# --------------------------------------------------------------------------- #
# Evaluation — fixed context budget (Lesson 03 §5)
# --------------------------------------------------------------------------- #

def eval_pipeline(idx: Index, fn, budget: int = BUDGET) -> dict:
    hits, rr, lat, per_tag = 0, [], [], {}
    per_q = []
    for q, tag, ans in GOLD:
        t0 = time.perf_counter()
        order = fn(idx, q)
        lat.append((time.perf_counter() - t0) * 1000)

        spent, found, rank_found = 0, False, None
        for r, ci in enumerate(order, 1):
            t = idx.texts[int(ci)]
            if spent + len(t) > budget:
                break
            spent += len(t)
            if ans in t:
                found, rank_found = True, r
                break
        hits += found
        rr.append(1.0 / rank_found if rank_found else 0.0)
        per_tag.setdefault(tag, [0, 0])
        per_tag[tag][1] += 1
        per_tag[tag][0] += found
        per_q.append({"q": q, "tag": tag, "found": found, "rank": rank_found})

    return {
        "recall": hits / len(GOLD),
        "mrr": statistics.mean(rr),
        "p50_ms": statistics.median(lat),
        "by_tag": {t: v[0] / v[1] for t, v in per_tag.items()},
        "per_q": per_q,
    }


def cmd_ladder(_a) -> None:
    text = CORPUS.read_text(encoding="utf-8")
    check_gold(text)
    chunks = chunk_recursive(text)
    idx = Index(chunks)

    rule("THE RETRIEVAL LADDER")
    print(f"{DIM}corpus {CORPUS.name} · {len(chunks)} chunks (recursive 900, Lesson 03's winner)")
    print(f"{len(GOLD)} gold questions · recall at a fixed {BUDGET}-char context budget")
    print(f"one question = {100/len(GOLD):.1f} points{RESET}\n")

    print(f"{'pipeline':<28} {'recall':>7} {'MRR':>7} {'p50 ms':>8}   "
          f"{'ident':>6} {'para':>6} {'multi':>6} {'plain':>6}")
    print(f"{DIM}{'-'*28} {'-'*7} {'-'*7} {'-'*8}   {'-'*6} {'-'*6} {'-'*6} {'-'*6}{RESET}")

    results = {}
    base = None
    for key, (label, fn) in PIPELINES.items():
        m = eval_pipeline(idx, fn)
        results[key] = m
        if base is None:
            base = m["recall"]
        col = GREEN if m["recall"] >= 0.8 else (YELLOW if m["recall"] >= 0.6 else RED)
        bt = m["by_tag"]
        print(f"{label:<28} {col}{m['recall']:>7.2f}{RESET} {m['mrr']:>7.3f} {m['p50_ms']:>8.1f}   "
              f"{bt.get('ident',0):>6.2f} {bt.get('para',0):>6.2f} "
              f"{bt.get('multi',0):>6.2f} {bt.get('plain',0):>6.2f}")

    d, b = results["dense"], results["hybrid"]
    rr_ = results["hybrid+rerank"]
    print(f"""
{BOLD}What moved{RESET}
  dense → hybrid   : {b['recall']-d['recall']:+.2f} recall, {b['mrr']-d['mrr']:+.3f} MRR
  hybrid → +rerank : {rr_['recall']-b['recall']:+.2f} recall, {rr_['mrr']-b['mrr']:+.3f} MRR
  dense → +rerank  : {GREEN}{rr_['recall']-d['recall']:+.2f} recall, {rr_['mrr']-d['mrr']:+.3f} MRR{RESET}
  latency cost     : {d['p50_ms']:.0f} ms → {rr_['p50_ms']:.0f} ms per query

{DIM}Read the per-tag columns, not just the total. They show WHY each rung helps:
'ident' questions are rare exact tokens where BM25 is strong and dense is weak;
'para' questions share no words with their answer, where BM25 is helpless.
A single number hides that the two retrievers fail on disjoint query sets —
which is the entire argument for fusing them rather than choosing.{RESET}""")


def cmd_why(_a) -> None:
    """Per-query win/loss. The table that tells you what to fix next."""
    text = CORPUS.read_text(encoding="utf-8")
    check_gold(text)
    idx = Index(chunk_recursive(text))
    rule("PER-QUERY: WHO WINS WHAT")

    ms = {k: eval_pipeline(idx, fn) for k, (_, fn) in PIPELINES.items()}
    keys = ["dense", "bm25", "hybrid", "hybrid+rerank"]
    print(f"{'tag':<6} {'question':<52} " + " ".join(f"{k[:6]:>7}" for k in keys))
    print(f"{DIM}{'-'*6} {'-'*52} " + " ".join("-" * 7 for _ in keys) + RESET)

    for i, (q, tag, _ans) in enumerate(GOLD):
        cells = []
        for k in keys:
            r = ms[k]["per_q"][i]
            cells.append(f"{GREEN}{'✓' + str(r['rank']):>7}{RESET}" if r["found"]
                         else f"{RED}{'✗':>7}{RESET}")
        print(f"{tag:<6} {q[:52]:<52} " + " ".join(cells))

    fixed = [GOLD[i][0] for i in range(len(GOLD))
             if not ms["dense"]["per_q"][i]["found"] and ms["hybrid+rerank"]["per_q"][i]["found"]]
    broke = [GOLD[i][0] for i in range(len(GOLD))
             if ms["dense"]["per_q"][i]["found"] and not ms["hybrid+rerank"]["per_q"][i]["found"]]
    print(f"\n{GREEN}FIXED by hybrid+rerank ({len(fixed)}){RESET}")
    for q in fixed:
        print(f"  + {q}")
    print(f"\n{RED}BROKEN by hybrid+rerank ({len(broke)}){RESET}")
    for q in broke:
        print(f"  - {q}")
    if not broke:
        print(f"  {DIM}(none){RESET}")
    print(f"""
{DIM}Always print this table, not just the aggregate. An upgrade that fixes 6 queries
and breaks 2 has a net +4 that looks like clean progress in a bar chart — and the
2 it broke may be the ones your most important user runs every morning.{RESET}""")


def cmd_rrf(_a) -> None:
    text = CORPUS.read_text(encoding="utf-8")
    check_gold(text)
    idx = Index(chunk_recursive(text))
    rule("HOW RECIPROCAL RANK FUSION ACTUALLY WORKS")

    q = "What is RRF?"
    d = [int(x) for x in np.argsort(-idx.dense(q))[:8]]
    s = [int(x) for x in np.argsort(-idx.sparse(q))[:8]]
    dsc, ssc = idx.dense(q), idx.sparse(q)

    print(f"query: {q!r}\n")
    print(f"{DIM}Note the score scales — this is why you cannot simply add them:{RESET}")
    print(f"  dense (cosine)  range [{dsc.min():.3f}, {dsc.max():.3f}]")
    print(f"  BM25            range [{ssc.min():.3f}, {ssc.max():.3f}]  {DIM}← unbounded, "
          f"corpus-dependent{RESET}\n")

    fused = rrf([d, s])[:8]
    print(f"{'rank':>4}  {'dense':>6} {'bm25':>6}   {'RRF contribution':<34} chunk")
    print(f"{DIM}{'-'*4}  {'-'*6} {'-'*6}   {'-'*34} {'-'*20}{RESET}")
    for r, c in enumerate(fused, 1):
        dr = d.index(c) + 1 if c in d else None
        sr = s.index(c) + 1 if c in s else None
        contrib = []
        if dr:
            contrib.append(f"1/(60+{dr})={1/(60+dr):.4f}")
        if sr:
            contrib.append(f"1/(60+{sr})={1/(60+sr):.4f}")
        total = sum(1 / (60 + x) for x in (dr, sr) if x)
        head = " ".join(idx.texts[c].split())[:34]
        print(f"{r:>4}  {str(dr or '-'):>6} {str(sr or '-'):>6}   "
              f"{' + '.join(contrib):<34} {DIM}{head}{RESET}")
        _ = total

    print(f"""
{DIM}Three properties worth stating out loud:

1. NO TUNING. There is no weight to set, because scores are discarded and only
   ranks are used. A weighted score-sum needs per-corpus calibration that rots
   the moment the corpus changes.
2. AGREEMENT WINS. A chunk ranked well by BOTH retrievers accumulates two
   contributions and rises above one that only one retriever liked.
3. k=60 DAMPS THE TOP. With k=60, rank 1 scores 1/61 and rank 2 scores 1/62 —
   nearly equal. So a single retriever being very confident cannot steamroll the
   other. Lower k makes the fusion more winner-take-all.{RESET}""")


def cmd_ann(_a) -> None:
    """Exact vs approximate nearest neighbour — the silent quality tax."""
    from sklearn.cluster import KMeans
    text = CORPUS.read_text(encoding="utf-8")
    check_gold(text)
    idx = Index(chunk_recursive(text))
    rule("EXACT vs APPROXIMATE — the silent quality tax")

    V, n = idx.vecs, len(idx.chunks)
    nlist = max(4, int(np.sqrt(n)))
    km = KMeans(n_clusters=nlist, n_init=10, random_state=0).fit(V)
    print(f"{DIM}IVF-style index: {n} vectors partitioned into {nlist} lists by k-means.")
    print(f"A query is compared only against vectors in the `nprobe` nearest lists.")
    print(f"nprobe = {nlist} is exhaustive, i.e. exact. Lower nprobe = faster and lossier.{RESET}\n")

    Q = embed([q for q, _, _ in GOLD])
    exact = [set(np.argsort(-(V @ Q[i]))[:10].tolist()) for i in range(len(GOLD))]

    print(f"{'nprobe':>7} {'vectors scanned':>16} {'speedup':>8} {'recall@10 vs exact':>20}")
    print(f"{DIM}{'-'*7} {'-'*16} {'-'*8} {'-'*20}{RESET}")
    for nprobe in sorted({1, 2, 3, max(1, nlist // 2), nlist}):
        hits, scanned = 0, 0
        for i in range(len(GOLD)):
            dists = np.linalg.norm(km.cluster_centers_ - Q[i], axis=1)
            lists = np.argsort(dists)[:nprobe]
            mask = np.isin(km.labels_, lists)
            cand = np.where(mask)[0]
            scanned += len(cand)
            sub = cand[np.argsort(-(V[cand] @ Q[i]))[:10]]
            hits += len(set(sub.tolist()) & exact[i])
        rec = hits / (10 * len(GOLD))
        avg = scanned / len(GOLD)
        col = GREEN if rec >= .95 else (YELLOW if rec >= .8 else RED)
        print(f"{nprobe:>7} {avg:>16.0f} {n/max(1,avg):>7.1f}× {col}{rec:>19.0%}{RESET}")

    print(f"""
{DIM}Nothing errors. No exception, no warning, no log line. Recall just quietly
drops and your answers get slightly worse in a way that looks like "the model
isn't very good today".

That is what "ANN recall loss is a silent quality tax" means, and it is why the
knobs matter: `nprobe` for IVFFlat, `ef_search` for HNSW. At {n} vectors you have
no speed problem, so exact search is STRICTLY better here — you would be paying
the tax for nothing. Turn ANN on when brute force stops fitting your latency
budget, and measure the recall you gave up when you do.{RESET}""")


def cmd_hyde(_a) -> None:
    """Query transformation via HyDE — attack the question↔passage asymmetry."""
    import aiconfig
    text = CORPUS.read_text(encoding="utf-8")
    check_gold(text)
    idx = Index(chunk_recursive(text))
    rule("HyDE — HYPOTHETICAL DOCUMENT EMBEDDINGS")
    print(f"""{DIM}Lesson 02 measured the problem: a question and its answer share no words and
embed only 0.287 apart. HyDE's move is strange and effective — ask the model to
HALLUCINATE an answer, throw away its content, and search using its EMBEDDING.
A fake answer is answer-shaped, so it lands nearer real answers than the
question ever could. The hallucination is not a bug here; it is the mechanism.{RESET}""")

    client = aiconfig.client()
    # Only the paraphrase-style questions — HyDE targets that failure mode.
    subset = [(q, t, a) for q, t, a in GOLD if t in ("para", "multi")]

    print(f"\n{DIM}generating {len(subset)} hypothetical answers via claude-shim …{RESET}")
    t0 = time.perf_counter()
    hyde_docs = []
    for q, _, _ in subset:
        r = client.chat.completions.create(
            model=aiconfig.MODEL,
            messages=[{"role": "system", "content":
                       "Write a short factual passage (2-3 sentences) that would answer the "
                       "user's question, in the style of a technical handbook. Do not hedge, "
                       "do not say you are unsure, do not mention that this is hypothetical."},
                      {"role": "user", "content": q}],
        )
        hyde_docs.append(r.choices[0].message.content.strip())
    gen_s = time.perf_counter() - t0
    print(f"{DIM}{gen_s:.1f}s total, {gen_s/len(subset):.1f}s per query "
          f"— note this is ON THE CRITICAL PATH of every search{RESET}")

    def score(use_hyde: bool) -> tuple[float, float]:
        hits, rr = 0, []
        for i, (q, _, ans) in enumerate(subset):
            qtext = hyde_docs[i] if use_hyde else q
            d = list(np.argsort(-(idx.vecs @ embed([qtext])[0])))
            spent, rank = 0, None
            for r, ci in enumerate(d, 1):
                t = idx.texts[int(ci)]
                if spent + len(t) > BUDGET:
                    break
                spent += len(t)
                if ans in t:
                    rank = r
                    break
            hits += rank is not None
            rr.append(1 / rank if rank else 0.0)
        return hits / len(subset), statistics.mean(rr)

    b_r, b_m = score(False)
    h_r, h_m = score(True)
    print(f"\n  {'variant':<34} {'recall':>7} {'MRR':>7}")
    print(f"  {DIM}{'-'*34} {'-'*7} {'-'*7}{RESET}")
    print(f"  {'dense, raw question':<34} {b_r:>7.2f} {b_m:>7.3f}")
    col = GREEN if h_r > b_r else (RED if h_r < b_r else DIM)
    print(f"  {'dense, HyDE hypothetical answer':<34} {col}{h_r:>7.2f}{RESET} {h_m:>7.3f}")
    print(f"  {col}{'delta':<34} {h_r-b_r:>+7.2f} {h_m-b_m:>+7.3f}{RESET}")

    print(f"\n{DIM}example — {subset[0][0]!r}")
    print(f"hypothetical: {hyde_docs[0][:220]}…{RESET}")
    print(f"""
{DIM}Cost/benefit, stated honestly: HyDE adds a full LLM call BEFORE retrieval can
start, on every query. At {gen_s/len(subset):.1f}s that is often more latency than the answer
generation itself. It is worth it when your corpus is jargon-heavy and your users
ask conversational questions; it is a bad trade for keyword-style queries, and it
cannot be cached across users the way a static prompt prefix can.

Cheaper alternatives that attack the same asymmetry: query rewriting with a small
model, or simply appending the conversation's last assistant turn to the query.{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for c in ("ladder", "why", "rrf", "ann", "hyde"):
        sub.add_parser(c)
    a = p.parse_args()
    {"ladder": cmd_ladder, "why": cmd_why, "rrf": cmd_rrf,
     "ann": cmd_ann, "hyde": cmd_hyde}[a.cmd](a)


if __name__ == "__main__":
    main()
