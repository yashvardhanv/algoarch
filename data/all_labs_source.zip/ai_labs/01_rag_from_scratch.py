"""Lab 01 — RAG from scratch. No LangChain, no vector database, no magic.

A complete Retrieval-Augmented Generation system in one file. Every stage is
visible and every stage prints what it did, because the entire point of this lab
is that RAG is not a product you install — it is six ordinary steps you already
know how to write:

    1. LOAD      read source documents
    2. CHUNK     cut them into retrievable pieces
    3. EMBED     turn each piece into a vector (LOCAL model — no API cost)
    4. INDEX     store the vectors so you can search them
    5. RETRIEVE  embed the question, find the nearest chunks
    6. GENERATE  paste those chunks into the prompt and ask the model

A "vector database" is step 4 plus persistence plus approximate search. You are
about to write step 4 in four lines of numpy, which is why you will never again
be confused about what Chroma or pgvector is *doing*.

USAGE
-----
    conda activate ai_projects
    # start the shim in another terminal first:
    #   python ../tools/claude_shim/server.py

    python 01_rag_from_scratch.py index                    # build the index
    python 01_rag_from_scratch.py ask "what is reranking?"  # one question
    python 01_rag_from_scratch.py ask "..." --show-work     # dump every stage
    python 01_rag_from_scratch.py ask "..." --no-rag        # ablation: no retrieval
    python 01_rag_from_scratch.py chat                      # interactive
    python 01_rag_from_scratch.py inspect                   # look at the index

FLAGS WORTH PLAYING WITH
------------------------
    --k N            how many chunks to retrieve (default 4)
    --chunk-size N   characters per chunk (default 900)
    --overlap N      character overlap between chunks (default 150)

Change them, re-index, re-ask. Watching answer quality move when you change
`--chunk-size` is the single fastest way to internalise why chunking matters.
"""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import re
import sys
import textwrap
import time

import numpy as np

# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
CORPUS = ROOT.parent / "ai-engineer-roadmap.md"      # the doc we'll answer over
INDEX_PATH = ROOT / "data" / "01_index.npz"

# 384-dim, ~90 MB, runs fine on CPU. Downloaded once to ~/.cache/huggingface.
# This is why the course costs $0: embeddings never leave your machine.
EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

sys.path.insert(0, str(HERE))
import aiconfig                      # noqa: E402  provider comes from env
SHIM_BASE_URL = aiconfig.BASE_URL
LLM_MODEL = aiconfig.MODEL

DIM = "\033[2m"
BOLD = "\033[1m"
CYAN = "\033[36m"
YELLOW = "\033[33m"
GREEN = "\033[32m"
RESET = "\033[0m"


def rule(label: str) -> None:
    print(f"\n{CYAN}{'─' * 4} {label} {'─' * max(0, 66 - len(label))}{RESET}")


# --------------------------------------------------------------------------- #
# STEP 1 — LOAD
# --------------------------------------------------------------------------- #

def load_document(path: pathlib.Path) -> str:
    """Read the source.

    In production this step is the hardest one in the whole pipeline: PDFs with
    two-column layouts, scanned pages, tables, headers/footers. Garbage parsing
    caps your quality ceiling no matter how good your retriever is. We get to
    skip it here because markdown is already clean text — enjoy it while it
    lasts; Lesson 03 makes you parse a real PDF.
    """
    if not path.exists():
        sys.exit(f"corpus not found: {path}")
    return path.read_text(encoding="utf-8")


# --------------------------------------------------------------------------- #
# STEP 2 — CHUNK
# --------------------------------------------------------------------------- #

def chunk_fixed(text: str, size: int = 900, overlap: int = 150) -> list[dict]:
    """Fixed-size character chunking with overlap. The naive baseline.

    WHY CHUNK AT ALL? Three independent reasons, and people usually only know
    the first:

      1. The document may not fit in the context window.
      2. Even when it fits, models degrade badly on long context — "lost in the
         middle" is real. Handing the model 40 pages to find one sentence in
         makes the answer WORSE, not just slower.
      3. Retrieval precision. Your unit of retrieval is your unit of relevance.
         Embed a whole 40-page doc into ONE vector and that vector is the
         average of 40 pages — an averaged blur that is close to everything and
         specific to nothing.

    WHY OVERLAP? A hard cut at character 900 can land mid-sentence, mid-table,
    or between a claim and the sentence that qualifies it. Overlap means the
    boundary appears in the middle of the *next* chunk too, so a fact split by a
    cut still lives intact somewhere.

    WHY THIS IS THE WRONG WAY (and we do it anyway): character counts have no
    idea what a section, a sentence, or a table is. Lesson 03 replaces it with
    structural chunking and you will measure the difference. Start naive, get a
    number, improve, get a better number. That loop is the whole job.
    """
    chunks: list[dict] = []
    step = size - overlap
    if step <= 0:
        sys.exit("--overlap must be smaller than --chunk-size")
    for i in range(0, len(text), step):
        body = text[i : i + size]
        if not body.strip():
            continue
        chunks.append({"id": len(chunks), "text": body, "start": i, "end": i + len(body)})
        if i + size >= len(text):
            break
    return chunks


def nearest_heading(text: str, pos: int) -> str:
    """Best-effort: the last markdown heading at or before `pos`.

    Not used for retrieval — used to make citations readable. Note how cheap
    this is compared to how much it improves the *human* experience of the
    answer. Metadata is consistently underrated.
    """
    head = text[:pos]
    matches = re.findall(r"^#{1,4} +(.+)$", head, flags=re.MULTILINE)
    return matches[-1].strip() if matches else "(preamble)"


# --------------------------------------------------------------------------- #
# STEP 3 — EMBED
# --------------------------------------------------------------------------- #

_model = None


def get_embedder():
    global _model
    if _model is None:
        from sentence_transformers import SentenceTransformer
        t0 = time.perf_counter()
        print(f"{DIM}loading embedding model {EMBED_MODEL} ...{RESET}", end="", flush=True)
        _model = SentenceTransformer(EMBED_MODEL)
        print(f"{DIM} {time.perf_counter() - t0:.1f}s{RESET}")
    return _model


def embed(texts: list[str]) -> np.ndarray:
    """Text -> float32 matrix of shape (n, 384), L2-normalised.

    WHAT AN EMBEDDING IS: a learned function from text to a point in R^384,
    trained so that texts humans consider related land near each other. It is
    NOT a summary, NOT reversible, and NOT a fact store. It is a coordinate.

    WHY L2-NORMALISE: once every vector has length 1, the dot product between
    two vectors IS their cosine similarity. So the entire search step becomes a
    single matrix multiply. That is the trick every vector DB is built on.

        cos(a, b) = (a · b) / (|a| |b|)     →  a · b     when |a| = |b| = 1

    RANGE: cosine ∈ [-1, 1] for arbitrary vectors, but modern sentence encoders
    put almost everything in roughly [0.0, 0.9]. A score of 0.35 is NOT "35%
    relevant" — the number is only meaningful *relative to other scores from the
    same model*. Never hard-code an absolute threshold without measuring first.
    """
    model = get_embedder()
    vecs = model.encode(
        texts, batch_size=64, convert_to_numpy=True,
        normalize_embeddings=True, show_progress_bar=len(texts) > 200,
    )
    return vecs.astype(np.float32)


# --------------------------------------------------------------------------- #
# STEP 4 — INDEX  (this is what a "vector database" mostly is)
# --------------------------------------------------------------------------- #

def build_index(chunk_size: int, overlap: int) -> dict:
    rule("STEP 1 — LOAD")
    text = load_document(CORPUS)
    print(f"source     : {CORPUS}")
    print(f"characters : {len(text):,}")

    rule("STEP 2 — CHUNK")
    chunks = chunk_fixed(text, size=chunk_size, overlap=overlap)
    for c in chunks:
        c["heading"] = nearest_heading(text, c["start"])
    lens = [len(c["text"]) for c in chunks]
    print(f"strategy   : fixed {chunk_size} chars, {overlap} overlap")
    print(f"chunks     : {len(chunks)}  (min {min(lens)} / mean {int(np.mean(lens))} / max {max(lens)} chars)")
    print(f"{DIM}first chunk preview: {chunks[0]['text'][:110].strip()!r}...{RESET}")

    rule("STEP 3 — EMBED")
    t0 = time.perf_counter()
    vecs = embed([c["text"] for c in chunks])
    dt = time.perf_counter() - t0
    print(f"model      : {EMBED_MODEL}  (local, $0)")
    print(f"matrix     : {vecs.shape}  dtype={vecs.dtype}  {vecs.nbytes / 1024:.0f} KiB")
    print(f"time       : {dt:.2f}s  ({len(chunks) / dt:.0f} chunks/s on CPU)")
    print(f"{DIM}norm check : |v0| = {np.linalg.norm(vecs[0]):.6f}  (1.0 ⇒ dot product == cosine){RESET}")

    rule("STEP 4 — INDEX")
    INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        INDEX_PATH,
        vecs=vecs,
        meta=np.array(json.dumps({
            "chunks": chunks, "model": EMBED_MODEL,
            "chunk_size": chunk_size, "overlap": overlap,
        })),
    )
    print(f"saved      : {INDEX_PATH}  ({INDEX_PATH.stat().st_size / 1024:.0f} KiB)")
    print(textwrap.dedent(f"""\
        {DIM}That's the whole index: one (n, 384) float32 matrix + the chunk text.
        A real vector DB adds (a) persistence you didn't write, (b) metadata
        filtering, and (c) APPROXIMATE nearest-neighbour search (HNSW/IVF) so it
        stays fast at 10M vectors instead of {len(chunks)}. At this scale, exact
        brute-force search is not just adequate — it is strictly better, because
        ANN trades recall for speed and you have no speed problem.{RESET}"""))
    return {"vecs": vecs, "chunks": chunks}


def load_index() -> dict:
    if not INDEX_PATH.exists():
        sys.exit(f"no index at {INDEX_PATH} — run:  python {pathlib.Path(__file__).name} index")
    z = np.load(INDEX_PATH, allow_pickle=False)
    meta = json.loads(str(z["meta"]))
    return {"vecs": z["vecs"], "chunks": meta["chunks"], "meta": meta}


# --------------------------------------------------------------------------- #
# STEP 5 — RETRIEVE
# --------------------------------------------------------------------------- #

def retrieve(index: dict, question: str, k: int = 4, timing: dict | None = None) -> list[dict]:
    """Embed the question, score every chunk, return the top-k.

    THE ASYMMETRY NOBODY WARNS YOU ABOUT: you are comparing a QUESTION to
    ANSWER-SHAPED TEXT. "How do I stop the agent looping forever?" and "Add a
    step budget and a loop detector" are semantically related but lexically
    disjoint. Dense embeddings handle this far better than keyword search — that
    is precisely what they are for — but they are also why dense retrieval
    *fails* on exact identifiers: error codes, function names, SKUs, dates.
    Those need BM25. That is the entire argument for hybrid search in Lesson 04.

    THE MATH: one matrix-vector product. `vecs` is (n, 384), `qv` is (384,), so
    `vecs @ qv` is (n,) — the cosine similarity of the query against every chunk
    at once. Brute force, exact, and on 40 chunks it is microseconds.
    """
    t0 = time.perf_counter()
    qv = embed([question])[0]
    t1 = time.perf_counter()
    scores = index["vecs"] @ qv                      # (n,) cosine similarities
    order = np.argsort(-scores)[:k]                  # top-k, descending
    t2 = time.perf_counter()
    if timing is not None:
        # Kept separate on purpose. Conflating these is how people conclude
        # "vector search is slow" when they actually measured a model forward
        # pass. Embedding the query is ~1000x the cost of searching 40 vectors.
        timing["embed_ms"] = (t1 - t0) * 1000
        timing["search_ms"] = (t2 - t1) * 1000
    out = []
    for rank, i in enumerate(order, 1):
        c = dict(index["chunks"][int(i)])
        c["score"] = float(scores[int(i)])
        c["rank"] = rank
        out.append(c)
    return out


# --------------------------------------------------------------------------- #
# STEP 6 — GENERATE
# --------------------------------------------------------------------------- #

SYSTEM_PROMPT = """\
You answer questions using ONLY the numbered context passages provided.

Rules:
- Every factual claim must be traceable to a passage. Cite as [1], [2] inline.
- If the passages do not contain the answer, reply exactly:
  "Not in the provided context."
  Do not answer from your own knowledge. Do not guess. Do not apologise.
- Be direct and specific. Prefer the document's own wording for technical terms.
"""


def build_context_block(chunks: list[dict]) -> str:
    """Assemble retrieved chunks into the prompt.

    Three deliberate choices, each of which you should be able to defend:

      * NUMBERED passages ⇒ the model has a token-cheap handle to cite. Without
        an identifier it cites by paraphrase, which you cannot verify
        programmatically.
      * Context goes in the USER turn, not the system prompt. Retrieved text is
        UNTRUSTED input — it came from a document. Keeping the trust boundary
        visible is the habit that saves you in Lesson 14, when one of those
        documents contains "ignore previous instructions".
      * Highest-scoring chunk FIRST. Models weight the start and end of context
        more heavily than the middle ("lost in the middle"). With k=4 it barely
        matters; at k=20 it matters a lot.
    """
    parts = []
    for c in chunks:
        parts.append(f"[{c['rank']}] (section: {c['heading']}, score {c['score']:.3f})\n{c['text'].strip()}")
    return "\n\n".join(parts)


def generate(question: str, chunks: list[dict] | None, *, show_work: bool = False) -> dict:

    client = aiconfig.client()

    if chunks is None:
        # Ablation path: no retrieval at all. Run this to see what RAG bought you.
        messages = [
            {"role": "system", "content": "Answer the question directly and honestly. "
                                          "If you are not sure, say so."},
            {"role": "user", "content": question},
        ]
    else:
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content":
                f"Context passages:\n\n{build_context_block(chunks)}\n\n"
                f"Question: {question}"},
        ]

    if show_work:
        rule("STEP 6 — THE ACTUAL PROMPT SENT")
        for m in messages:
            print(f"{YELLOW}<{m['role']}>{RESET}")
            print(textwrap.indent(m["content"][:1800], "  "))
            if len(m["content"]) > 1800:
                print(f"  {DIM}... [{len(m['content']) - 1800} more chars]{RESET}")

    t0 = time.perf_counter()
    resp = client.chat.completions.create(model=LLM_MODEL, messages=messages)
    return {
        "text": resp.choices[0].message.content,
        "usage": resp.usage,
        "latency": time.perf_counter() - t0,
        "extra": getattr(resp, "x_claude", None),
    }


# --------------------------------------------------------------------------- #
# Commands
# --------------------------------------------------------------------------- #

def cmd_ask(args) -> None:
    if args.no_rag:
        rule("ABLATION — NO RETRIEVAL")
        print(f"{DIM}Same question, no context. Compare this answer to the RAG one.{RESET}")
        out = generate(args.question, None, show_work=args.show_work)
        chunks = []
    else:
        index = load_index()
        get_embedder()          # load the model BEFORE timing anything
        rule("STEP 5 — RETRIEVE")
        timing: dict = {}
        chunks = retrieve(index, args.question, k=args.k, timing=timing)
        print(f"query      : {args.question!r}")
        print(f"embed query: {timing['embed_ms']:.1f} ms   (one forward pass through MiniLM)")
        print(f"search     : {timing['search_ms']:.3f} ms  ({len(index['chunks'])} chunks, "
              f"exact brute force — one matmul)")
        print()
        for c in chunks:
            preview = " ".join(c["text"].split())[:88]
            bar = "█" * max(1, int(c["score"] * 30))
            print(f"  [{c['rank']}] {GREEN}{c['score']:.3f}{RESET} {bar:<30} {DIM}{c['heading'][:28]:<28}{RESET} {preview}...")
        spread = chunks[0]["score"] - chunks[-1]["score"]
        print(f"\n{DIM}score spread top→bottom: {spread:.3f}. A FLAT spread means the retriever "
              f"can't tell these apart — a warning sign that your query is vague or your "
              f"chunks are too uniform.{RESET}")
        out = generate(args.question, chunks, show_work=args.show_work)

    rule("ANSWER")
    print(textwrap.fill(out["text"], width=88, replace_whitespace=False))

    u = out["usage"]
    rule("COST")
    print(f"tokens     : {u.prompt_tokens} in + {u.completion_tokens} out = {u.total_tokens}")
    print(f"latency    : {out['latency']:.2f}s")
    if chunks:
        ctx_chars = sum(len(c["text"]) for c in chunks)
        print(f"{DIM}context    : {ctx_chars:,} chars of retrieved text ≈ {ctx_chars // 4} tokens "
              f"({100 * (ctx_chars // 4) // max(1, u.prompt_tokens)}% of your input bill).")
        print(f"             That fraction is the RAG tax. Every retrieval decision — k, "
              f"chunk size, reranking — is a bet that this tax buys more accuracy than it costs.{RESET}")


def cmd_chat(args) -> None:
    index = load_index()
    print(f"{BOLD}RAG chat{RESET} over {CORPUS.name} — {len(index['chunks'])} chunks, k={args.k}")
    print(f"{DIM}Ctrl-C or 'exit' to quit. History is NOT kept: each question is retrieved")
    print(f"independently. Multi-turn RAG needs query rewriting — that's Lesson 04.{RESET}\n")
    while True:
        try:
            q = input(f"{BOLD}you ›{RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not q or q.lower() in {"exit", "quit"}:
            return
        chunks = retrieve(index, q, k=args.k)
        srcs = ", ".join(f"[{c['rank']}] {c['heading'][:24]} ({c['score']:.2f})" for c in chunks)
        print(f"{DIM}retrieved: {srcs}{RESET}")
        out = generate(q, chunks)
        print(f"{GREEN}rag  ›{RESET} {textwrap.fill(out['text'], width=88, subsequent_indent='       ')}")
        print(f"{DIM}       {out['usage'].total_tokens} tok · {out['latency']:.1f}s{RESET}\n")


def cmd_inspect(args) -> None:
    index = load_index()
    m = index["meta"]
    rule("INDEX")
    print(f"chunks      : {len(index['chunks'])}")
    print(f"vectors     : {index['vecs'].shape}  {index['vecs'].nbytes/1024:.0f} KiB")
    print(f"model       : {m['model']}")
    print(f"chunk_size  : {m['chunk_size']}  overlap: {m['overlap']}")

    # How similar are chunks to EACH OTHER? Reveals redundancy in your corpus.
    sims = index["vecs"] @ index["vecs"].T
    np.fill_diagonal(sims, -1)
    i, j = np.unravel_index(np.argmax(sims), sims.shape)
    rule("MOST SIMILAR CHUNK PAIR")
    print(f"cosine {sims[i, j]:.3f} between chunk {i} ({index['chunks'][i]['heading']}) "
          f"and chunk {j} ({index['chunks'][j]['heading']})")
    print(f"{DIM}Near-duplicate chunks waste your top-k: retrieve 4 and get the same fact 4 times.")
    print(f"Dedup / MMR (maximal marginal relevance) is the fix — Lesson 04.{RESET}")

    off = sims[np.triu_indices_from(sims, k=1)]
    rule("SIMILARITY DISTRIBUTION (chunk ↔ chunk)")
    print(f"mean {off.mean():.3f}   p50 {np.percentile(off,50):.3f}   "
          f"p95 {np.percentile(off,95):.3f}   max {off.max():.3f}")
    print(f"{DIM}These are all chunks from ONE document, so baseline similarity is high. This is")
    print(f"why an absolute threshold like 'score > 0.5 means relevant' is meaningless without")
    print(f"calibrating against your own corpus first.{RESET}")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    pi = sub.add_parser("index", help="build the vector index")
    pi.add_argument("--chunk-size", type=int, default=900)
    pi.add_argument("--overlap", type=int, default=150)

    pa = sub.add_parser("ask", help="ask one question")
    pa.add_argument("question")
    pa.add_argument("--k", type=int, default=4)
    pa.add_argument("--show-work", action="store_true", help="print the full prompt")
    pa.add_argument("--no-rag", action="store_true", help="ablation: skip retrieval entirely")

    pc = sub.add_parser("chat", help="interactive loop")
    pc.add_argument("--k", type=int, default=4)

    sub.add_parser("inspect", help="statistics about the built index")

    args = p.parse_args()
    if args.cmd == "index":
        build_index(args.chunk_size, args.overlap)
    elif args.cmd == "ask":
        cmd_ask(args)
    elif args.cmd == "chat":
        cmd_chat(args)
    elif args.cmd == "inspect":
        cmd_inspect(args)


if __name__ == "__main__":
    main()
