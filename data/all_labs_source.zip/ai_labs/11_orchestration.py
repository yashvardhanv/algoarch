"""Lab 11 — Orchestration, state, durability, human-in-the-loop.

Lesson 10's loop works and loses everything the moment the process dies. This lab
adds the four things that make a long-running agent operable:

    CHECKPOINTING   persist state after every step; resume instead of restart
    INTERRUPTS      pause for a human, return control, continue later
    DURABILITY      survive a process restart, not just an exception
    COMPACTION      bound context growth so step 40 is possible at all

    python 11_orchestration.py crash      # A. kill mid-run, resume, count lost work
    python 11_orchestration.py interrupt  # B. pause for approval, exit, resume, finish
    python 11_orchestration.py compact    # C. context growth with and without compaction
    python 11_orchestration.py fsm        # D. a state machine vs a free-running loop
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import sys
import time
import uuid
from dataclasses import dataclass, field, asdict

HERE = pathlib.Path(__file__).resolve().parent
STATE_DIR = HERE.parent / "data" / "runs"
spec = importlib.util.spec_from_file_location("lab10", HERE / "10_agent_loop.py")
lab10 = importlib.util.module_from_spec(spec)
# MUST register before exec_module: @dataclass resolves type hints via
# sys.modules[cls.__module__], which is None for a module loaded this way.
# Earlier labs got away without this only because they had no dataclasses.
sys.modules["lab10"] = lab10
spec.loader.exec_module(lab10)

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")


def rule(s):
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


# --------------------------------------------------------------------------- #
# DURABLE STATE
# --------------------------------------------------------------------------- #

@dataclass
class RunState:
    """Everything needed to resume. If it isn't in here, a crash loses it.

    The test for a durable design is blunt: delete the process, keep only this
    file, and ask whether the run can continue. Anything held in a local
    variable, a closure, or an in-memory list fails that test.
    """
    run_id: str
    question: str
    status: str = "running"          # running | awaiting_approval | done | failed
    step: int = 0
    cost: float = 0.0
    messages: list[dict] = field(default_factory=list)
    seen: list[str] = field(default_factory=list)
    pending_action: dict | None = None   # the action waiting for a human
    answer: str | None = None
    stopped: str = ""
    history: list[dict] = field(default_factory=list)   # audit trail (Lesson 06)

    def path(self) -> pathlib.Path:
        return STATE_DIR / f"{self.run_id}.json"

    def save(self) -> None:
        """Atomic write. A half-written checkpoint is worse than none — it
        resumes into a corrupt state and the failure looks like a model bug."""
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        tmp = self.path().with_suffix(".tmp")
        tmp.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        tmp.replace(self.path())

    @classmethod
    def load(cls, run_id: str) -> "RunState":
        return cls(**json.loads((STATE_DIR / f"{run_id}.json").read_text(encoding="utf-8")))

    @classmethod
    def exists(cls, run_id: str) -> bool:
        return (STATE_DIR / f"{run_id}.json").exists()


# --------------------------------------------------------------------------- #
# THE DURABLE LOOP
# --------------------------------------------------------------------------- #

def step_once(st: RunState, *, approve: bool = False, max_steps: int = 8) -> RunState:
    """Advance exactly ONE step and checkpoint. The unit of durability is the
    step, so the most work a crash can destroy is one step."""
    if st.status in ("done", "failed"):
        return st

    # resuming into a pending approval
    if st.status == "awaiting_approval":
        act = st.pending_action or {}
        if not approve:
            return st                                   # still waiting; no work done
        obs = lab10.TOOLS[act["action"]]["fn"](
            **{k: act.get("args", {}).get(k) for k in lab10.TOOLS[act["action"]]["args"]})
        st.messages.append({"role": "assistant", "content": json.dumps(act)})
        st.messages.append({"role": "user", "content": f"Observation: {json.dumps(obs)[:1200]}"})
        st.history.append({"step": st.step, "action": act["action"], "approved": True,
                           "result": obs})
        st.pending_action = None
        st.status = "running"
        st.save()
        return st

    if st.step >= max_steps:
        st.status, st.stopped = "done", f"step budget exhausted ({max_steps})"
        st.save()
        return st

    st.step += 1
    act, cost = lab10.call_model(st.messages)
    st.cost += cost
    name, args = act.get("action", ""), act.get("args", {}) or {}
    sig = json.dumps({"a": name, "g": args}, sort_keys=True)

    if sig in st.seen:
        st.status, st.stopped = "done", f"loop detected — repeated {name}"
        st.save()
        return st
    st.seen.append(sig)

    if name == "finish":
        st.answer = args.get("answer", "")
        st.status, st.stopped = "done", "finished"
        st.history.append({"step": st.step, "action": name, "args": args})
        st.save()
        return st

    spec_ = lab10.TOOLS.get(name)
    if spec_ and spec_["danger"]:
        # INTERRUPT: persist the pending action and hand control back to the
        # caller. The process may now exit entirely.
        st.pending_action = act
        st.status = "awaiting_approval"
        st.history.append({"step": st.step, "action": name, "args": args,
                           "result": "AWAITING HUMAN APPROVAL"})
        st.save()
        return st

    if not spec_:
        obs = {"error": f"unknown action {name!r}. Valid: {', '.join(lab10.TOOLS)}"}
    else:
        try:
            obs = spec_["fn"](**{k: args.get(k) for k in spec_["args"]})
        except Exception as e:  # noqa: BLE001
            obs = {"error": f"{type(e).__name__}: {e}"}

    st.messages.append({"role": "assistant", "content": json.dumps(act)})
    st.messages.append({"role": "user", "content": f"Observation: {json.dumps(obs)[:1200]}"})
    st.history.append({"step": st.step, "action": name, "args": args, "result": obs})
    st.save()
    return st


def new_run(question: str) -> RunState:
    st = RunState(run_id=uuid.uuid4().hex[:8], question=question)
    st.messages = [{"role": "system", "content": lab10.SYSTEM},
                   {"role": "user", "content": f"Question: {question}"}]
    st.save()
    return st


# --------------------------------------------------------------------------- #
# A. CRASH AND RESUME
# --------------------------------------------------------------------------- #

def cmd_crash(_a) -> None:
    rule("A. CRASH MID-RUN, THEN RESUME")
    q = "How many chunks mention reranking, and what does the roadmap say about it?"
    st = new_run(q)
    print(f"{DIM}run {st.run_id} · checkpoint: {st.path()}{RESET}\n")

    CRASH_AFTER = 2
    for _ in range(CRASH_AFTER):
        st = step_once(st)
        last = st.history[-1] if st.history else {}
        print(f"  step {st.step}  {BOLD}{last.get('action','?')}{RESET}  "
              f"${st.cost:.4f}  {DIM}checkpointed{RESET}")

    print(f"\n  {RED}*** PROCESS DIES HERE ***{RESET}  {DIM}(simulating SIGKILL — no cleanup,")
    print(f"  no finally block, no graceful shutdown){RESET}")
    run_id, cost_before, steps_before = st.run_id, st.cost, st.step
    del st                                              # everything in memory is gone

    print(f"\n{DIM}new process. Only the checkpoint file survives.{RESET}")
    st = RunState.load(run_id)
    print(f"  resumed run {st.run_id} at step {st.step}, ${st.cost:.4f} already spent")
    print(f"  {GREEN}work lost: 0 steps{RESET}  {DIM}(the unit of durability is one step){RESET}\n")

    while st.status == "running":
        st = step_once(st)
        last = st.history[-1] if st.history else {}
        print(f"  step {st.step}  {BOLD}{last.get('action','?')}{RESET}  ${st.cost:.4f}")

    print(f"\n  stopped: {GREEN}{st.stopped}{RESET} · total {st.step} steps · ${st.cost:.4f}")
    if st.answer:
        print(f"  answer: {' '.join(st.answer.split())[:110]}")

    naive_cost = st.cost + cost_before      # what a restart-from-scratch would have cost
    print(f"""
{BOLD}What checkpointing bought{RESET}
  resumed at step        {steps_before + 1} of {st.step}
  cost already spent     ${cost_before:.4f}  (preserved)
  restart-from-scratch   ${naive_cost:.4f}  ({naive_cost/max(st.cost,1e-9):.2f}x)

{DIM}On a 4-step run that is small change. On a 40-step research agent that has been
running for 20 minutes, a crash at step 38 without checkpointing throws away the
entire run AND its cost, and then your retry does it again. That is the shape of
a 3am incident: the system is not broken, it is just unable to finish.

The blunt test for a durable design: delete the process, keep only the state
file, and ask whether the run can continue. Anything living in a local variable,
a closure, or an in-memory list fails that test.{RESET}""")


# --------------------------------------------------------------------------- #
# B. INTERRUPT / RESUME AROUND A HUMAN
# --------------------------------------------------------------------------- #

def cmd_interrupt(_a) -> None:
    rule("B. INTERRUPT — pause for a human, exit, resume later")
    q = "Write a note to disk containing the single most important idea in the roadmap."
    st = new_run(q)
    print(f"{DIM}run {st.run_id}{RESET}\n")

    while st.status == "running":
        st = step_once(st)
        last = st.history[-1] if st.history else {}
        mark = (YELLOW + "PAUSED " + RESET) if st.status == "awaiting_approval" else "       "
        print(f"  {mark} step {st.step}  {BOLD}{last.get('action','?')}{RESET}")

    if st.status == "awaiting_approval":
        act = st.pending_action
        print(f"""
  {YELLOW}RUN SUSPENDED — awaiting human approval{RESET}
  action  : {BOLD}{act['action']}{RESET}
  args    : {json.dumps(act.get('args', {}))[:120]}
  state   : {st.path()}

{DIM}Note what just happened, because it is the whole point. Lesson 10's approval
gate BLOCKED the action and let the agent continue with a refusal observation.
This one SUSPENDS THE RUN and returns control. The process can now exit for a
week. The human approves in a UI, a queue, or a Slack button, and a completely
different process resumes exactly here.

Blocking is a guard rail. Suspending is a workflow. Production needs the second
one, because a human is not going to approve within your HTTP timeout.{RESET}""")

        run_id = st.run_id
        del st
        print(f"\n{DIM}--- process exits. later, a human approves. new process: ---{RESET}\n")
        st = RunState.load(run_id)
        print(f"  resumed run {st.run_id} at step {st.step}, status={st.status}")
        st = step_once(st, approve=True)
        print(f"  {GREEN}approved{RESET} — action executed, run continues")
        while st.status == "running":
            st = step_once(st)
            last = st.history[-1] if st.history else {}
            print(f"          step {st.step}  {BOLD}{last.get('action','?')}{RESET}")

    print(f"\n  stopped: {GREEN}{st.stopped}{RESET} · {st.step} steps · ${st.cost:.4f}")
    note = HERE.parent / "data" / "agent_note.txt"
    if note.exists():
        print(f"  {DIM}note written: {' '.join(note.read_text().split())[:90]}{RESET}")


# --------------------------------------------------------------------------- #
# C. CONTEXT COMPACTION
# --------------------------------------------------------------------------- #

def cmd_compact(_a) -> None:
    rule("C. COMPACTION — bounding context growth")
    print(f"""{DIM}Lesson 07 measured conversation memory. The same problem returns in an agent
as OBSERVATION GROWTH: every tool result is appended forever, and step 40 dies
with a context-length error. Three strategies, measured on a real run's messages.{RESET}""")

    q = "What does the roadmap say about evaluation, retrieval, and agents?"
    st = new_run(q)
    while st.status == "running" and st.step < 6:
        st = step_once(st, max_steps=6)

    msgs = st.messages
    chars_full = sum(len(m["content"]) for m in msgs)

    def window(ms, keep=4):
        return ms[:2] + ms[-keep:] if len(ms) > keep + 2 else ms

    def truncate_obs(ms, cap=300):
        out = []
        for m in ms:
            c = m["content"]
            if m["role"] == "user" and c.startswith("Observation:") and len(c) > cap:
                c = c[:cap] + f"… [truncated {len(c)-cap} chars]"
            out.append({**m, "content": c})
        return out

    strategies = [
        ("full history (Lesson 10)", msgs),
        ("sliding window (last 4)", window(msgs)),
        ("truncate observations", truncate_obs(msgs)),
        ("truncate + window", window(truncate_obs(msgs))),
    ]
    # Does the FIRST tool result survive? Identify it by content, not position —
    # the first version of this check looked at ms[:4], which after windowing
    # contains LATE observations, and so reported "yes" for a strategy that had
    # in fact dropped step 1. A positional check on a reordered list is a bug.
    first_obs = next((m["content"] for m in msgs
                      if m["role"] == "user" and m["content"].startswith("Observation:")), None)
    first_key = (first_obs or "")[:60]

    print(f"\n  {'strategy':<28} {'messages':>9} {'chars':>8} {'vs full':>8} {'step-1 result?':>15}")
    print(f"  {DIM}{'-'*28} {'-'*9} {'-'*8} {'-'*8} {'-'*15}{RESET}")
    for name, ms in strategies:
        c = sum(len(m["content"]) for m in ms)
        kept = bool(first_key) and any(m["content"].startswith(first_key[:40]) for m in ms)
        col = GREEN if c < chars_full * 0.6 else YELLOW
        mark = (GREEN + "kept" if kept else RED + "DROPPED") + RESET
        print(f"  {name:<28} {len(ms):>9} {col}{c:>8,}{RESET} "
              f"{c/max(1,chars_full):>7.0%} {mark:>24}")

    print(f"""
{DIM}Truncating observations is almost free and keeps the SHAPE of the run — the
agent still sees that step 1 was a `count` and roughly what it returned. A
sliding window drops early steps entirely, which is how an agent forgets the
constraint it was given at the start and re-does work it already did.

The strategy that actually scales, and the one this lab does NOT implement:
extract structured state. Keep {{facts_found, tools_tried, goal}} as a dict,
re-inject it every turn, and let the raw transcript go. Same argument as Lesson
07 — the version you can debug is the version that stores named fields.{RESET}""")


# --------------------------------------------------------------------------- #
# D. STATE MACHINE vs FREE-RUNNING LOOP
# --------------------------------------------------------------------------- #

def cmd_fsm(_a) -> None:
    rule("D. STATE MACHINE vs FREE-RUNNING LOOP")
    print(f"""{DIM}Lesson 10's loop lets the model choose any action at any time. A state machine
constrains WHICH actions are legal in WHICH state. That is less flexible and much
more testable — and for most production work, that trade is correct.{RESET}""")

    FSM = {
        "start":     {"legal": ["count", "search"], "next": "gathering"},
        "gathering": {"legal": ["count", "search", "finish"], "next": "gathering"},
        "writing":   {"legal": ["write_note", "finish"], "next": "done"},
        "done":      {"legal": [], "next": None},
    }
    print(f"\n  {'state':<12} {'legal actions':<34} {'illegal here'}")
    print(f"  {DIM}{'-'*12} {'-'*34} {'-'*24}{RESET}")
    allt = set(lab10.TOOLS)
    for s, v in FSM.items():
        illegal = sorted(allt - set(v["legal"]))
        print(f"  {s:<12} {', '.join(v['legal']) or '—':<34} {DIM}{', '.join(illegal)[:24]}{RESET}")

    print(f"""
{BOLD}What the constraint buys{RESET}
{DIM}  * `write_note` is UNREACHABLE from `start` — not "discouraged by the prompt",
    structurally unreachable. That is a security property, not a behaviour.
  * every state transition is a test case you can write without an LLM
  * a stuck run names its state, so "it hung" becomes "it was in `gathering`
    for 30 steps"
  * checkpointing gets simpler: the state name IS most of the state

{BOLD}When you still want the free-running loop{RESET}
  when you genuinely cannot enumerate the states — open-ended research, debugging
  an unfamiliar system. That is the same test as Lesson 10's "can you draw the
  flowchart": if you can draw it, encode it, and get testability for free.

{BOLD}What a real framework adds on top{RESET}
  LangGraph and the vendor agent SDKs give you this state machine PLUS
  checkpointing, interrupts, and resume as primitives — which is exactly the 200
  lines you just read. Write it once by hand so you can read their source; then
  use theirs, because their edge cases are already found.{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for c in ("crash", "interrupt", "compact", "fsm"):
        sub.add_parser(c)
    a = p.parse_args()
    {"crash": cmd_crash, "interrupt": cmd_interrupt,
     "compact": cmd_compact, "fsm": cmd_fsm}[a.cmd](a)


if __name__ == "__main__":
    main()
