"""Lab 08 — Drive the evalkit harness end to end, exactly as CI would.

    python 08_run_evals.py build      # build + validate a versioned gold dataset
    python 08_run_evals.py calibrate  # calibrate the judge, refuse it if kappa is low
    python 08_run_evals.py run        # full run -> HTML report + baseline
    python 08_run_evals.py ci         # re-run and gate on regression (exit code!)
    python 08_run_evals.py regress    # deliberately break retrieval, watch CI fail
"""

from __future__ import annotations

import importlib.util
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
DATA = HERE.parent / "data"
sys.path.insert(0, str(HERE))

spec = importlib.util.spec_from_file_location("lab4", HERE / "04_retrieval.py")
lab4 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab4)

import evalkit as ek  # noqa: E402

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")

GOLD_PATH = DATA / "gold_v1.json"
BASELINE = DATA / "baseline.json"
REPORT = DATA / "eval_report.html"


def rule(s):
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


def ask(system, user, schema=None):
    import aiconfig
    kw = {}
    if schema:
        kw["response_format"] = {"type": "json_schema", "json_schema": {"name": "v", "schema": schema}}
    r = aiconfig.client().chat.completions.create(
        model=aiconfig.MODEL,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}], **kw)
    return r.choices[0].message.content.strip()


ANSWER_SYS = ("Answer using ONLY the numbered context passages. Cite as [1], [2]. "
              "If the passages do not contain the answer, reply exactly: "
              "Not in the provided context. Maximum two sentences.")

UNANSWERABLE = [
    ("u1", "What is the current price of Bitcoin?"),
    ("u2", "How many employees does OpenAI have?"),
    ("u3", "What is my account balance?"),
]


# --------------------------------------------------------------------------- #

def cmd_build(_a) -> None:
    rule("BUILD + VALIDATE THE GOLD DATASET")
    corpus = lab4.CORPUS.read_text(encoding="utf-8")
    examples = []
    for i, (q, tag, ans) in enumerate(lab4.GOLD):
        examples.append(ek.Example(
            id=f"g{i:03d}", question=q, answer=ans, tags=[tag],
            doc=lab4.CORPUS.name, offset=corpus.find(ans), answerable=True))
    for uid, q in UNANSWERABLE:
        examples.append(ek.Example(id=uid, question=q, answer="", tags=["unanswerable"],
                                   doc=lab4.CORPUS.name, offset=-1, answerable=False))

    ds = ek.Dataset(name="roadmap-gold", schema_version=1, examples=examples)
    problems = ds.validate(corpus)
    print(f"{len(examples)} examples ({sum(not e.answerable for e in examples)} unanswerable)")
    if problems:
        print(f"{RED}VALIDATION FAILED — {len(problems)} problem(s){RESET}")
        for p in problems[:10]:
            print(f"  {p}")
        sys.exit(1)
    print(f"{GREEN}validation passed{RESET} — every gold answer found at its recorded offset")

    dev, test = ds.split(0.5)
    DATA.mkdir(parents=True, exist_ok=True)
    ds.save(GOLD_PATH)
    print(f"wrote {GOLD_PATH}  (dev {len(dev.examples)} / test {len(test.examples)})")
    print(f"""
{DIM}Two things this step does that a plain list of questions does not:

  * every answerable example records doc + OFFSET, so re-chunking cannot silently
    invalidate the labels (Lesson 03). validate() re-checks the offset actually
    points at the gold string.
  * schema_version means a harness refuses to run against a dataset it does not
    understand, instead of scoring zeros that look like a quality regression.{RESET}""")


# --------------------------------------------------------------------------- #

CAL_CONTEXT = """[1] Reranking: a cross-encoder over the top ~50-100 candidates. Retrieve wide,
rerank narrow. This is usually the highest-ROI single upgrade to a mediocre RAG system.

[2] Hybrid search is the baseline, not an optimisation. BM25/sparse for exact terms, IDs,
and rare tokens; dense vectors for paraphrase and concept. Fuse with Reciprocal Rank Fusion.

[3] Vector stores: pgvector (default — you probably already have Postgres), Qdrant, Weaviate,
Milvus, Pinecone, Vespa, Turbopuffer."""

CAL_Q = "How should I improve a mediocre RAG system, and what should I use to store vectors?"

CAL_CASES = [
    ek.JudgeCase("Add a cross-encoder reranker over the top 50-100 candidates [1]. pgvector is a "
                 "sensible default [3].", True, "—", 1),
    ek.JudgeCase("Hybrid search with BM25 and dense vectors fused by RRF [2]; store in pgvector [3].",
                 True, "—", 1),
    ek.JudgeCase("Add a reranker [1] and use pgvector [3], which benchmarks show is 3x faster than "
                 "Pinecone.", False, "unsupported benchmark claim", 1),
    ek.JudgeCase("Rerank the top 5-10 candidates [1] and use pgvector [3].", False,
                 "number changed 50-100 -> 5-10", 1),
    ek.JudgeCase("Hybrid search is an optional optimisation you can skip [2].", False,
                 "contradicts the context", 1),
    ek.JudgeCase("Not in the provided context.", False, "false refusal", 1),
    ek.JudgeCase("Add a cross-encoder reranker over the top 50-100 candidates [2], and store "
                 "vectors in pgvector [3].", False, "MIS-CITATION: cites [2] not [1]", 2),
    ek.JudgeCase("Reranking is the highest-ROI upgrade [1]. pgvector is the default and is "
                 "probably sufficient for most teams [3].", False,
                 "hedged extrapolation not in context", 2),
    ek.JudgeCase("Use a reranker [1] and pgvector [3], which is open source.", False,
                 "true-in-world but not in context", 2),
    ek.JudgeCase("Hybrid search fusing BM25 and dense vectors is the baseline [2]; pgvector is the "
                 "suggested default [3].", True, "—", 2),
]


def make_judge():
    return ek.Judge(ask=lambda s, u, sch: ask(s, u, sch))


def cmd_calibrate(_a) -> None:
    rule("CALIBRATE THE JUDGE — before trusting a single verdict")
    j = make_judge()

    print(f"{DIM}The harness REFUSES to report judge verdicts before calibration. Proving it:{RESET}")
    try:
        j.require_calibrated()
        print(f"{RED}  it did not refuse — that is a bug{RESET}")
    except RuntimeError as e:
        print(f"  {GREEN}refused as designed:{RESET} {e}")

    print(f"\n{DIM}calibrating against {len(CAL_CASES)} known-defect cases …{RESET}")
    cal = j.calibrate(CAL_CONTEXT, CAL_Q, CAL_CASES)
    for tier, v in cal.items():
        col = GREEN if v["kappa"] > 0.6 else (YELLOW if v["kappa"] > 0.4 else RED)
        print(f"\n  {BOLD}{tier}{RESET}  n={v['n']}  accuracy {v['accuracy']:.0%}  "
              f"kappa {col}{v['kappa']:.3f}{RESET}")
        for d in v["missed"]:
            print(f"    {RED}missed:{RESET} {d}")
        for d in v["false_alarms"]:
            print(f"    {YELLOW}false alarm:{RESET} {d}")

    (DATA / "judge_calibration.json").write_text(json.dumps(cal, indent=2), encoding="utf-8")
    try:
        j.require_calibrated(min_kappa=0.6)
        print(f"\n{GREEN}judge accepted — kappa above 0.6 on every tier{RESET}")
    except RuntimeError as e:
        print(f"\n{RED}judge REJECTED:{RESET} {e}")

    print(f"""
{DIM}The gate is the point. A judge below the kappa threshold does not get to
contribute verdicts to a report, because a report containing an unreliable
measurement is worse than a report missing one — people act on it either way.{RESET}""")


# --------------------------------------------------------------------------- #

def make_runner(break_retrieval: bool = False):
    idx = lab4.Index(lab4.chunk_recursive(lab4.CORPUS.read_text(encoding="utf-8")))
    texts = {f"c{i}": t for i, t in enumerate(idx.texts)}

    def retriever(q: str):
        if break_retrieval:
            # the deliberate regression: dense-only, k truncated to 2
            order = lab4.p_dense(idx, q)[:2]
        else:
            order = lab4.p_hybrid_rerank(idx, q)[:10]
        return [f"c{int(i)}" for i in order], texts

    def generator(q: str, ctx: list[str]) -> str:
        block = "\n\n".join(f"[{i}] {t.strip()}" for i, t in enumerate(ctx, 1))
        return ask(ANSWER_SYS, f"Context passages:\n\n{block}\n\nQuestion: {q}")

    return retriever, generator


def _load_ds():
    if not GOLD_PATH.exists():
        sys.exit("run `python 08_run_evals.py build` first")
    return ek.Dataset.load(GOLD_PATH)


def cmd_run(_a) -> None:
    rule("FULL RUN → HTML REPORT + BASELINE")
    ds = _load_ds()
    retriever, generator = make_runner()
    j = make_judge()
    j.calibrate(CAL_CONTEXT, CAL_Q, CAL_CASES)
    try:
        j.require_calibrated(0.6)
        judge = j
        print(f"{GREEN}judge calibrated and accepted{RESET}")
    except RuntimeError as e:
        judge = None
        print(f"{YELLOW}judge rejected ({e}) — running WITHOUT groundedness{RESET}")

    h = ek.Harness(ds, retriever, generator, judge)
    print(f"{DIM}running {len(ds.examples)} examples …{RESET}")
    rep = h.run()
    for k, v in rep.summary().items():
        print(f"  {k:<18} {v:.3f}")
    rep.to_html(REPORT)
    rep.save_baseline(BASELINE)
    print(f"\nwrote {REPORT}")
    print(f"wrote {BASELINE}  {DIM}(this run is now the baseline CI compares against){RESET}")


def cmd_ci(_a) -> None:
    rule("CI GATE — same code a build server would run")
    ds = _load_ds()
    retriever, generator = make_runner()
    rep = ek.Harness(ds, retriever, generator).run()
    ok = rep.assert_no_regression(BASELINE)
    print(f"\n{DIM}exit code {0 if ok else 1}{RESET}")
    sys.exit(0 if ok else 1)


def cmd_regress(_a) -> None:
    rule("DELIBERATE REGRESSION — dense-only, k=2")
    print(f"{DIM}Swapping the retriever for the Lesson 01 baseline truncated to k=2, then running")
    print(f"the same CI gate. A harness that does not fail here is decoration.{RESET}")
    ds = _load_ds()
    retriever, generator = make_runner(break_retrieval=True)
    rep = ek.Harness(ds, retriever, generator).run()
    ok = rep.assert_no_regression(BASELINE)
    print(f"\n{(GREEN + 'CI would PASS — the harness missed the regression' + RESET) if ok else (GREEN + 'CI would FAIL, correctly — the harness caught it' + RESET)}")
    print(f"{DIM}exit code {0 if ok else 1}{RESET}")


def main() -> None:
    cmds = {"build": cmd_build, "calibrate": cmd_calibrate, "run": cmd_run,
            "ci": cmd_ci, "regress": cmd_regress}
    which = sys.argv[1] if len(sys.argv) > 1 else "run"
    if which not in cmds:
        sys.exit(f"usage: {sys.argv[0]} [{'|'.join(cmds)}]")
    cmds[which](None)


if __name__ == "__main__":
    main()
