"""Lab 17 — Fine-tuning, and why you probably shouldn't. Your diagnostic Q12.

The roadmap's decision order: prompt → few-shot → RAG → routing/decomposition →
THEN fine-tune. This lab does the one fine-tune that is usually worth it, on your
CPU, for free — and measures it honestly on a HELD-OUT split, because training
and testing on the same questions produces a beautiful number that means nothing.

    python 17_fine_tuning.py ladder    # A. the decision ladder, priced
    python 17_fine_tuning.py embed     # B. fine-tune the EMBEDDING model — real training
    python 17_fine_tuning.py distill   # C. distillation: the highest-value case
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import random
import statistics
import sys
import time

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
DATA = HERE.parent / "data"
spec = importlib.util.spec_from_file_location("lab4", HERE / "04_retrieval.py")
lab4 = importlib.util.module_from_spec(spec)
sys.modules["lab4"] = lab4
spec.loader.exec_module(lab4)

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")


def rule(s):
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


# --------------------------------------------------------------------------- #
# A. THE DECISION LADDER
# --------------------------------------------------------------------------- #

def cmd_ladder(_a) -> None:
    rule("A. THE DECISION LADDER — try these first, in this order")
    rungs = [
        ("1. better prompt", "minutes", "$0", "Lesson 07 — output contract moved citations 0.43→1.00"),
        ("2. few-shot examples", "hours", "$0", "Lesson 07 — selection matters more than count"),
        ("3. RAG", "days", "low", "Lessons 01-06 — adds knowledge without training"),
        ("4. better retrieval", "days", "low", "Lesson 04 — +0.17 recall, +0.327 MRR"),
        ("5. routing / decomposition", "days", "negative", "Lesson 16 — small model at 46% of cost"),
        ("6. fine-tune EMBEDDINGS", "hours", "~$0", "section B — often the biggest RAG win"),
        ("7. distillation", "days", "medium", "section C — 10-50x cost cut on a narrow task"),
        ("8. fine-tune the LLM", "weeks", "high", "style, format, latency — RARELY knowledge"),
    ]
    print(f"\n  {'rung':<28} {'time':<9} {'cost':<10} evidence")
    print(f"  {DIM}{'-'*28} {'-'*9} {'-'*10} {'-'*38}{RESET}")
    for n, t, c, e in rungs:
        col = GREEN if n.startswith(("1", "2", "3", "4", "5")) else (
            YELLOW if n.startswith(("6", "7")) else RED)
        print(f"  {col}{n:<28}{RESET} {t:<9} {c:<10} {DIM}{e[:38]}{RESET}")

    print(f"""
{BOLD}Q12 ANSWERED — what fine-tuning reliably buys, and what it does not{RESET}

  {GREEN}BUYS{RESET}
    style and tone consistency         a house voice, reliably
    format adherence                   structured output without a schema
    latency and cost                   via distillation into a smaller model
    narrow classification              beats prompting on a well-defined task
    {BOLD}embedding quality on YOUR jargon{RESET}   section B

  {RED}DOES NOT BUY{RESET}
    {BOLD}knowledge{RESET}                          this is the big one. Facts learned in
                                       training cannot be updated, cited, access-
                                       controlled, or audited — everything RAG
                                       gives you for free (Lesson 01 §2)
    reasoning ability                  a small model fine-tuned on hard problems
                                       is still a small model
    reliability                        it shifts the distribution; it does not
                                       make output deterministic

{DIM}The failure mode this ordering prevents: a team fine-tunes to "teach the model
our documentation", ships it, and discovers they now have an artifact that is
stale on day one, cannot cite a source, cannot be filtered per user, and must be
retrained to fix a typo. That is a knowledge problem solved with a weights
problem.{RESET}""")


# --------------------------------------------------------------------------- #
# B. FINE-TUNE THE EMBEDDING MODEL — real training, on CPU, free
# --------------------------------------------------------------------------- #

def cmd_embed(_a) -> None:
    from sentence_transformers import SentenceTransformer, InputExample, losses
    from torch.utils.data import DataLoader

    rule("B. FINE-TUNING THE EMBEDDING MODEL — real training")
    text = lab4.CORPUS.read_text(encoding="utf-8")
    lab4.check_gold(text)
    chunks = lab4.chunk_recursive(text)
    texts = [c["text"] for c in chunks]

    # ---- the split, and why it is the whole experiment --------------------
    gold = list(lab4.GOLD)
    random.Random(0).shuffle(gold)
    split = int(len(gold) * 0.65)
    train_g, test_g = gold[:split], gold[split:]
    print(f"{DIM}{len(gold)} gold questions → train {len(train_g)} / HELD-OUT TEST {len(test_g)}")
    print(f"Training and testing on the same questions produces a beautiful number that")
    print(f"means nothing — the model can memorise 30 pairs trivially.{RESET}")

    def recall_at(model, subset, k=5):
        V = model.encode(texts, convert_to_numpy=True, normalize_embeddings=True,
                         batch_size=64)
        Q = model.encode([q for q, _, _ in subset], convert_to_numpy=True,
                         normalize_embeddings=True)
        hits = 0
        for i, (_q, _t, ans) in enumerate(subset):
            order = np.argsort(-(V @ Q[i]))[:k]
            hits += any(ans in texts[int(c)] for c in order)
        return hits / len(subset)

    base = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    b_train, b_test = recall_at(base, train_g), recall_at(base, test_g)
    print(f"\n  {'model':<22} {'recall@5 TRAIN':>15} {'recall@5 HELD-OUT':>19}")
    print(f"  {DIM}{'-'*22} {'-'*15} {'-'*19}{RESET}")
    print(f"  {'base MiniLM':<22} {b_train:>15.2f} {b_test:>19.2f}")

    # ---- training set: (question, the chunk that contains the answer) ------
    examples = []
    for q, _t, ans in train_g:
        pos = next((t for t in texts if ans in t), None)
        if pos:
            examples.append(InputExample(texts=[q, pos]))
    print(f"\n{DIM}training on {len(examples)} (query, positive-chunk) pairs …")
    print(f"MultipleNegativesRankingLoss: every OTHER positive in the batch acts as a")
    print(f"negative, so you need no hand-labelled negatives — which is why this is")
    print(f"cheap enough to be worth doing.{RESET}")

    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    loader = DataLoader(examples, shuffle=True, batch_size=8)
    loss = losses.MultipleNegativesRankingLoss(model)
    t0 = time.perf_counter()
    model.fit(train_objectives=[(loader, loss)], epochs=3, warmup_steps=5,
              show_progress_bar=False)
    train_s = time.perf_counter() - t0

    f_train, f_test = recall_at(model, train_g), recall_at(model, test_g)
    tcol = GREEN if f_test > b_test else (YELLOW if f_test == b_test else RED)
    print(f"\n  {'fine-tuned':<22} {f_train:>15.2f} {tcol}{f_test:>19.2f}{RESET}")
    print(f"  {DIM}{'delta':<22} {f_train-b_train:>+15.2f} {f_test-b_test:>+19.2f}{RESET}")

    out = DATA / "ft_minilm"
    model.save(str(out))
    print(f"\n  trained in {train_s:.0f}s on CPU · saved {out}")

    gap = (f_train - b_train) - (f_test - b_test)
    print(f"""
{BOLD}Read the two columns against each other{RESET}
{DIM}  train improvement    {f_train-b_train:+.2f}
  held-out improvement {f_test-b_test:+.2f}
  overfitting gap      {gap:+.2f}

{'A large gap means the model memorised the training questions rather than learning' if gap > 0.1 else 'A small gap means what it learned generalised, at least on this tiny sample.'}
{'anything transferable. That is the number that would have been hidden if I had' if gap > 0.1 else 'With ' + str(len(test_g)) + ' held-out questions one question is worth ' + f'{1/len(test_g):.2f}' + ', so treat this as'}
{'reported "recall went up" from a single train-set evaluation.' if gap > 0.1 else 'directional, not decisive.'}

{BOLD}What this experiment is and is not{RESET}
{DIM}IS:  a real fine-tune. Real gradients, real weights, {train_s:.0f} seconds, $0, on a CPU.
     The cheapest rung on the ladder that involves training at all.
NOT: evidence that fine-tuning "works" in general. {len(examples)} training pairs on a
     30k-character corpus is a toy. On a real corpus you would want thousands of
     (query, positive) pairs — which you get from PRODUCTION LOGS: the queries
     users actually ran, paired with the chunk they clicked or the answer that
     was accepted.

That last point is the practical one. Embedding fine-tuning is cheap because the
training data is a byproduct of running the system, and the labels are free.{RESET}""")


# --------------------------------------------------------------------------- #
# C. DISTILLATION
# --------------------------------------------------------------------------- #

def cmd_distill(_a) -> None:
    rule("C. DISTILLATION — the highest-value fine-tune in practice")
    print(f"""{DIM}Use a frontier model to GENERATE training data, then train a small model to
reproduce its behaviour on a narrow task. You are not teaching knowledge; you are
teaching a policy.{RESET}

{BOLD}The shape{RESET}
  1. define a narrow task           "classify this ticket into one of 8 queues"
  2. run the frontier model on      10k real inputs, keeping its outputs
  3. filter                         drop low-confidence / disagreeing samples
  4. fine-tune a small model        on (input, frontier-output) pairs
  5. evaluate on YOUR harness       Lesson 08 — same gold set, same gates
  6. serve the small model          escalating the hard cases (Lesson 16 routing)
""")

    # Cost model using this course's measured numbers
    reqs = 1_000_000
    big_in, big_out = 900, 86
    frontier = (big_in * 3 + big_out * 15) / 1e6 * reqs
    small = (big_in * 0.8 + big_out * 4) / 1e6 * reqs
    # a distilled task-specific model is typically cheaper still to serve
    distilled = (big_in * 0.2 + big_out * 1.0) / 1e6 * reqs
    train_cost = 10_000 * (big_in * 3 + big_out * 15) / 1e6      # generating 10k samples

    print(f"  {'serving':<32} {'$/day @1M req':>15} {'vs frontier':>12}")
    print(f"  {DIM}{'-'*32} {'-'*15} {'-'*12}{RESET}")
    for name, c in (("frontier model", frontier), ("off-the-shelf small model", small),
                    ("distilled task model", distilled)):
        col = GREEN if c < frontier * 0.5 else DIM
        print(f"  {name:<32} {col}{c:>15,.0f}{RESET} {c/frontier:>11.0%}")
    print(f"\n  {DIM}one-off cost to generate 10k training samples: ${train_cost:,.0f} "
          f"→ pays back in {train_cost/max(1,(frontier-distilled)):.2f} days{RESET}")

    print(f"""
{BOLD}Why this is the case that actually pays{RESET}
{DIM}  * the task is NARROW, so a small model can actually learn it
  * the labels are FREE — a frontier model generated them
  * the win is 10-50x on cost and latency, not 5%
  * you keep the frontier model as an escalation path (Lesson 16)

{BOLD}The costs nobody budgets for{RESET}
{DIM}  * you now OWN a model version. It needs storage, versioning, rollback, and an
    eval gate on every retrain (Lesson 08).
  * CATASTROPHIC FORGETTING — the model gets better at your task and worse at
    everything adjacent. You will not notice unless you evaluate the adjacent
    things too.
  * evaluate BEFORE and AFTER on the same harness, or you cannot tell improvement
    from a distribution shift.
  * the frontier model you distilled from will be superseded, and your distilled
    model will not improve on its own.

{BOLD}Quantisation, briefly{RESET}
{DIM}GPTQ / AWQ / GGUF / FP8 cut serving memory and cost with a quality curve you
must measure — same discipline as Lesson 02's dimension truncation: find where
YOUR metric falls below threshold, then buy the saving.{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for c in ("ladder", "embed", "distill"):
        sub.add_parser(c)
    a = p.parse_args()
    {"ladder": cmd_ladder, "embed": cmd_embed, "distill": cmd_distill}[a.cmd](a)


if __name__ == "__main__":
    main()
