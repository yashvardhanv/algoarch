"""Lab 16 — Observability & cost. Your diagnostic Q14.

"Cut the cost of a chat product by 70% without a meaningful quality drop. What do
you do first?"

This lab does it, measuring each lever on the real system rather than listing
them. It also builds the tracing you need to answer "why did it do that?" six
weeks later, which is the other half of the job.

    python 16_observability_cost.py trace     # A. a replayable trace
    python 16_observability_cost.py routing   # B. cheap model first — measured
    python 16_observability_cost.py levers    # C. the full cost-reduction stack
    python 16_observability_cost.py alerting  # D. what to alert on (not 500s)
"""

from __future__ import annotations

import argparse
import concurrent.futures as cf
import hashlib
import importlib.util
import json
import pathlib
import statistics
import sys
import time
import uuid
from dataclasses import dataclass, field, asdict

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
DATA = HERE.parent / "data"
spec = importlib.util.spec_from_file_location("lab4", HERE / "04_retrieval.py")
lab4 = importlib.util.module_from_spec(spec)
sys.modules["lab4"] = lab4
spec.loader.exec_module(lab4)

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")

# $/Mtok — representative frontier vs small-model pricing
PRICE = {"sonnet": (3.00, 15.00), "haiku": (0.80, 4.00)}


def rule(s):
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


def cost_of(model, pin, pout):
    i, o = PRICE.get(model, PRICE["sonnet"])
    return (pin * i + pout * o) / 1e6


# --------------------------------------------------------------------------- #
# A. TRACING — the span model, and why "log the input" is not enough
# --------------------------------------------------------------------------- #

@dataclass
class Span:
    name: str
    kind: str                      # retrieval | llm | tool | check
    start: float
    end: float = 0.0
    attrs: dict = field(default_factory=dict)

    @property
    def ms(self) -> float:
        return (self.end - self.start) * 1000


@dataclass
class Trace:
    """OpenTelemetry-shaped, deliberately.

    The GenAI semantic conventions name these attributes: gen_ai.system,
    gen_ai.request.model, gen_ai.usage.input_tokens, gen_ai.usage.output_tokens.
    Using the standard names is what lets a vendor dashboard understand your
    spans without custom parsing — the difference between a trace and a log line.
    """
    trace_id: str
    question: str
    spans: list[Span] = field(default_factory=list)
    # the thing people forget: what the model actually SAW
    context_snapshot: list[str] = field(default_factory=list)
    output: str = ""

    def save(self):
        (DATA / "traces").mkdir(parents=True, exist_ok=True)
        p = DATA / "traces" / f"{self.trace_id}.json"
        p.write_text(json.dumps({
            "trace_id": self.trace_id, "question": self.question,
            "spans": [asdict(s) for s in self.spans],
            "context_snapshot": self.context_snapshot, "output": self.output,
        }, indent=2), encoding="utf-8")
        return p

    def total_cost(self):
        return sum(s.attrs.get("cost_usd", 0) for s in self.spans)


def ask(model, system, user):
    import aiconfig
    c = aiconfig.client()
    r = c.chat.completions.create(model=model or aiconfig.MODEL,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
    u = r.usage
    return r.choices[0].message.content.strip(), u.prompt_tokens, u.completion_tokens


SYS = ("Answer using ONLY the numbered context passages. Cite as [1], [2]. "
       "If the passages do not contain the answer, reply exactly: "
       "Not in the provided context. Maximum two sentences.")


def traced_answer(idx, question: str, model=aiconfig.MODEL) -> Trace:
    tr = Trace(trace_id=uuid.uuid4().hex[:12], question=question)

    s = Span("retrieve", "retrieval", time.perf_counter())
    order = lab4.p_hybrid_rerank(idx, question)
    ctx, spent = [], 0
    for ci in order:
        t = idx.texts[int(ci)]
        if spent + len(t) > lab4.BUDGET:
            break
        spent += len(t)
        ctx.append(t)
    s.end = time.perf_counter()
    s.attrs = {"chunk_ids": [int(c) for c in order[:len(ctx)]], "k": len(ctx),
               "context_chars": spent}
    tr.spans.append(s)
    tr.context_snapshot = ctx                      # ← the replayable part

    block = "\n\n".join(f"[{i}] {t.strip()}" for i, t in enumerate(ctx, 1))
    s = Span("generate", "llm", time.perf_counter())
    out, pin, pout = ask(model, SYS, f"Context passages:\n\n{block}\n\nQuestion: {question}")
    s.end = time.perf_counter()
    s.attrs = {"gen_ai.system": "anthropic", "gen_ai.request.model": model,
               "gen_ai.usage.input_tokens": pin, "gen_ai.usage.output_tokens": pout,
               "cost_usd": cost_of(model, pin, pout)}
    tr.spans.append(s)
    tr.output = out
    return tr


def cmd_trace(_a) -> None:
    rule("A. A REPLAYABLE TRACE")
    idx = lab4.Index(lab4.chunk_recursive(lab4.CORPUS.read_text(encoding="utf-8")))
    tr = traced_answer(idx, "What is the highest-ROI upgrade to a mediocre RAG system?")
    p = tr.save()

    print(f"\n  trace {tr.trace_id}")
    print(f"  {'span':<12} {'kind':<10} {'ms':>8}  attributes")
    print(f"  {DIM}{'-'*12} {'-'*10} {'-'*8}  {'-'*40}{RESET}")
    for s in tr.spans:
        keys = {k: v for k, v in s.attrs.items() if k != "chunk_ids"}
        print(f"  {s.name:<12} {s.kind:<10} {s.ms:>8.0f}  {DIM}{json.dumps(keys)[:52]}{RESET}")
    print(f"\n  total ${tr.total_cost():.5f} · context {len(tr.context_snapshot)} passages")
    print(f"  saved {p}")

    print(f"""
{BOLD}Why the context snapshot is the whole point{RESET}
{DIM}Six weeks from now someone asks "why did it say that?". The question is
answerable ONLY if you stored what the model SAW — not the question, not the
answer, not the chunk IDs. Chunk IDs are useless after a re-chunk (Lesson 03),
and re-running retrieval today gives you today's index, not the one that produced
the answer.

  log the input           → you can reproduce the request
  log the output          → you can see what happened
  {BOLD}log the CONTEXT{RESET}{DIM}         → you can explain WHY, which is the actual question

Use the OpenTelemetry GenAI attribute names — gen_ai.request.model,
gen_ai.usage.input_tokens — so a dashboard understands your spans without custom
parsing. That is the difference between a trace and a log line.{RESET}""")


# --------------------------------------------------------------------------- #
# B. MODEL ROUTING — measured, not asserted
# --------------------------------------------------------------------------- #

def cmd_routing(_a) -> None:
    rule("B. CHEAP MODEL FIRST — routing, measured")
    idx = lab4.Index(lab4.chunk_recursive(lab4.CORPUS.read_text(encoding="utf-8")))
    subset = lab4.GOLD[:16]
    print(f"{DIM}Same {len(subset)} questions through a frontier model and a small one.")
    print(f"Correct = the gold fact appears in the answer.{RESET}\n")

    def run(model):
        def one(item):
            q, _tag, ans = item
            tr = traced_answer(idx, q, model=model)
            key = " ".join(ans.split()[:4]).lower().strip("*")
            return {"q": q, "ok": key in tr.output.lower(), "cost": tr.total_cost(),
                    "ms": sum(s.ms for s in tr.spans)}
        with cf.ThreadPoolExecutor(max_workers=4) as ex:
            return list(ex.map(one, subset))

    print(f"{DIM}running sonnet …{RESET}")
    big = run("sonnet")
    print(f"{DIM}running haiku …{RESET}")
    small = run("haiku")

    def agg(rows):
        return (sum(r["ok"] for r in rows) / len(rows), sum(r["cost"] for r in rows),
                statistics.median(r["ms"] for r in rows))

    ba, bc, bm = agg(big)
    sa, sc, sm = agg(small)
    print(f"\n  {'model':<10} {'accuracy':>9} {'cost/16q':>10} {'p50 ms':>8}")
    print(f"  {DIM}{'-'*10} {'-'*9} {'-'*10} {'-'*8}{RESET}")
    print(f"  {'sonnet':<10} {ba:>9.2f} ${bc:>9.4f} {bm:>8.0f}")
    print(f"  {'haiku':<10} {sa:>9.2f} ${sc:>9.4f} {sm:>8.0f}")

    # cascade: haiku first; escalate when it refuses or omits a citation
    esc = [i for i, r in enumerate(small) if not r["ok"]]
    casc_cost = sc + sum(big[i]["cost"] for i in esc)
    casc_acc = sum(1 for i, r in enumerate(small) if r["ok"] or big[i]["ok"]) / len(subset)
    print(f"  {'cascade':<10} {casc_acc:>9.2f} ${casc_cost:>9.4f} {DIM}(escalated {len(esc)}/{len(subset)}){RESET}")

    print(f"""
{BOLD}Reading it{RESET}
  small model alone   {sa:.0%} of frontier accuracy at {sc/max(bc,1e-9):.0%} of the cost
  cascade             {casc_acc:.0%} accuracy at {casc_cost/max(bc,1e-9):.0%} of the cost

{YELLOW}READ THE CASCADE ROW AS AN UPPER BOUND, NOT A RESULT.{RESET}
{DIM}It scored {casc_acc:.2f} — HIGHER than the frontier model alone ({ba:.2f}) — which should
immediately look wrong. It is: my router escalates exactly the {len(esc)} questions the
small model got wrong, which it knows because it peeked at the gold label. That
is an ORACLE router, and an oracle router is not a thing you can deploy.

What the row legitimately shows is the ceiling: if your router were perfect, you
could have {casc_acc:.0%} accuracy at {casc_cost/max(bc,1e-9):.0%} of frontier cost. Your real router will land
somewhere below that, and the gap between the two IS the router's quality.

THE ROUTER IS THE HARD PART. In production you route on a signal available at
request time — retrieval score spread (Lesson 01), a cheap classifier,
output-schema validity, or an explicit "I'm not sure" from the small model —
and you measure its escalation rate and its false-negative rate like any other
classifier (Lesson 05).

A router that escalates everything costs MORE than the frontier model alone,
because you paid twice. Measure your escalation rate before you ship it.{RESET}""")


# --------------------------------------------------------------------------- #
# C. THE COST-REDUCTION STACK — Q14 answered
# --------------------------------------------------------------------------- #

def cmd_levers(_a) -> None:
    rule("C. CUT COST 70% — Q14, with measured inputs")
    # Baseline from this course's own measurements
    base_in, base_out = 1731, 780          # Lesson 01 §12
    reqs = 1_000_000
    pin, pout = PRICE["sonnet"]

    def daily(i, o, model=aiconfig.MODEL, cached=0):
        pi, po = PRICE[model]
        billed_in = cached * 0.10 + (i - cached)
        return (billed_in * pi + o * po) / 1e6 * reqs

    base = daily(base_in, base_out)
    levers = [
        ("baseline", base_in, base_out, "sonnet", 0, "Lesson 01 measurements"),
        ("+ output cap (3 sentences)", base_in, 86, "sonnet", 0, "Lesson 07: 630→86 out tokens"),
        ("+ prefix caching (static first)", base_in, 86, "sonnet", 1000, "Lesson 09: ~60% of input cached"),
        ("+ rerank, drop k 8→4", 900, 86, "sonnet", 700, "Lesson 04: rerank beats raising k"),
        ("+ cascade to small model", 900, 86, "haiku", 700, "section B, for the easy 70%"),
    ]
    print(f"\n{DIM}1M requests/day. Each row ADDS to the one above it.{RESET}\n")
    print(f"  {'lever':<34} {'in':>6} {'out':>5} {'$/day':>10} {'cum. saving':>12}  source")
    print(f"  {DIM}{'-'*34} {'-'*6} {'-'*5} {'-'*10} {'-'*12}  {'-'*24}{RESET}")
    for name, i, o, m, c, src in levers:
        d = daily(i, o, m, c)
        save = 1 - d / base
        col = GREEN if save >= 0.7 else (YELLOW if save > 0 else DIM)
        print(f"  {name:<34} {i:>6} {o:>5} {d:>10,.0f} {col}{save:>11.0%}{RESET}  {DIM}{src[:24]}{RESET}")

    final = daily(*levers[-1][1:3], levers[-1][3], levers[-1][4])
    print(f"""
{BOLD}Q14 ANSWERED — {1-final/base:.0%} reduction, and the order matters{RESET}
{DIM}What you do FIRST is not "switch to a cheaper model". It is:

  1. {BOLD}CAP THE OUTPUT.{RESET}{DIM} Output tokens cost 5x input and dominate latency
     (Lesson 09). Lesson 07 measured a prompt change taking output from 630 to 86
     tokens with no accuracy loss — it was the single biggest lever in this course
     and it is one line of instruction.
  2. {BOLD}RESTRUCTURE FOR PREFIX CACHING.{RESET}{DIM} Static content first. Free, structural,
     and Lesson 09 measured a timestamp in the wrong place costing 61%.
  3. {BOLD}RERANK INSTEAD OF RAISING k.{RESET}{DIM} Lesson 04: reranking is the only lever that
     improves quality WITHOUT inflating the prompt.
  4. {BOLD}THEN{RESET}{DIM} consider a cheaper model, behind a router you have measured.

Every one of those is measured elsewhere in this course. Note what is NOT on the
list: a smaller embedding model (Lesson 02 — embeddings are already local and
free here), or fine-tuning (Lesson 17 — expensive, slow, and rarely the cost
lever people expect).

Two more worth knowing:
  SEMANTIC CACHING   cache by embedding proximity with a staleness policy. On
                     support-style traffic where queries repeat, this is enormous
                     — and it inherits the ACL of whatever context produced it
                     (Lesson 06), so never share entries across permission
                     boundaries.
  BATCH API          ~50% cheaper for anything non-interactive. If a human is not
                     waiting, you are overpaying by default.{RESET}""")


# --------------------------------------------------------------------------- #
# D. ALERTING
# --------------------------------------------------------------------------- #

def cmd_alerting(_a) -> None:
    rule("D. WHAT TO ALERT ON — the scary failure is 200 OK")
    print(f"""{DIM}A non-deterministic system fails by being confidently wrong at HTTP 200. Your
existing alerting — 500s, latency, saturation — cannot see that.{RESET}""")

    signals = [
        ("500 rate", "no", "traditional monitoring already has it"),
        ("p99 latency", "no", "same"),
        ("groundedness on sampled traffic", "YES", "Lesson 06 — quality drift, not errors"),
        ("citation validity rate", "YES", "Lesson 06 — free, deterministic, 100% of traffic"),
        ("refusal rate", "YES", "a spike means retrieval broke; a drop means the hatch broke"),
        ("retrieval score spread", "YES", "Lesson 01 — flat spread = low-confidence retrieval"),
        ("cache hit rate", "YES", "Lesson 09 — a broken cache looks like organic growth"),
        ("cost per COMPLETED task", "YES", "Lesson 10 — not cost per call"),
        ("stop-reason distribution", "YES", "Lesson 10 — budget/loop/cap vs finished"),
        ("eval score on golden set in CI", "YES", "Lesson 08 — blocks the merge"),
        ("judge/human agreement (kappa)", "YES", "Lesson 05 — the judge itself drifts"),
    ]
    print(f"\n  {'signal':<36} {'alert?':<7} why")
    print(f"  {DIM}{'-'*36} {'-'*7} {'-'*34}{RESET}")
    for name, a, why in signals:
        col = GREEN if a == "YES" else DIM
        print(f"  {name:<36} {col}{a:<7}{RESET} {DIM}{why[:34]}{RESET}")

    print(f"""
{BOLD}The incident-response question{RESET}
{DIM}"What's the rollback when the MODEL is the bug?" You need to be able to pin:
  * the prompt version        (Lesson 07 — prompts in git, with eval results)
  * the model version         (a provider-side upgrade is a deploy you did not do)
  * the index version         (Lesson 03 — a re-chunk changes every answer)
  * the retrieval config      (k, rerank depth, filters)

If any of those is "latest", you cannot roll back — you can only wait. Pin them,
and treat a model upgrade like a schema migration: shadow, canary, compare on the
golden set, then cut over.{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for c in ("trace", "routing", "levers", "alerting"):
        sub.add_parser(c)
    a = p.parse_args()
    {"trace": cmd_trace, "routing": cmd_routing,
     "levers": cmd_levers, "alerting": cmd_alerting}[a.cmd](a)


if __name__ == "__main__":
    main()
