"""Lab 09 — Model behaviour: sampling, caching, context, determinism.

Repairs diagnostic Q7 (prefix caching) and Q8 (temperature).

AN HONEST NOTE ON METHOD. The claude-shim from Lesson 00 exposes no temperature
and no prompt caching — the CLI has neither knob. Rather than assert how they
behave, this lab:

  * IMPLEMENTS sampling from scratch over REAL next-token distributions built
    from the roadmap corpus, so you can see exactly what temperature/top-k/top-p
    do to a probability vector                                    (exact, free)
  * SIMULATES prefix-cache economics as arithmetic over prompt structure, and
    states plainly that it is arithmetic                          (exact, free)
  * MEASURES what the shim can actually show: latency vs input length, and
    output determinism across repeated identical calls            (real API)

    python 09_model_behaviour.py sampling     # A. temperature/top-k/top-p, from scratch
    python 09_model_behaviour.py determinism  # B. same prompt N times — how stable?
    python 09_model_behaviour.py cache        # C. prefix caching economics (Q7)
    python 09_model_behaviour.py context      # D. latency vs input length
"""

from __future__ import annotations

import argparse
import collections
import importlib.util
import math
import pathlib
import re
import statistics
import sys
import time

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
spec = importlib.util.spec_from_file_location("lab4", HERE / "04_retrieval.py")
lab4 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab4)

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")


def rule(s):
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


def ask(system, user, model=aiconfig.MODEL):
    import aiconfig
    c = aiconfig.client()
    r = c.chat.completions.create(
        model=model or aiconfig.MODEL,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
    return r.choices[0].message.content.strip(), r.usage


# =========================================================================== #
# A. SAMPLING, IMPLEMENTED
# =========================================================================== #

def build_bigram(text: str) -> dict[str, collections.Counter]:
    """A real (tiny) language model from the corpus, so the distributions below
    are measured rather than invented."""
    words = re.findall(r"[a-z']+", text.lower())
    m: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
    for a, b in zip(words, words[1:]):
        m[a][b] += 1
    return m


def softmax(logits: np.ndarray, temp: float) -> np.ndarray:
    if temp <= 0:                        # temperature 0 = argmax, deterministic
        p = np.zeros_like(logits)
        p[int(np.argmax(logits))] = 1.0
        return p
    z = logits / temp
    z = z - z.max()
    e = np.exp(z)
    return e / e.sum()


def top_k_filter(p: np.ndarray, k: int) -> np.ndarray:
    if k <= 0 or k >= len(p):
        return p
    out = np.zeros_like(p)
    idx = np.argsort(-p)[:k]
    out[idx] = p[idx]
    return out / out.sum()


def top_p_filter(p: np.ndarray, top_p: float) -> np.ndarray:
    """Nucleus sampling: keep the smallest set whose cumulative mass ≥ top_p.

    The key property, and the reason it usually beats top-k: the size of the
    kept set ADAPTS to how confident the model is. On a peaked distribution it
    keeps 1-2 tokens; on a flat one it keeps many. top-k keeps k either way,
    which is too many when the model is sure and too few when it isn't.
    """
    if top_p >= 1.0:
        return p
    order = np.argsort(-p)
    cum = np.cumsum(p[order])
    cut = int(np.searchsorted(cum, top_p) + 1)
    out = np.zeros_like(p)
    out[order[:cut]] = p[order[:cut]]
    return out / out.sum()


def entropy(p: np.ndarray) -> float:
    q = p[p > 0]
    return abs(float(-(q * np.log2(q)).sum()))   # abs() kills -0.00 at temp 0


def cmd_sampling(_a) -> None:
    text = lab4.CORPUS.read_text(encoding="utf-8")
    bg = build_bigram(text)
    rule("A. SAMPLING — implemented over real corpus distributions")
    print(f"{DIM}A bigram model over {lab4.CORPUS.name}. Not a transformer, but the next-token")
    print(f"distribution is REAL, and temperature/top-k/top-p do exactly the same arithmetic")
    print(f"to it that they do inside a frontier model's sampler.{RESET}")

    for word in ("retrieval", "the"):
        counts = bg[word]
        toks = [t for t, _ in counts.most_common(12)]
        c = np.array([counts[t] for t in toks], dtype=float)
        logits = np.log(c)                     # counts -> logits
        base = softmax(logits, 1.0)

        print(f"\n{BOLD}next token after {word!r}{RESET}  "
              f"{DIM}({len(counts)} distinct continuations, showing top 12){RESET}")
        print(f"  {'temp':>5} {'entropy':>8} {'top-1 p':>8}  distribution")
        print(f"  {DIM}{'-'*5} {'-'*8} {'-'*8}  {'-'*44}{RESET}")
        for t in (0.0, 0.2, 0.7, 1.0, 1.5, 2.0):
            p = softmax(logits, t)
            bar = "".join("█" if x > .25 else "▓" if x > .12 else "▒" if x > .04 else "·"
                          for x in p)
            col = GREEN if t <= 0.2 else (YELLOW if t <= 1.0 else RED)
            print(f"  {col}{t:>5.1f}{RESET} {entropy(p):>8.2f} {p.max():>8.3f}  {bar}")
        print(f"  {DIM}tokens: {' '.join(t[:7] for t in toks[:8])}{RESET}")

    # top-k vs top-p on a peaked vs a flat distribution
    print(f"\n{BOLD}top-k vs top-p — why nucleus adapts and k doesn't{RESET}")
    print(f"  {'distribution':<20} {'top-k=5':>10} {'top-p=0.9 keeps':>17}")
    print(f"  {DIM}{'-'*20} {'-'*10} {'-'*17}{RESET}")
    for name, w in (("peaked", "reciprocal"), ("flat", "the")):
        counts = bg[w] if bg[w] else bg["the"]
        toks = [t for t, _ in counts.most_common(40)]
        p = softmax(np.log(np.array([counts[t] for t in toks], dtype=float)), 1.0)
        k_keep = min(5, len(p))
        p_keep = int((top_p_filter(p, 0.9) > 0).sum())
        print(f"  {name + ' (' + w + ')':<20} {k_keep:>10} {p_keep:>17}")

    print(f"""
{BOLD}Q8 answered — why temperature=0 for extraction, not for drafting{RESET}
{DIM}At temp 0 the sampler is argmax: same input -> same output, every time. That is
what you want when the output feeds CODE — extraction, classification, routing,
tool arguments — because a pipeline that returns a different field name on Tuesday
is undebuggable, and any variation is pure downside.

At temp ~0.7-1.0 the distribution stays wide enough to pick the less-likely-but-
better continuation. That is what you want when a human reads the output and
"technically correct but wooden" is a real cost: drafting, brainstorming,
rewriting.

WHAT YOU SAID IN THE DIAGNOSTIC, corrected: you suggested RAISING temperature to
stop an agent looping. It doesn't work that way. Temperature adds variance, not
judgement — a looping agent at temp 1.2 takes a random walk through the same dead
end. The fixes are structural: a step budget, a loop detector on repeated
(action, args), and a cost cap. That is Lesson 10.

  temp 0        extraction · classification · routing · tool args · SQL
  temp 0.7-1.0  drafting · summarising for humans · ideation
  top-p 0.9     the sane default when you do sample; adapts to model confidence
  top-k         blunter; keeps k candidates whether or not the model is sure{RESET}""")


# =========================================================================== #
# B. DETERMINISM
# =========================================================================== #

def cmd_determinism(_a) -> None:
    rule("B. DETERMINISM — the same prompt, ten times")
    print(f"""{DIM}claude-shim exposes no temperature, so this measures the DEFAULT sampling
behaviour you actually get. Two prompts: one with a single correct short answer,
one open-ended.{RESET}""")

    probes = [
        ("closed", "Reply with only the number.", "What is 17 * 23?"),
        ("open", "Answer in one sentence.", "Why does hybrid search beat dense-only retrieval?"),
    ]
    N = 10
    for kind, sysmsg, q in probes:
        outs = []
        for _ in range(N):
            o, _ = ask(sysmsg, q)
            outs.append(" ".join(o.split()))
        uniq = collections.Counter(outs)
        most, cnt = uniq.most_common(1)[0]
        col = GREEN if len(uniq) == 1 else (YELLOW if len(uniq) <= 3 else RED)
        print(f"\n{BOLD}{kind}{RESET}  {q}")
        print(f"  distinct outputs: {col}{len(uniq)}/{N}{RESET}  modal answer seen {cnt}x")
        for text, c in uniq.most_common(3):
            print(f"    {c}x  {DIM}{text[:76]}{RESET}")

    print(f"""
{DIM}Two operational consequences:

1. YOUR EVAL IS NOISY EVEN AT FIXED CONFIGURATION. Lesson 07 measured a 0.14
   run-to-run spread; this is where it comes from. Any A/B smaller than that
   spread needs repeats, not opinions.
2. CACHING AND REPLAY. If the same input can produce different output, "why did
   it do that?" requires logging the OUTPUT, not just the input. Lesson 06's
   audit trail is not optional for a stochastic system.

Note also: closed-form questions collapse to near-determinism on their own,
because the distribution is peaked — the model does not need temperature 0 to be
stable when it is certain. Temperature 0 matters when the model ISN'T.{RESET}""")


# =========================================================================== #
# C. PREFIX CACHING (Q7)
# =========================================================================== #

def cmd_cache(_a) -> None:
    rule("C. PREFIX CACHING — Q7 answered")
    print(f"""{DIM}THIS SECTION IS ARITHMETIC, NOT A MEASUREMENT. The shim spawns a fresh
process per request so there is no cache to observe. The mechanism and the
economics are exact anyway, and they are what the question was about.{RESET}""")

    print(f"""
{BOLD}The mechanism{RESET}
{DIM}A transformer computes, for every token, a key and value vector used by
attention. For a fixed prefix those vectors are IDENTICAL on every request — the
same 2,000-token system prompt produces the same KV entries whether it is call 1
or call 100,000. The KV CACHE stores them so the prefix is not recomputed.

Prefix caching exposes that to you across requests: the provider hashes the
leading tokens of your prompt, and if it matches a cached entry you are billed a
small fraction (typically ~10%) for that span and skip the compute.

The rule that falls out — and this is the whole answer to Q7:

  {BOLD}STATIC CONTENT AT THE FRONT. VOLATILE CONTENT AT THE BACK.{RESET}{DIM}

Because the cache matches a PREFIX, one changed byte near the start invalidates
everything after it. Put the timestamp at the top of your system prompt and you
have a 0% hit rate forever, silently.{RESET}""")

    # economics
    SYS, FEWSHOT, RETRIEVED, QUESTION = 800, 1200, 900, 60
    PRICE, CACHE_MULT = 3.00 / 1e6, 0.10
    layouts = [
        ("cache-friendly  [sys][fewshot] | [retrieved][question]", SYS + FEWSHOT),
        ("half-cached     [sys] | [fewshot][retrieved][question]", SYS),
        ("timestamp first [ts][sys][fewshot][retrieved][question]", 0),
    ]
    total = SYS + FEWSHOT + RETRIEVED + QUESTION
    print(f"\n{BOLD}Economics — {total:,} input tokens, 1M requests/day, ${PRICE*1e6:.2f}/Mtok{RESET}")
    print(f"\n  {'prompt layout':<56} {'cached':>7} {'$/day':>10} {'saved':>8}")
    print(f"  {DIM}{'-'*56} {'-'*7} {'-'*10} {'-'*8}{RESET}")
    base = None
    for label, cached in layouts:
        billed = cached * CACHE_MULT + (total - cached)
        cost = billed * 1e6 * PRICE
        if base is None:
            base = cost
        col = GREEN if cached > 1500 else (YELLOW if cached else RED)
        print(f"  {label:<56} {col}{cached:>7}{RESET} {cost:>10,.0f} "
              f"{(1 - cost/ (total*1e6*PRICE)) * 100:>7.0f}%")

    print(f"""
{DIM}The third row is not hypothetical. "Let's add the current time to the system
prompt so it knows the date" is a one-line change that silently costs the
difference between row 1 and row 3 — here about ${(total*1e6*PRICE) - ((SYS+FEWSHOT)*CACHE_MULT + (total-SYS-FEWSHOT))*1e6*PRICE:,.0f}/day — with no error,
no alert, and no visible symptom other than the bill.

What breaks a prefix cache, in order of how often it happens:
  * a timestamp, request id, or user name near the top of the prompt
  * retrieved context placed BEFORE the static instructions
  * per-user personalisation in the system prompt instead of the user turn
  * randomly ordered few-shot examples
  * any A/B test that varies the system prompt per request

How to check you actually have it: log cached vs uncached input tokens per
request and alert on hit rate, not just cost. A cache that quietly stops working
looks exactly like organic growth.{RESET}""")


# =========================================================================== #
# D. CONTEXT LENGTH vs LATENCY
# =========================================================================== #

def cmd_context(_a) -> None:
    text = lab4.CORPUS.read_text(encoding="utf-8")
    rule("D. CONTEXT LENGTH vs LATENCY — measured")
    print(f"{DIM}Same question, same model, growing amounts of irrelevant context in front of it.{RESET}")

    q = "What is the highest-ROI single upgrade to a mediocre RAG system?"
    sizes = [0, 2000, 6000, 14000, 30000]
    print(f"\n  {'ctx chars':>10} {'input tok':>10} {'latency':>9} {'correct':>8} {'ms/1k tok':>10}")
    print(f"  {DIM}{'-'*10} {'-'*10} {'-'*9} {'-'*8} {'-'*10}{RESET}")
    rows = []
    for n in sizes:
        pad = text[:n]
        prompt = (f"Reference material:\n{pad}\n\n" if n else "") + f"Question: {q}"
        t0 = time.perf_counter()
        out, usage = ask("Answer in one sentence using the reference material if relevant.", prompt)
        dt = time.perf_counter() - t0
        ok = "rerank" in out.lower()
        rows.append((n, usage.prompt_tokens, dt, ok))
        col = GREEN if ok else RED
        print(f"  {n:>10,} {usage.prompt_tokens:>10,} {dt:>8.1f}s {col}{str(ok):>8}{RESET} "
              f"{dt*1000/max(1,usage.prompt_tokens/1000):>10.0f}")

    first, last = rows[0], rows[-1]
    growth = last[2] / max(0.01, first[2])
    tokgrowth = last[1] / max(1, first[1])
    lat = [r[2] for r in rows]
    spread = max(lat) - min(lat)
    print(f"""
{BOLD}{tokgrowth:.0f}x the input tokens → {growth:.1f}x the latency (spread across all sizes: {spread:.1f}s){RESET}
{YELLOW}Read that carefully: latency did NOT grow. It is flat inside the noise.{RESET}
{DIM}n=1 per row, so treat the individual numbers as indicative — but a 55x increase
in input producing no visible latency cost is not a subtle effect, and it is the
opposite of most people's intuition.

The reason is that PREFILL IS MASSIVELY PARALLEL: the model processes the whole
prompt in one forward pass, whereas generation is sequential — one forward pass
per output token. So input length is cheap in TIME and expensive in MONEY, while
output length is expensive in both. That is why:

  * OUTPUT length dominates latency, not input length. Lesson 07 measured a
    prompt that cut output 630 -> 86 tokens; that is the bigger latency lever.
  * TTFT (time to first token) tracks input; total time tracks output. Report
    both, because a user feels TTFT and your bill feels total tokens.
  * "effective context" is not "advertised context". Everything you add competes
    for attention and for your budget, and Lesson 06 showed 6.7x the tokens
    buying identical answers.{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for c in ("sampling", "determinism", "cache", "context"):
        sub.add_parser(c)
    a = p.parse_args()
    {"sampling": cmd_sampling, "determinism": cmd_determinism,
     "cache": cmd_cache, "context": cmd_context}[a.cmd](a)


if __name__ == "__main__":
    main()
