"""Lab 10 — The agent loop, in ~200 lines, with the controls that make it safe.

The roadmap: "Read the source of one agent framework end to end. Then write a
minimal agent loop yourself in ~200 lines. You'll understand the abstractions
properly and stop being framework-dependent."

An agent is a loop:  model decides -> tool runs -> model observes -> repeat.
Everything hard about agents is CONTROLLING THAT LOOP. This file is the loop plus
the five controls, and then it deliberately breaks each one so you can watch the
failure it prevents.

NOTE ON METHOD: claude-shim has no tool-calling API (Lesson 00 documents the
gap), so the loop uses a STRUCTURED-OUTPUT protocol instead — the model returns
{thought, action, args} validated against a JSON schema. This is the better
teaching artifact anyway: nothing is hidden inside a provider's tool runtime.

    python 10_agent_loop.py run "how many chunks mention reranking?"
    python 10_agent_loop.py controls    # each control, removed, and the failure it lets through
    python 10_agent_loop.py failures    # the failure-mode catalogue, measured
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import re
import sys
import time
from dataclasses import dataclass, field

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
spec = importlib.util.spec_from_file_location("lab4", HERE / "04_retrieval.py")
lab4 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab4)

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")


def rule(s):
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


# --------------------------------------------------------------------------- #
# TOOLS — few, well-named, orthogonal, returning COMPACT structured results
# --------------------------------------------------------------------------- #

_IDX = None


def _idx():
    global _IDX
    if _IDX is None:
        _IDX = lab4.Index(lab4.chunk_recursive(lab4.CORPUS.read_text(encoding="utf-8")))
    return _IDX


def tool_search(query: str, k: int = 3) -> dict:
    """Search the corpus. Returns compact hits, never raw dumps."""
    idx = _idx()
    order = lab4.p_hybrid_rerank(idx, query)[:k]
    return {"hits": [{"id": int(i), "text": " ".join(idx.texts[int(i)].split())[:220]}
                     for i in order]}


def tool_count(pattern: str) -> dict:
    """Count chunks containing a literal string (case-insensitive)."""
    idx = _idx()
    n = sum(1 for t in idx.texts if pattern.lower() in t.lower())
    return {"pattern": pattern, "matching_chunks": n, "total_chunks": len(idx.texts)}

def tool_calc(expression: str) -> dict:
    """Arithmetic only. Note what this does NOT do: eval().

    Lesson 06's rule — model output is untrusted input — applies to tool
    arguments too. `eval()` on an LLM-authored string is a remote code execution
    primitive you handed to a text generator.
    """
    if not re.fullmatch(r"[0-9\.\s\+\-\*/\(\)%]+", expression or ""):
        return {"error": "expression contains characters outside [0-9 . + - * / ( ) %]"}
    try:
        return {"expression": expression, "result": eval(expression, {"__builtins__": {}}, {})}
    except Exception as e:  # noqa: BLE001
        return {"error": f"{type(e).__name__}: {e}"}


def tool_write_note(text: str) -> dict:
    """An IRREVERSIBLE-ish action, used to demonstrate approval gates."""
    p = HERE.parent / "data" / "agent_note.txt"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    return {"wrote": str(p), "bytes": len(text)}


TOOLS = {
    "search": {"fn": tool_search, "args": ["query"], "danger": False,
               "desc": "Search the AI engineering roadmap. args: {query: string}"},
    "count": {"fn": tool_count, "args": ["pattern"], "danger": False,
              "desc": "Count corpus chunks containing a literal string. args: {pattern: string}"},
    "calc": {"fn": tool_calc, "args": ["expression"], "danger": False,
             "desc": "Evaluate arithmetic. args: {expression: string}"},
    "write_note": {"fn": tool_write_note, "args": ["text"], "danger": True,
                   "desc": "Write a note to disk. IRREVERSIBLE. args: {text: string}"},
    "finish": {"fn": None, "args": ["answer"], "danger": False,
               "desc": "Return the final answer and stop. args: {answer: string}"},
}

ACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "thought": {"type": "string", "description": "one sentence of reasoning"},
        "action": {"type": "string", "enum": list(TOOLS)},
        "args": {"type": "object"},
    },
    "required": ["thought", "action", "args"],
}

SYSTEM = """You are an agent that answers questions about an AI engineering roadmap.

Each turn, choose exactly ONE action and return it as JSON.

Available actions:
""" + "\n".join(f"  {n}: {t['desc']}" for n, t in TOOLS.items()) + """

Rules:
- Use `search` to find relevant text before answering.
- Use `count` for "how many" questions — do not estimate from search results.
- When you have the answer, use `finish`.
- Do not repeat an action with identical arguments; if a result was unhelpful,
  change the arguments or choose a different action.
"""


# --------------------------------------------------------------------------- #
# THE LOOP
# --------------------------------------------------------------------------- #

@dataclass
class Limits:
    """The five controls. Every one exists because of a specific failure."""
    max_steps: int = 8              # goal drift / infinite loop
    max_cost_usd: float = 0.50      # cost explosion from retry storms
    loop_detect: bool = True        # repeated (action, args) = stuck
    approve_dangerous: bool = True  # human gate on irreversible actions
    max_tool_errors: int = 3        # error cascade


@dataclass
class Trace:
    steps: list[dict] = field(default_factory=list)
    stopped: str = ""
    answer: str | None = None
    cost: float = 0.0
    tool_errors: int = 0


def call_model(messages: list[dict]) -> tuple[dict, float]:
    import aiconfig
    c = aiconfig.client()
    r = c.chat.completions.create(
        model=aiconfig.MODEL, messages=messages,
        response_format={"type": "json_schema",
                         "json_schema": {"name": "action", "schema": ACTION_SCHEMA}})
    # crude cost estimate; the shim reports real usage
    u = r.usage
    cost = (u.prompt_tokens * 3.0 + u.completion_tokens * 15.0) / 1e6
    try:
        return json.loads(r.choices[0].message.content), cost
    except ValueError:
        return {"thought": "unparseable", "action": "finish",
                "args": {"answer": "internal error: model returned invalid JSON"}}, cost


def run_agent(question: str, limits: Limits, *, auto_approve=False, verbose=True) -> Trace:
    tr = Trace()
    messages = [{"role": "system", "content": SYSTEM},
                {"role": "user", "content": f"Question: {question}"}]
    seen: set[str] = set()

    for step in range(1, limits.max_steps + 2):          # +1 so we can OVERRUN and be caught
        if step > limits.max_steps:
            tr.stopped = f"step budget exhausted ({limits.max_steps})"
            break
        if tr.cost > limits.max_cost_usd:
            tr.stopped = f"cost cap exceeded (${tr.cost:.3f} > ${limits.max_cost_usd})"
            break
        if tr.tool_errors >= limits.max_tool_errors:
            tr.stopped = f"too many tool errors ({tr.tool_errors})"
            break

        act, cost = call_model(messages)
        tr.cost += cost
        name = act.get("action", "")
        args = act.get("args", {}) or {}
        sig = json.dumps({"a": name, "g": args}, sort_keys=True)

        if verbose:
            print(f"  {DIM}step {step}{RESET} {BOLD}{name}{RESET}"
                  f"({', '.join(f'{k}={str(v)[:34]!r}' for k, v in args.items())})")
            print(f"         {DIM}{act.get('thought','')[:88]}{RESET}")

        if limits.loop_detect and sig in seen:
            tr.stopped = f"loop detected — repeated {name} with identical args"
            tr.steps.append({"step": step, "action": name, "args": args, "result": "LOOP"})
            break
        seen.add(sig)

        if name == "finish":
            tr.answer = args.get("answer", "")
            tr.stopped = "finished"
            tr.steps.append({"step": step, "action": name, "args": args, "result": "done"})
            break

        spec_ = TOOLS.get(name)
        if not spec_:
            # TOOL HALLUCINATION. The error message is written FOR THE MODEL to
            # recover from — it names the valid options rather than saying "error".
            obs = {"error": f"unknown action {name!r}. Valid actions: {', '.join(TOOLS)}"}
            tr.tool_errors += 1
        elif spec_["danger"] and limits.approve_dangerous and not auto_approve:
            obs = {"blocked": "this action is irreversible and requires human approval; "
                              "it was NOT executed"}
            if verbose:
                print(f"         {YELLOW}APPROVAL GATE — blocked{RESET}")
        else:
            try:
                obs = spec_["fn"](**{k: args.get(k) for k in spec_["args"]})
                if "error" in obs:
                    tr.tool_errors += 1
            except Exception as e:  # noqa: BLE001
                obs = {"error": f"{type(e).__name__}: {e}"}
                tr.tool_errors += 1

        tr.steps.append({"step": step, "action": name, "args": args, "result": obs})
        messages.append({"role": "assistant", "content": json.dumps(act)})
        messages.append({"role": "user", "content": f"Observation: {json.dumps(obs)[:1200]}"})

    if not tr.stopped:
        tr.stopped = "loop ended"
    return tr


def show(tr: Trace) -> None:
    col = GREEN if tr.stopped == "finished" else YELLOW
    print(f"  {col}stopped: {tr.stopped}{RESET}  ·  {len(tr.steps)} steps  ·  ${tr.cost:.4f}")
    if tr.answer:
        print(f"  {BOLD}answer:{RESET} {' '.join(tr.answer.split())[:150]}")


# --------------------------------------------------------------------------- #

def cmd_run(a) -> None:
    rule("AGENT RUN")
    print(f"question: {a.question}\n")
    tr = run_agent(a.question, Limits())
    show(tr)


def cmd_controls(_a) -> None:
    rule("THE FIVE CONTROLS — each removed, and the failure it lets through")
    q = "How many chunks mention reranking, and what does the roadmap say about it?"

    cases = [
        ("all controls on", Limits(), False),
        ("step budget = 2", Limits(max_steps=2), False),
        ("cost cap = $0.001", Limits(max_cost_usd=0.001), False),
        ("loop detection OFF", Limits(loop_detect=False, max_steps=6), False),
    ]
    for label, lim, auto in cases:
        print(f"\n{BOLD}{label}{RESET}")
        tr = run_agent(q, lim, auto_approve=auto, verbose=False)
        show(tr)

    print(f"\n{BOLD}approval gate — asking the agent to write to disk{RESET}")
    q2 = "Write a note to disk containing the single most important idea in the roadmap."
    tr = run_agent(q2, Limits(), auto_approve=False, verbose=True)
    show(tr)
    blocked = any("blocked" in str(s.get("result", "")) for s in tr.steps)
    print(f"  {(GREEN + 'irreversible action was blocked' if blocked else RED + 'NOT blocked — gate failed')}{RESET}")

    print(f"""
{DIM}Read the stop reasons, not the answers. An agent that "worked" is not evidence
of anything; an agent that STOPPED FOR A NAMED REASON is a system you can operate.

  step budget    bounds goal drift and the pathological long run
  cost cap       bounds a retry storm — the denial-of-wallet failure (Lesson 14)
  loop detection repeated (action, args) means stuck; more turns will not help
  approval gate  irreversible actions need a human, always
  error ceiling  stops an error cascade poisoning the rest of the run{RESET}""")


def cmd_failures(_a) -> None:
    rule("FAILURE-MODE CATALOGUE — measured")

    print(f"\n{BOLD}1. TOOL HALLUCINATION{RESET}")
    print(f"{DIM}The model invents an action that does not exist. The loop's error message is")
    print(f"written FOR THE MODEL to recover from — it names the valid options.{RESET}")
    obs = {"error": "unknown action 'query_database'. Valid actions: " + ", ".join(TOOLS)}
    print(f"  observation returned: {DIM}{json.dumps(obs)[:100]}{RESET}")
    print(f"  {GREEN}recoverable{RESET} — contrast with a bare 500 or a stack trace, which the")
    print(f"  model cannot act on and which usually produces a retry of the same call")

    print(f"\n{BOLD}2. INSECURE TOOL ARGUMENTS{RESET}")
    for expr in ("2 + 2 * 10", "__import__('os').system('id')"):
        r = tool_calc(expr)
        ok = "error" not in r
        print(f"  calc({expr!r:34}) -> {(GREEN if ok else RED)}{json.dumps(r)[:60]}{RESET}")
    print(f"  {DIM}Lesson 06's rule — model output is untrusted input — applies to tool ARGS.")
    print(f"  eval() on an LLM-authored string is an RCE primitive you handed to a text")
    print(f"  generator. The allow-list regex is the whole defence.{RESET}")

    print(f"\n{BOLD}3. THE STOP-REASON DISTRIBUTION IS YOUR REAL METRIC{RESET}")
    qs = ["How many chunks mention reranking?",
          "What does the roadmap say about evaluation?",
          "What is the airspeed velocity of an unladen swallow?"]
    stops = []
    for q in qs:
        tr = run_agent(q, Limits(max_steps=6), verbose=False)
        stops.append((q, tr.stopped, len(tr.steps), tr.cost))
    print(f"\n  {'question':<46} {'stopped':<26} {'steps':>6} {'cost':>8}")
    print(f"  {DIM}{'-'*46} {'-'*26} {'-'*6} {'-'*8}{RESET}")
    for q, s, n, c in stops:
        col = GREEN if s == "finished" else YELLOW
        print(f"  {q[:46]:<46} {col}{s[:26]:<26}{RESET} {n:>6} ${c:>7.4f}")

    print(f"""
{DIM}Task completion rate alone hides everything. Track the STOP-REASON
DISTRIBUTION — finished / step budget / cost cap / loop / error ceiling — plus
cost and steps PER COMPLETED TASK, not per call. A version that "improves
completion" by raising the step budget has not improved anything; it has moved
spend from one column to another.

{BOLD}When NOT to use an agent (your Q11){RESET}
An agent is the right shape only when the SEQUENCE OF STEPS CANNOT BE KNOWN IN
ADVANCE. If you can draw the flowchart, write the flowchart: it is cheaper,
faster, testable, and it cannot loop.

  wrong  "summarise this document"          -> one call
  wrong  "extract these 6 fields"           -> one call with a schema
  wrong  "answer from our docs"             -> RAG pipeline (Lessons 01-06)
  wrong  "classify then route then reply"   -> a prompt chain; the steps are known
  right  "debug why this pipeline is failing" — the next step depends on what the
         last one found, and the depth is unknown until you get there{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    pr = sub.add_parser("run"); pr.add_argument("question")
    sub.add_parser("controls"); sub.add_parser("failures")
    a = p.parse_args()
    {"run": cmd_run, "controls": cmd_controls, "failures": cmd_failures}[a.cmd](a)


if __name__ == "__main__":
    main()
