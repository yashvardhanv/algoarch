"""Lab 07 — Context engineering: deciding what the model sees at the moment of the call.

The industry renamed "prompt engineering" to "context engineering" and the rename
is meaningful. The job is not clever wording. It is assembling the right bytes
into a finite, priced window — and then MEASURING, because your intuition about
which prompt is better is wrong more often than you expect.

    python 07_context_engineering.py variants   # A. 5 prompts, ranked by eval not vibes
    python 07_context_engineering.py hatch      # B. the escape hatch, ablated
    python 07_context_engineering.py structured # C. "return JSON" vs a real schema
    python 07_context_engineering.py order      # D. lost in the middle, measured
    python 07_context_engineering.py memory     # E. conversation memory strategies
"""

from __future__ import annotations

import argparse
import concurrent.futures as cf
import importlib.util
import json
import pathlib
import statistics
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
spec = importlib.util.spec_from_file_location("lab4", HERE / "04_retrieval.py")
lab4 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab4)

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")


CAP_CHARS = 300


def rule(s: str) -> None:
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


def client():
    import aiconfig
    return aiconfig.client()


def ask(system: str, user: str, schema: dict | None = None):
    kw = {}
    if schema:
        kw["response_format"] = {"type": "json_schema",
                                 "json_schema": {"name": "out", "schema": schema}}
    r = client().chat.completions.create(
        model=aiconfig.MODEL,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}], **kw)
    return r.choices[0].message.content.strip(), r.usage


def parallel(fn, items, workers=4):
    out = [None] * len(items)
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(fn, it): i for i, it in enumerate(items)}
        done = 0
        for f in cf.as_completed(futs):
            out[futs[f]] = f.result()
            done += 1
            print(f"\r  {done}/{len(items)} …", end="", file=sys.stderr, flush=True)
    print("\r" + " " * 30 + "\r", end="", file=sys.stderr, flush=True)
    return out


def build_index():
    text = lab4.CORPUS.read_text(encoding="utf-8")
    lab4.check_gold(text)
    return lab4.Index(lab4.chunk_recursive(text))


def retrieve_ctx(idx, q, budget=lab4.BUDGET):
    order = lab4.p_hybrid_rerank(idx, q)
    ctx, spent = [], 0
    for ci in order:
        t = idx.texts[int(ci)]
        if spent + len(t) > budget:
            break
        spent += len(t)
        ctx.append(t)
    return ctx


def block_of(ctx):
    return "\n\n".join(f"[{i}] {t.strip()}" for i, t in enumerate(ctx, 1))


# =========================================================================== #
# A. FIVE PROMPT VARIANTS, RANKED BY EVAL
# =========================================================================== #

VARIANTS = {
    "V1 minimal": "Answer the question using the context.",

    "V2 role+task": (
        "You are a technical documentation assistant. Answer the user's question about "
        "AI engineering using the provided context passages. Be accurate and concise."),

    "V3 structured": (
        "<role>Technical documentation assistant.</role>\n"
        "<task>Answer the question using ONLY the numbered context passages.</task>\n"
        "<rules>\n"
        "- Cite passages inline as [1], [2].\n"
        "- If the passages do not contain the answer, reply exactly: "
        "Not in the provided context.\n"
        "- Maximum three sentences.\n"
        "</rules>"),

    "V4 structured+examples": (
        "<role>Technical documentation assistant.</role>\n"
        "<task>Answer the question using ONLY the numbered context passages.</task>\n"
        "<rules>\n"
        "- Cite passages inline as [1], [2].\n"
        "- If the passages do not contain the answer, reply exactly: "
        "Not in the provided context.\n"
        "- Maximum three sentences.\n"
        "</rules>\n"
        "<example>\n"
        "Q: What fuses sparse and dense retrieval?\n"
        "A: Reciprocal Rank Fusion merges the two ranked lists without tuning score scales [2].\n"
        "</example>\n"
        "<example>\n"
        "Q: What is the capital of France?\n"
        "A: Not in the provided context.\n"
        "</example>"),

    "V5 kitchen sink": (
        "You are an extremely capable, world-class technical documentation assistant with deep "
        "expertise in AI engineering, retrieval systems, evaluation methodology, and production "
        "machine learning. It is critically important that you answer accurately. Take a deep "
        "breath and think step by step. Answer the user's question using ONLY the numbered "
        "context passages provided below. Cite passages inline as [1], [2]. Be thorough but "
        "concise. Be helpful. If the passages do not contain the answer, say so. Do not "
        "hallucinate. Do not make things up. Accuracy is paramount. Maximum three sentences, "
        "but be complete. Think carefully before answering."),
}


def cmd_variants(_a) -> None:
    idx = build_index()
    rule("A. FIVE PROMPT VARIANTS — ranked by eval, not by vibes")
    print(f"""{DIM}The roadmap's instruction: write five variants and pick the winner ONLY on
eval scores. Notice how often your intuition was wrong.

Scored on {len(lab4.GOLD[:14])} questions: did the answer contain the gold fact, did it cite,
and how many output tokens did it spend.{RESET}""")

    subset = lab4.GOLD[:14]
    ctxs = {q: retrieve_ctx(idx, q) for q, _, _ in subset}

    def score_variant(name):
        sysmsg = VARIANTS[name]

        def one(item):
            q, _tag, ans = item
            out, usage = ask(sysmsg, f"Context passages:\n\n{block_of(ctxs[q])}\n\nQuestion: {q}")
            key = " ".join(ans.split()[:4]).lower().strip("*")
            return {"correct": key in out.lower(),
                    # LENGTH CONTROL. A substring check rewards writing more: a
                    # 500-token answer has more chances to contain the gold string
                    # than a 90-token one. That is the VERBOSITY BIAS from Lesson
                    # 05 appearing inside my own metric. Capping every answer at
                    # the same prefix length removes the advantage.
                    "correct_capped": key in out.lower()[:CAP_CHARS],
                    "cited": "[" in out and "]" in out,
                    "out_tok": usage.completion_tokens,
                    "in_tok": usage.prompt_tokens,
                    "chars": len(out)}
        rows = parallel(one, subset)
        return {"acc": sum(r["correct"] for r in rows) / len(rows),
                "acc_capped": sum(r["correct_capped"] for r in rows) / len(rows),
                "cite": sum(r["cited"] for r in rows) / len(rows),
                "out_tok": statistics.mean(r["out_tok"] for r in rows),
                "in_tok": statistics.mean(r["in_tok"] for r in rows),
                "chars": statistics.mean(r["chars"] for r in rows)}

    REPEATS = 2
    print(f"\n{DIM}{REPEATS} independent runs per variant — a single run is not a decision.{RESET}")
    print(f"\n{'variant':<24} {'sys ch':>7} {'raw acc':>8} {'capped':>13} {'cited':>7} "
          f"{'out tok':>8}")
    print(f"{DIM}{'-'*24} {'-'*7} {'-'*8} {'-'*13} {'-'*7} {'-'*8}{RESET}")
    res = {}
    for name in VARIANTS:
        runs = [score_variant(name) for _ in range(REPEATS)]
        m = {k: statistics.mean(r[k] for r in runs) for k in runs[0]}
        m["cap_lo"] = min(r["acc_capped"] for r in runs)
        m["cap_hi"] = max(r["acc_capped"] for r in runs)
        res[name] = m
        cap = GREEN if m["acc_capped"] >= 0.85 else (YELLOW if m["acc_capped"] >= 0.7 else RED)
        ccol = GREEN if m["cite"] >= 0.9 else (YELLOW if m["cite"] >= 0.5 else RED)
        spread = f"{m['cap_lo']:.2f}-{m['cap_hi']:.2f}"
        print(f"{name:<24} {len(VARIANTS[name]):>7} {DIM}{m['acc']:>8.2f}{RESET} "
              f"{cap}{m['acc_capped']:>6.2f}{RESET} {DIM}{spread:>6}{RESET} "
              f"{ccol}{m['cite']:>7.2f}{RESET} {m['out_tok']:>8.0f}")

    noise = max(m["cap_hi"] - m["cap_lo"] for m in res.values())
    print(f"\n{YELLOW}NOISE FLOOR: the widest run-to-run spread was {noise:.2f}.{RESET}")
    print(f"{DIM}With {len(subset)} questions, one question is worth {1/len(subset):.2f}. Any variant difference")
    print(f"smaller than {max(noise, 1/len(subset)):.2f} is indistinguishable from sampling noise, and this")
    print(f"lab does not have the samples to rank variants that are close. Treat the")
    print(f"table as separating CLASSES of prompt, not as a leaderboard.{RESET}")

    raw_best = max(res.items(), key=lambda kv: kv[1]["acc"])
    cap_best = max(res.items(), key=lambda kv: (kv[1]["acc_capped"], kv[1]["cite"]))
    v1, v3, v5 = res["V1 minimal"], res["V3 structured"], res["V5 kitchen sink"]
    print(f"""
{YELLOW}FIRST, A CONFOUND IN MY OWN METRIC.{RESET}
{DIM}"raw acc" is a substring check, and it REWARDS WRITING MORE: V1 emits {v1['out_tok']:.0f} output
tokens and V3 emits {v3['out_tok']:.0f}. A longer answer simply has more chances to contain the
gold string. That is the VERBOSITY BIAS from Lesson 05, appearing inside my own
eval — which is exactly how it appears inside yours.

"capped" scores only the first {CAP_CHARS} characters of each answer, so every variant is
judged on the same amount of text.

  winner on raw acc     : {raw_best[0]}
  winner on capped acc  : {cap_best[0]}
{'  → the ranking CHANGED once length was controlled.' if raw_best[0] != cap_best[0] else '  → the ranking held under the length control.'}{RESET}

{BOLD}THE HONEST CONCLUSION — and it is not the one the exercise expects{RESET}
{DIM}Capped accuracy across all five variants spans {min(m['acc_capped'] for m in res.values()):.2f} to {max(m['acc_capped'] for m in res.values()):.2f}, and the
run-to-run noise floor is {noise:.2f}. THE VARIANTS ARE NOT DISTINGUISHABLE ON ACCURACY.
Six hundred characters of "take a deep breath, accuracy is paramount, do not
hallucinate" bought nothing measurable over a 38-character instruction.

What DID separate cleanly, far outside the noise:

  citation rate   {min(m['cite'] for m in res.values()):.2f} → {max(m['cite'] for m in res.values()):.2f}   ({(max(m['cite'] for m in res.values())-min(m['cite'] for m in res.values()))/max(noise,0.01):.0f}x the noise floor)
  output tokens   {max(m['out_tok'] for m in res.values()):.0f} → {min(m['out_tok'] for m in res.values()):.0f}   ({max(m['out_tok'] for m in res.values())/max(1,min(m['out_tok'] for m in res.values())):.1f}x cheaper, on every single request)

Both come from instructions that change the OUTPUT CONTRACT — "cite as [n]",
"maximum three sentences", an exact refusal string — not from tone, role-play, or
encouragement.

So the takeaway is not "V3 wins". It is: {BOLD}stop tuning adjectives and start
specifying the contract{RESET}{DIM} — and build the harness before you believe any prompt
comparison, including this one. The kitchen-sink prompt also contradicts itself
("maximum three sentences, but be complete"), which is the most common real
defect in production prompts and produces exactly the {res['V5 kitchen sink']['out_tok']:.0f}-token outputs you see.{RESET}""")


# =========================================================================== #
# B. THE ESCAPE HATCH, ABLATED
# =========================================================================== #

WITH_HATCH = (
    "Answer using ONLY the numbered context passages. Cite as [1], [2].\n"
    "If the passages do not contain the answer, reply exactly: Not in the provided context.\n"
    "Do not answer from your own knowledge. Maximum two sentences.")

NO_HATCH = (
    "Answer using ONLY the numbered context passages. Cite as [1], [2].\n"
    "Maximum two sentences.")

UNANSWERABLE = [
    "What is the current price of Bitcoin?",
    "How many employees does OpenAI have?",
    "What is the capital of Mongolia?",
    "Who won the 2026 Super Bowl?",
    "What is my account balance?",
    "What version of Postgres should I install?",
]


def cmd_hatch(_a) -> None:
    idx = build_index()
    rule("B. THE ESCAPE HATCH — ablated")
    print(f"""{DIM}Lesson 01 claimed "most hallucination in production is a missing escape
hatch". That was an assertion. Here it is as an experiment: {len(UNANSWERABLE)} questions the
corpus cannot answer, with and without the refusal instruction.{RESET}""")

    ctxs = {q: retrieve_ctx(idx, q) for q in UNANSWERABLE}

    CANON = "not in the provided context."

    def run(sysmsg, label):
        def one(q):
            out, _ = ask(sysmsg, f"Context passages:\n\n{block_of(ctxs[q])}\n\nQuestion: {q}")
            exact = out.strip().lower().rstrip(".") == CANON.rstrip(".")
            # semantic refusal decided by a judge, because the whole point of this
            # section is that ad-hoc string matching CANNOT do this reliably
            v, _ = ask(
                "You classify assistant responses. The response below was produced by a "
                "RAG system. Answer YES if it declined to answer, said the information was "
                "unavailable, or said the answer was not in its context. Answer NO if it "
                "actually provided a substantive answer to the question.\n"
                "Reply with exactly one word: YES or NO.",
                f"QUESTION: {q}\n\n<response>\n{out}\n</response>")
            semantic = v.strip().upper().startswith("Y")
            return {"q": q, "out": out, "exact": exact, "semantic": semantic}
        rows = parallel(one, UNANSWERABLE)
        n = len(rows)
        e = sum(x["exact"] for x in rows)
        s = sum(x["semantic"] for x in rows)
        print(f"\n{BOLD}{label}{RESET}")
        print(f"  declined (judged): {s}/{n}   detectable by exact string: "
              f"{(GREEN if e == s else RED)}{e}/{n}{RESET}")
        for x in rows:
            if x["exact"]:
                mark = f"{GREEN}EXACT   {RESET}"
            elif x["semantic"]:
                mark = f"{YELLOW}declined{RESET}"
            else:
                mark = f"{RED}ANSWERED{RESET}"
            print(f"  {mark} {x['q'][:40]:<40} {DIM}{' '.join(x['out'].split())[:58]}{RESET}")
        return e / n, s / n

    ea, sa = run(WITH_HATCH, "WITH an explicit escape hatch")
    eb, sb = run(NO_HATCH, "WITHOUT an escape hatch")

    print(f"""
{BOLD}                         declined   detectable by string{RESET}
  with escape hatch        {sa:>7.0%}   {GREEN}{ea:>18.0%}{RESET}
  without escape hatch     {sb:>7.0%}   {RED}{eb:>18.0%}{RESET}

{YELLOW}THIS PARTIALLY CONTRADICTS WHAT LESSON 01 ASSERTED. KEEP THE CONTRADICTION.{RESET}
{DIM}Lesson 01 claimed "most hallucination in production is a missing escape hatch".
On THIS setup that did not reproduce: the model declined {sb:.0%} of the time with no
instruction at all. It is a strong model and these questions are obviously out of
domain — it is not eager to invent a Bitcoin price.

Where the original claim still holds, and what this experiment cannot show:
weaker/smaller models, and SUBTLY unanswerable questions where the context looks
topically relevant but lacks the specific fact. Those are the cases that
fabricate. Do not generalise this result past its conditions.

The first version of this lab used a hand-written substring matcher and scored
the no-hatch condition at 50%, because the model phrased refusals six ways:

  "This question isn't addressed in the provided context passages"
  "The context does not specify a particular Postgres version"
  "I don't have real-time data access, so I can't provide..."

All refusals. None matched my matcher. The measurement was wrong, not the model.

So the escape hatch's real job is not to make the model refuse — it is to make
refusals {BOLD}DETECTABLE{RESET}{DIM}. With the exact string you get {ea:.0%} string-detectable
refusals and can route them with `==`. Without it you need a classifier on every
response, which costs an LLM call, has its own error rate, and is one more thing
to calibrate.

  * make the refusal string LITERAL and EXACT so downstream logic is a comparison
  * a refusal is trivially grounded (Lesson 06), so this line is also what makes
    your groundedness metric achievable
  * do not conclude "the model hallucinates without a hatch" from a bad detector —
    that error is the same shape as Lesson 05's mislabelled hallucinations{RESET}""")


# =========================================================================== #
# C. STRUCTURED OUTPUT
# =========================================================================== #

EXTRACT_SCHEMA = {
    "type": "object",
    "properties": {
        "technique": {"type": "string"},
        "category": {"type": "string", "enum": ["retrieval", "evaluation", "agents",
                                                "safety", "training", "serving"]},
        "roi": {"type": "string", "enum": ["high", "medium", "low", "unknown"]},
        "cited_passages": {"type": "array", "items": {"type": "integer"}},
    },
    "required": ["technique", "category", "roi", "cited_passages"],
}

EXTRACT_QS = [
    "What is reranking and how valuable is it?",
    "What is Reciprocal Rank Fusion?",
    "What is Cohen's kappa used for?",
    "What is LoRA?",
    "What is prompt injection?",
    "What is prefix caching?",
    "What is HyDE?",
    "What is contextual retrieval?",
]


def cmd_structured(_a) -> None:
    idx = build_index()
    rule("C. 'PLEASE RETURN JSON' vs A REAL SCHEMA")
    print(f"""{DIM}Both approaches ask for the same object. One asks politely in prose and
parses with json.loads; the other constrains decoding with a JSON Schema. The
difference is not style — it is whether your parser can fail in production.{RESET}""")

    ctxs = {q: retrieve_ctx(idx, q, budget=2500) for q in EXTRACT_QS}
    valid_cats = set(EXTRACT_SCHEMA["properties"]["category"]["enum"])
    valid_roi = set(EXTRACT_SCHEMA["properties"]["roi"]["enum"])

    PROSE_SYS = (
        "Extract information about the technique the user asks about, using the context.\n"
        "Return JSON with keys: technique (string), category (one of: retrieval, evaluation, "
        "agents, safety, training, serving), roi (one of: high, medium, low, unknown), "
        "cited_passages (array of integers).\n"
        "Return only the JSON object, nothing else.")
    SCHEMA_SYS = ("Extract information about the technique the user asks about, using the "
                  "numbered context passages. cited_passages are the passage numbers you used.")

    def run(sysmsg, schema, label):
        def one(q):
            try:
                out, _ = ask(sysmsg, f"Context:\n\n{block_of(ctxs[q])}\n\nTechnique: {q}",
                             schema=schema)
            except Exception as e:  # noqa: BLE001
                return {"parsed": False, "err": type(e).__name__, "enum_ok": False, "keys_ok": False}
            try:
                obj = json.loads(out)
            except ValueError:
                return {"parsed": False, "err": "JSONDecodeError", "raw": out[:70],
                        "enum_ok": False, "keys_ok": False}
            keys_ok = set(EXTRACT_SCHEMA["required"]) <= set(obj)
            enum_ok = (obj.get("category") in valid_cats and obj.get("roi") in valid_roi)
            return {"parsed": True, "keys_ok": keys_ok, "enum_ok": enum_ok, "obj": obj}
        rows = parallel(one, EXTRACT_QS)
        n = len(rows)
        p = sum(r["parsed"] for r in rows)
        k = sum(r["keys_ok"] for r in rows)
        e = sum(r["enum_ok"] for r in rows)
        pc, kc, ec = (GREEN if x == n else RED for x in (p, k, e))
        print(f"  {label:<28} parsed {pc}{p}/{n}{RESET}  "
              f"all keys {kc}{k}/{n}{RESET}  enums valid {ec}{e}/{n}{RESET}")
        for r in rows:
            if not r["parsed"]:
                print(f"    {RED}FAILED{RESET} {r.get('err')} {DIM}{r.get('raw','')}{RESET}")
            elif not r["enum_ok"]:
                o = r["obj"]
                print(f"    {YELLOW}ENUM VIOLATION{RESET} category={o.get('category')!r} "
                      f"roi={o.get('roi')!r}")
        return p, k, e

    print()
    run(PROSE_SYS, None, "prose 'return JSON'")
    run(SCHEMA_SYS, EXTRACT_SCHEMA, "json_schema (constrained)")

    print(f"""
{DIM}Even when the prose version parses, it parses BY LUCK — nothing prevents a
markdown fence, a preamble ("Here is the JSON:"), a trailing explanation, or an
enum value the model invented. Those failures appear at 3am under load, on the
inputs you did not test, and your retry loop turns each one into three.

Prefer native structured output wherever the provider offers it. When it isn't
available: constrain aggressively, validate with Pydantic, and treat a parse
failure as a first-class error path with a bounded retry — not an exception that
escapes into a 500.

Note this course's own shim (Lesson 00) maps response_format=json_schema onto the
claude CLI's --json-schema, which is why this section runs at all.{RESET}""")


# =========================================================================== #
# D. LOST IN THE MIDDLE
# =========================================================================== #

def cmd_order(_a) -> None:
    idx = build_index()
    rule("D. LOST IN THE MIDDLE — where the answer sits in the context")
    print(f"""{DIM}Lessons 01 and 03 asserted that models weight the edges of the context more
than the middle. Here it is measured: the SAME gold passage placed at different
positions among {14} distractors, same question, same model.{RESET}""")

    N_DISTRACT = 14
    subset = [(q, a) for q, t, a in lab4.GOLD if t in ("para", "multi")][:10]

    def build(q, ans, position):
        """Put the gold chunk at `position` among distractors drawn from elsewhere."""
        gold = next(t for t in idx.texts if ans in t)
        distract = [t for t in idx.texts if ans not in t][:N_DISTRACT]
        ctx = distract[:]
        pos = min(position, len(ctx))
        ctx.insert(pos, gold)
        return ctx

    positions = [0, 3, 7, 11, N_DISTRACT]
    print(f"\n  {'gold position':>14} {'answered':>9} {'note':<34}")
    print(f"  {DIM}{'-'*14} {'-'*9} {'-'*34}{RESET}")
    results = []
    for pos in positions:
        def one(item):
            q, ans = item
            ctx = build(q, ans, pos)
            out, _ = ask(WITH_HATCH, f"Context passages:\n\n{block_of(ctx)}\n\nQuestion: {q}")
            key = " ".join(ans.split()[:4]).lower().strip("*")
            return key in out.lower()
        hits = parallel(one, subset)
        acc = sum(hits) / len(hits)
        results.append((pos, acc))
        note = ("first — the primacy edge" if pos == 0 else
                "LAST — the recency edge" if pos == N_DISTRACT else "buried in the middle")
        col = GREEN if acc >= 0.8 else (YELLOW if acc >= 0.6 else RED)
        print(f"  {pos:>14} {col}{acc:>9.2f}{RESET} {DIM}{note:<34}{RESET}")

    edges = statistics.mean([results[0][1], results[-1][1]])
    middle = statistics.mean([r[1] for r in results[1:-1]])
    delta = edges - middle
    print(f"""
{BOLD}edges {edges:.2f} vs middle {middle:.2f}  →  {delta:+.2f}{RESET}
{DIM}{'The effect reproduced on this corpus.' if delta > 0.05 else
'The effect did NOT reproduce meaningfully here — report that honestly. With ' +
str(len(subset)) + ' questions and a strong model over ' + str(N_DISTRACT + 1) + ' short passages, ' +
'this context is far below the length where lost-in-the-middle bites hardest.'}

What to do with it either way:
  * put the highest-ranked chunks at the EDGES, not in rank order, once k is large
  * keep k small — Lesson 04 showed reranking beats raising k anyway
  * static content FIRST (it is also what makes prefix caching work — Lesson 09),
    volatile content LAST{RESET}""")


# =========================================================================== #
# E. CONVERSATION MEMORY
# =========================================================================== #

CONVO = [
    ("user", "I'm building a RAG system over about 400,000 internal support tickets."),
    ("assistant", "Noted — 400,000 support tickets."),
    ("user", "We're on Postgres already and the team is small, three engineers."),
    ("assistant", "Understood: Postgres, three engineers."),
    ("user", "Latency budget is 800ms end to end and tickets are multi-tenant."),
    ("assistant", "Got it: 800ms budget, multi-tenant."),
    ("user", "We tried dense-only retrieval and recall was poor on error codes."),
    ("assistant", "That's a known weakness of dense retrieval."),
    ("user", "Also our docs contain a lot of near-duplicate tickets."),
    ("assistant", "Near-duplicates noted."),
]
FINAL_Q = "Given everything above, which vector store should we use and why?"


def cmd_memory(_a) -> None:
    rule("E. CONVERSATION MEMORY — four strategies, priced")
    print(f"""{DIM}Every turn you re-send is billed again. The question is not "keep history or
not" but WHICH BYTES survive into the next call. Four strategies on the same
10-turn conversation, judged on whether the final answer uses the facts that
matter (Postgres, multi-tenant, small team).{RESET}""")

    facts = ["postgres", "multi-tenant", "three engineers"]

    def render(strategy):
        if strategy == "full":
            return "\n".join(f"{r.capitalize()}: {c}" for r, c in CONVO)
        if strategy == "window":
            return "\n".join(f"{r.capitalize()}: {c}" for r, c in CONVO[-4:])
        if strategy == "none":
            return ""
        if strategy == "summary":
            hist = "\n".join(f"{r.capitalize()}: {c}" for r, c in CONVO)
            s, _ = ask("Summarise the constraints and facts the user has stated, as a compact "
                       "bullet list. Facts only, no preamble.", hist)
            return s
        raise ValueError(strategy)

    print(f"\n  {'strategy':<22} {'ctx chars':>10} {'in tok':>8} {'facts kept':>11} {'answer':<28}")
    print(f"  {DIM}{'-'*22} {'-'*10} {'-'*8} {'-'*11} {'-'*28}{RESET}")
    for strategy, label in (("full", "full history"), ("window", "sliding window (4)"),
                            ("summary", "running summary"), ("none", "no history")):
        hist = render(strategy)
        out, usage = ask("Answer the user's question directly in two sentences, using the "
                         "conversation context if present.",
                         (f"Conversation so far:\n{hist}\n\n" if hist else "") + FINAL_Q)
        kept = sum(f in out.lower() or f in hist.lower() for f in facts)
        col = GREEN if kept == len(facts) else (YELLOW if kept else RED)
        print(f"  {label:<22} {len(hist):>10} {usage.prompt_tokens:>8} "
              f"{col}{f'{kept}/{len(facts)}':>11}{RESET} {DIM}{' '.join(out.split())[:28]}…{RESET}")

    print(f"""
{DIM}The tradeoff, stated plainly:

  full history     perfect recall · cost grows O(n^2) over a conversation ·
                   eventually exceeds the window and fails hard
  sliding window   flat cost · silently forgets the constraint stated in turn 2,
                   which is usually the most important one
  running summary  flat-ish cost · costs an extra LLM call per turn · lossy in a
                   way you cannot predict
  structured state extract named fields (stack, scale, constraints) into a dict and
                   re-inject them — cheap, lossless for what you chose to keep,
                   and the only one that is DEBUGGABLE

For agents (Lesson 10) the same problem returns as compaction, and the answer is
the same: extract state deliberately rather than hoping a summary keeps the right
sentence.{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for c in ("variants", "hatch", "structured", "order", "memory"):
        sub.add_parser(c)
    a = p.parse_args()
    {"variants": cmd_variants, "hatch": cmd_hatch, "structured": cmd_structured,
     "order": cmd_order, "memory": cmd_memory}[a.cmd](a)


if __name__ == "__main__":
    main()
