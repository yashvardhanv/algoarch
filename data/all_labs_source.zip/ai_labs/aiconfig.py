"""aiconfig — one place that decides which LLM every lab talks to.

Before this module, eleven labs each hard-coded
`base_url="http://127.0.0.1:8787/v1"` and `model=aiconfig.MODEL`. That works until you
want to run the course against a real API, a local model, or a colleague's
endpoint — at which point you are editing eleven files and missing one.

Everything is driven by environment variables, so nothing in the labs changes:

    AI_PROVIDER   shim | openai | anthropic | ollama | custom     (default: shim)
    AI_MODEL      model id                    (default: per provider, see below)
    AI_BASE_URL   override the endpoint       (default: per provider)
    AI_API_KEY    override the key            (default: from the provider's env var)
    AI_TIMEOUT    seconds                     (default: 900)

Examples:

    # the default — free, local, uses your Claude subscription via claude-shim
    ./start.sh

    # a real OpenAI key
    AI_PROVIDER=openai AI_MODEL=gpt-4o-mini ./start.sh

    # Anthropic directly (bypassing the shim)
    AI_PROVIDER=anthropic AI_MODEL=claude-sonnet-5 ./start.sh

    # anything OpenAI-compatible: vLLM, LM Studio, OpenRouter, a colleague's box
    AI_PROVIDER=custom AI_BASE_URL=http://gpu-box:8000/v1 AI_MODEL=qwen2.5-14b ./start.sh

WHY EVERY PROVIDER IS SPOKEN TO AS "OpenAI-compatible": the openai SDK's wire
format is the lingua franca — vLLM, LM Studio, OpenRouter, Ollama and the
Lesson 00 shim all implement it. One client, one code path, and swapping
providers is an env var rather than a rewrite. Anthropic is the exception and
gets its own branch below.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass

DEFAULTS = {
    # provider:  (base_url,                          model,                   key env var)
    "shim":      ("http://127.0.0.1:8787/v1",        "sonnet",                None),
    "openai":    ("https://api.openai.com/v1",       "gpt-4o-mini",           "OPENAI_API_KEY"),
    "anthropic": ("https://api.anthropic.com/v1",    "claude-sonnet-5",       "ANTHROPIC_API_KEY"),
    "ollama":    ("http://127.0.0.1:11434/v1",       "qwen2.5:7b",            None),
    "custom":    (None,                              None,                    "AI_API_KEY"),
    "gemini": (
    "https://generativelanguage.googleapis.com/v1beta/openai/",
    "gemini-3.5-flash-lite",
    "GEMINI_API_KEY",
),
}

# Small/cheap counterpart per provider — used by Lesson 16's routing experiment.
SMALL_MODEL = {
    "shim": "haiku",
    "openai": "gpt-4o-mini",
    "anthropic": "claude-haiku-4-5",
    "ollama": "qwen2.5:3b",
    "custom": None,
    "gemini": "gemini-3.5-flash-lite",
}


@dataclass(frozen=True)
class Config:
    provider: str
    base_url: str
    model: str
    small_model: str
    api_key: str
    timeout: int

    def describe(self) -> str:
        key = "—" if self.api_key in ("", "not-needed") else f"{self.api_key[:6]}…"
        return (f"provider={self.provider} model={self.model} "
                f"small={self.small_model} base_url={self.base_url} key={key}")


def _load_dotenv() -> None:
    """Read ../.env if present, without clobbering real environment variables.

    Real env wins over the file on purpose: a one-off
    `AI_PROVIDER=openai python lab.py` must not be silently overridden by a
    stale .env.
    """
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    if not os.path.exists(p):
        return
    for line in open(p, encoding="utf-8"):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def load() -> Config:
    _load_dotenv()
    provider = os.environ.get("AI_PROVIDER", "shim").strip().lower()
    if provider not in DEFAULTS:
        sys.exit(f"AI_PROVIDER={provider!r} is not one of {', '.join(DEFAULTS)}")

    d_url, d_model, key_var = DEFAULTS[provider]
    base_url = os.environ.get("AI_BASE_URL") or d_url
    model = os.environ.get("AI_MODEL") or d_model
    small = os.environ.get("AI_SMALL_MODEL") or SMALL_MODEL.get(provider) or model

    if not base_url:
        sys.exit("AI_PROVIDER=custom requires AI_BASE_URL")
    if not model:
        sys.exit(f"AI_PROVIDER={provider} requires AI_MODEL")

    key = os.environ.get("AI_API_KEY") or (os.environ.get(key_var) if key_var else None)
    if provider == "shim":
        key = key or "not-needed"          # the shim ignores it unless configured
    elif provider == "ollama":
        key = key or "ollama"              # ollama ignores it but the SDK demands one
    elif not key:
        sys.exit(f"AI_PROVIDER={provider} needs {key_var} (or AI_API_KEY) in the environment")

    return Config(provider=provider, base_url=base_url, model=model or aiconfig.MODEL, small_model=small,
                  api_key=key, timeout=int(os.environ.get("AI_TIMEOUT", "900")))


CONFIG = load()
MODEL = CONFIG.model
SMALL = CONFIG.small_model
BASE_URL = CONFIG.base_url


def client():
    """An OpenAI-compatible client for whichever provider is configured.

    Anthropic's native API is not OpenAI-shaped, so it gets a shim of its own
    here rather than leaking the difference into every lab.
    """
    if CONFIG.provider == "anthropic":
        return _AnthropicAdapter()
    from openai import OpenAI
    return OpenAI(base_url=CONFIG.base_url, api_key=CONFIG.api_key, timeout=CONFIG.timeout)


class _AnthropicAdapter:
    """Presents `chat.completions.create(...)` over the Anthropic SDK.

    Deliberately minimal: it covers exactly what the labs use — a system
    message, user messages, and optional JSON-schema structured output — and
    returns objects with `.choices[0].message.content` and `.usage`.
    """

    def __init__(self):
        try:
            import anthropic
        except ImportError:
            sys.exit("AI_PROVIDER=anthropic needs: pip install anthropic")
        self._c = anthropic.Anthropic(api_key=CONFIG.api_key, timeout=CONFIG.timeout)
        self.chat = self

    @property
    def completions(self):
        return self

    def create(self, model=None, messages=None, response_format=None, **_kw):
        system = "\n\n".join(m["content"] for m in messages if m["role"] == "system")
        turns = [{"role": m["role"], "content": m["content"]}
                 for m in messages if m["role"] in ("user", "assistant")]
        if response_format and response_format.get("type") == "json_schema":
            schema = response_format["json_schema"]["schema"]
            system += ("\n\nReply with ONLY a JSON object matching this schema, no prose, "
                       "no markdown fence:\n" + str(schema))
        r = self._c.messages.create(model=model or CONFIG.model, max_tokens=4096,
                                    system=system or None, messages=turns)
        text = "".join(b.text for b in r.content if getattr(b, "type", "") == "text")
        return _Resp(text, r.usage.input_tokens, r.usage.output_tokens)


class _Resp:
    def __init__(self, text, pin, pout):
        self.choices = [type("C", (), {"message": type("M", (), {"content": text})()})()]
        self.usage = type("U", (), {"prompt_tokens": pin, "completion_tokens": pout,
                                    "total_tokens": pin + pout})()


def preflight() -> bool:
    """One cheap call to prove the configured provider actually answers."""
    try:
        r = client().chat.completions.create(
            model=MODEL, messages=[{"role": "user", "content": "reply with: ok"}])
        return bool(r.choices[0].message.content)
    except Exception as e:  # noqa: BLE001
        print(f"preflight failed: {type(e).__name__}: {str(e)[:160]}", file=sys.stderr)
        return False


if __name__ == "__main__":
    print(CONFIG.describe())
    print("preflight:", "OK" if preflight() else "FAILED")
