"""Lab 03 — Chunking strategies, measured against retrieval recall.

Lesson 01 chunked on a character count because it was the simplest thing that
works. This lab shows what that cost you, in numbers, and replaces it.

THE MEASUREMENT
---------------
Arguing about chunking without a metric is how teams burn weeks. So this lab
carries a small GOLD SET: (question, answer_substring) pairs where the answer
string is known to exist verbatim in the corpus. A chunk is RELEVANT if it
contains that substring. That makes recall objective and needs no hand-labelling:

    recall@k = fraction of questions where at least one of the top-k chunks
               contains the answer string
    MRR      = mean of 1/rank of the first relevant chunk

This is a preview of Lesson 05. Notice you can build a useful eval in 20 lines.

    python 03_chunking.py compare      # all strategies, side by side  ← START HERE
    python 03_chunking.py inspect fixed900
    python 03_chunking.py cliff        # the 256-word-piece truncation cliff
    python 03_chunking.py contextual   # contextual retrieval (uses claude-shim)
"""

from __future__ import annotations

import argparse
import pathlib
import re
import statistics
import sys
import time

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
CORPUS = HERE.parent.parent / "ai-engineer-roadmap.md"

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")


def rule(s: str) -> None:
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


# --------------------------------------------------------------------------- #
# GOLD SET — (question, answer substring that exists verbatim in the corpus)
# --------------------------------------------------------------------------- #

GOLD = [
    ("What is the highest-ROI upgrade to a mediocre RAG system?",
     "highest-ROI single upgrade"),
    ("How do you fuse sparse and dense retrieval?",
     "Reciprocal Rank Fusion"),
    ("What should I do about ANN recall loss?",
     "silent quality tax"),
    ("How do I detect an uncalibrated LLM judge?",
     "Cohen's kappa"),
    ("What causes most hallucination in production?",
     "missing escape hatch"),
    ("Which vector store should I default to?",
     "correct default vector store"),
    ("How should I handle permissions in retrieval?",
     "Never post-filter"),
    ("What is contextual retrieval?",
     "LLM-generated summary of the parent document"),
    ("When is fine-tuning the right answer?",
     "rarely for adding knowledge"),
    ("How long can an agent run before it needs durability?",
     "durable execution layer"),
    ("What do I do about prompt injection?",
     "prompt injection is not solved"),
    ("How much of AI engineering is normal backend work?",
     "ordinary backend engineering"),
]


# --------------------------------------------------------------------------- #
# CHUNKERS
# --------------------------------------------------------------------------- #

def chunk_fixed(text: str, size: int, overlap: int) -> list[dict]:
    """Cut every `size` characters. Knows nothing about language.

    This is the strategy from Lesson 01, and the one your diagnostic Q6 asked
    about. It is fast, trivially correct, and structurally blind: the cut point
    is chosen by a counter, so it lands wherever it lands — mid-sentence,
    mid-table-row, or between a claim and the sentence that qualifies it.
    """
    out, step = [], max(1, size - overlap)
    for i in range(0, len(text), step):
        body = text[i:i + size]
        if body.strip():
            out.append({"text": body, "start": i})
        if i + size >= len(text):
            break
    return out


_SEPARATORS = ["\n## ", "\n### ", "\n\n", "\n", ". ", " "]


def chunk_recursive(text: str, size: int, overlap: int = 0,
                    seps: list[str] | None = None) -> list[dict]:
    """Split on the most semantic separator that works, recursing to finer ones.

    Try to split on headings. If a piece is still too big, split it on blank
    lines. Still too big? sentences. Still too big? words. Each level down is a
    less meaningful boundary, so you only descend when forced. This is what
    LangChain's RecursiveCharacterTextSplitter does, and it is the correct
    default for almost everything.
    """
    seps = _SEPARATORS if seps is None else seps

    def _split(s: str, depth: int) -> list[str]:
        if len(s) <= size or depth >= len(seps):
            return [s]
        sep = seps[depth]
        parts = s.split(sep)
        # re-attach the separator so we don't destroy the text
        parts = [(sep if i else "") + p for i, p in enumerate(parts)]
        out, buf = [], ""
        for p in parts:
            if buf and len(buf) + len(p) > size:
                out.extend(_split(buf, depth + 1) if len(buf) > size else [buf])
                buf = p
            else:
                buf += p
        if buf:
            out.extend(_split(buf, depth + 1) if len(buf) > size else [buf])
        return out

    pos, res = 0, []
    for piece in _split(text, 0):
        if piece.strip():
            res.append({"text": piece, "start": text.find(piece, max(0, pos - 50))})
            pos += len(piece)
    return res


def chunk_structural(text: str, size: int, overlap: int = 0) -> list[dict]:
    """Split on the document's own heading hierarchy, then pack to `size`.

    A markdown `##` is a boundary the AUTHOR already drew. It is free, exact,
    and semantically meaningful — you cannot buy a better boundary than one a
    human placed deliberately. Sections larger than `size` fall back to
    paragraph packing.
    """
    parts = re.split(r"(?m)^(?=#{2,4} )", text)
    out, pos = [], 0
    for part in parts:
        if not part.strip():
            continue
        start = text.find(part, pos)
        pos = start + len(part)
        if len(part) <= size:
            out.append({"text": part, "start": start})
            continue
        buf, bstart = "", start
        for para in part.split("\n\n"):
            cand = (buf + "\n\n" + para) if buf else para
            if buf and len(cand) > size:
                out.append({"text": buf, "start": bstart})
                bstart += len(buf)
                buf = para
            else:
                buf = cand
        if buf.strip():
            out.append({"text": buf, "start": bstart})
    return out


def chunk_semantic(text: str, size: int, overlap: int = 0) -> list[dict]:
    """Embed each paragraph; cut where consecutive similarity drops sharply.

    The idea: a topic shift shows up as a dip in similarity between adjacent
    passages. Cut at the dips. Expensive (you embed the whole corpus once at
    ingestion just to decide boundaries) and it ignores explicit structure that
    is already there — so it earns its keep on unstructured prose (transcripts,
    contracts, scraped pages) and rarely beats structural chunking on markdown.
    """
    paras = [p for p in re.split(r"\n\n+", text) if p.strip()]
    V = embed([p for p in paras])
    sims = np.array([float(V[i] @ V[i + 1]) for i in range(len(V) - 1)] + [1.0])
    thresh = float(np.percentile(sims[:-1], 25))       # cut at the weakest 25% of joins

    out, buf, bstart, pos = [], "", 0, 0
    for i, p in enumerate(paras):
        start = text.find(p, pos)
        pos = start + len(p)
        if not buf:
            bstart = start
        buf = (buf + "\n\n" + p) if buf else p
        if sims[i] <= thresh or len(buf) >= size:
            out.append({"text": buf, "start": bstart})
            buf = ""
    if buf:
        out.append({"text": buf, "start": bstart})
    return out


# --------------------------------------------------------------------------- #
# embedding + metrics
# --------------------------------------------------------------------------- #

_model = None


def get_model():
    global _model
    if _model is None:
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    return _model


def embed(texts: list[str]) -> np.ndarray:
    m = get_model()
    return m.encode(texts, batch_size=64, convert_to_numpy=True,
                    normalize_embeddings=True).astype(np.float32)


def n_word_pieces(text: str) -> int:
    return len(get_model().tokenizer.encode(text, add_special_tokens=False))


_SEVERED = re.compile(r"^[a-z,;:)\]]")


def severed(c: dict) -> bool:
    """Chunk begins mid-sentence: starts lowercase or with closing punctuation."""
    t = c["text"].strip()
    return bool(t) and bool(_SEVERED.match(t))


def evaluate(chunks: list[dict], ks=(1, 3, 5, 10)) -> dict:
    """recall@k and MRR against the gold set."""
    V = embed([c["text"] for c in chunks])
    Q = embed([q for q, _ in GOLD])
    relevant = [[i for i, c in enumerate(chunks) if ans in c["text"]]
                for _, ans in GOLD]

    recalls = {k: 0 for k in ks}
    rr, unreachable = [], 0
    for qi in range(len(GOLD)):
        rel = set(relevant[qi])
        if not rel:
            # The answer string was SEVERED by this chunker — it exists in no
            # single chunk, so no retriever can ever return it. This is the
            # chunking bug made visible, and it is invisible from the answer.
            unreachable += 1
            rr.append(0.0)
            continue
        order = np.argsort(-(V @ Q[qi]))
        first = next((r for r, ci in enumerate(order, 1) if int(ci) in rel), None)
        rr.append(1.0 / first if first else 0.0)
        for k in ks:
            if first and first <= k:
                recalls[k] += 1

    n = len(GOLD)
    sizes = [len(c["text"]) for c in chunks]
    wp = [n_word_pieces(c["text"]) for c in chunks]
    return {
        "n": len(chunks),
        "mean_chars": int(statistics.mean(sizes)),
        "max_chars": max(sizes),
        "severed_pct": 100 * sum(severed(c) for c in chunks) / len(chunks),
        "over_256wp_pct": 100 * sum(w > 256 for w in wp) / len(chunks),
        "truncated_chars": sum(max(0, len(c["text"]) - 1100) for c in chunks),
        "unreachable": unreachable,
        "recall": {k: recalls[k] / n for k in ks},
        "mrr": statistics.mean(rr),
    }


def evaluate_budget(chunks: list[dict], budget_chars: int = 4000) -> dict:
    """recall at a fixed CONTEXT BUDGET rather than a fixed k.

    WHY THIS EXISTS — a real methodological trap, found while building this lab:

    recall@5 is NOT comparable across chunk sizes. Five chunks of 3000 chars is
    15,000 characters of context; five chunks of 600 chars is 3,000. The larger
    setting "wins" recall@5 simply by retrieving five times more text, not by
    retrieving better. Measured naively, chunk size 3000 scored recall@5 = 0.92
    while 100% of its chunks were being truncated by the encoder — a nonsense
    result produced by a nonsense metric.

    Fixing it: hold the thing the LLM actually pays for constant. Fill a fixed
    character budget with top-ranked chunks, then ask whether the answer is in
    there. Now every strategy is spending the same tokens and the comparison is
    honest.

    Generalise the lesson: whenever you compare two retrieval configurations,
    ask what quantity each is allowed to spend. If they differ, you are
    measuring the budget, not the retriever.
    """
    V = embed([c["text"] for c in chunks])
    Q = embed([q for q, _ in GOLD])
    hits = 0
    used = []
    for qi, (_, ans) in enumerate(GOLD):
        order = np.argsort(-(V @ Q[qi]))
        spent, found = 0, False
        for ci in order:
            t = chunks[int(ci)]["text"]
            if spent + len(t) > budget_chars:
                break
            spent += len(t)
            if ans in t:
                found = True
                break
        used.append(spent)
        hits += found
    return {"recall_at_budget": hits / len(GOLD),
            "budget": budget_chars,
            "mean_chunks_in_budget": statistics.mean(
                [max(1, round(u / max(1, statistics.mean([len(c["text"]) for c in chunks]))))
                 for u in used])}


STRATEGIES = {
    "fixed400":    ("fixed 400/60",        lambda t: chunk_fixed(t, 400, 60)),
    "fixed900":    ("fixed 900/150  ←L01", lambda t: chunk_fixed(t, 900, 150)),
    "fixed2000":   ("fixed 2000/300",      lambda t: chunk_fixed(t, 2000, 300)),
    "recursive":   ("recursive 900",       lambda t: chunk_recursive(t, 900)),
    "structural":  ("structural 900",      lambda t: chunk_structural(t, 900)),
    "semantic":    ("semantic 900",        lambda t: chunk_semantic(t, 900)),
}


def cmd_compare(_args) -> None:
    text = CORPUS.read_text(encoding="utf-8")
    rule("CHUNKING STRATEGIES vs RETRIEVAL RECALL")
    print(f"{DIM}corpus: {CORPUS.name} · {len(text):,} chars · {len(GOLD)} gold questions")
    print(f"a chunk is RELEVANT if it contains the gold answer substring verbatim{RESET}\n")

    hdr = (f"{'strategy':<20} {'chunks':>7} {'mean':>6} {'sev%':>6} "
           f"{'>256wp':>7} {'unreach':>8} {'MRR':>6} {'R@5':>6} {'R@4000ch':>9}")
    print(hdr)
    print(f"{DIM}{'-'*20} {'-'*7} {'-'*6} {'-'*6} {'-'*7} {'-'*8} {'-'*6} {'-'*6} {'-'*9}{RESET}")

    results = {}
    for key, (label, fn) in STRATEGIES.items():
        t0 = time.perf_counter()
        chunks = fn(text)
        m = evaluate(chunks)
        m.update(evaluate_budget(chunks, 4000))
        m["label"], m["build_s"] = label, time.perf_counter() - t0
        results[key] = m
        sev_c = RED if m["severed_pct"] > 25 else (YELLOW if m["severed_pct"] > 8 else GREEN)
        ovf_c = RED if m["over_256wp_pct"] > 25 else (YELLOW if m["over_256wp_pct"] > 0 else GREEN)
        unr_c = RED if m["unreachable"] else GREEN
        rb_c = GREEN if m["recall_at_budget"] >= .8 else (
            YELLOW if m["recall_at_budget"] >= .6 else RED)
        print(f"{label:<20} {m['n']:>7} {m['mean_chars']:>6} "
              f"{sev_c}{m['severed_pct']:>5.0f}%{RESET} {ovf_c}{m['over_256wp_pct']:>6.0f}%{RESET} "
              f"{unr_c}{m['unreachable']:>8}{RESET} {m['mrr']:>6.3f} "
              f"{DIM}{m['recall'][5]:>6.2f}{RESET} {rb_c}{m['recall_at_budget']:>9.2f}{RESET}")

    # Rank on the honest metric: equal context budget, tie-broken by MRR.
    best = max(results.values(), key=lambda m: (m["recall_at_budget"], m["mrr"]))
    l01 = results["fixed900"]
    print(f"""
{BOLD}Reading the table{RESET}
  {DIM}sev%      chunks starting mid-sentence — the cut landed inside a thought
  >256wp    chunks longer than the encoder's 256 word-piece limit; everything past
            it is SILENTLY DROPPED before embedding (Lesson 02 §10)
  unreach   gold answers severed across a boundary so they exist in NO chunk —
            permanently unretrievable, and invisible from the answer
  R@5       DIMMED ON PURPOSE. Not comparable across chunk sizes: 5 chunks of
            2000 chars is 5× the context of 5 chunks of 400. It rewards spending.
  R@4000ch  the honest one — equal character budget for every strategy{RESET}

{BOLD}Result — ranked on equal context budget{RESET}
  Lesson 01's fixed 900/150 : R@4000ch {l01['recall_at_budget']:.2f}, MRR {l01['mrr']:.3f}, severed {l01['severed_pct']:.0f}%
  Best ({best['label']:<20}): R@4000ch {best['recall_at_budget']:.2f}, MRR {best['mrr']:.3f}, severed {best['severed_pct']:.0f}%
  {GREEN if best['recall_at_budget'] >= l01['recall_at_budget'] else DIM}delta: {best['recall_at_budget']-l01['recall_at_budget']:+.2f} R@4000ch, {best['mrr']-l01['mrr']:+.3f} MRR{RESET}

{DIM}Two things this table teaches, and the second one is the more valuable:

1. You changed no model, no prompt, no k — only WHERE THE TEXT WAS CUT — and
   retrieval quality moved. Chunking is not preprocessing. It is a retrieval
   parameter, and it belongs in your eval sweep.

2. The metric you pick decides who wins. R@5 and R@4000ch rank these strategies
   DIFFERENTLY on the same data. Before you trust any retrieval comparison —
   including this one — ask what each configuration was allowed to spend.{RESET}

{YELLOW}SAMPLE SIZE WARNING — apply this to my table too.{RESET}
{DIM}{len(GOLD)} gold questions means one question is worth {100/len(GOLD):.1f} points. A gap of
0.08 between two strategies is ONE question and is indistinguishable from noise.
Only the large gaps here are real. Your homework raises this to 40+ questions,
which is the minimum for the differences to mean anything.

Note also what recall does NOT measure: `fixed 400/60` and `recursive 900` tie on
R@4000ch, but fixed severs {results['fixed400']['severed_pct']:.0f}% of its chunks mid-sentence and recursive severs
{results['recursive']['severed_pct']:.0f}%. Retrieval found the text either way — but the LLM then has to
READ it, and a chunk beginning ", rerank narrow." is worse context and produces
worse citations. At equal recall, prefer the strategy that severs nothing.{RESET}""")


def cmd_inspect(args) -> None:
    text = CORPUS.read_text(encoding="utf-8")
    label, fn = STRATEGIES[args.strategy]
    chunks = fn(text)
    rule(f"INSPECT — {label}")
    for i, c in enumerate(chunks[:14]):
        head = " ".join(c["text"].split())[:88]
        mark = f"{RED}SEVERED{RESET}" if severed(c) else "       "
        wp = n_word_pieces(c["text"])
        wpm = f"{RED}{wp:>4}wp{RESET}" if wp > 256 else f"{DIM}{wp:>4}wp{RESET}"
        print(f"  {i:>3} {mark} {len(c['text']):>5}ch {wpm}  {head}…")
    if len(chunks) > 14:
        print(f"  {DIM}… {len(chunks)-14} more{RESET}")


def cmd_cliff(_args) -> None:
    """Prove the 256-word-piece truncation bug from Lesson 02 §10."""
    text = CORPUS.read_text(encoding="utf-8")
    rule("THE 256 WORD-PIECE CLIFF")
    m = get_model()
    print(f"{DIM}encoder max_seq_length = {m.max_seq_length} word-pieces. Text past that is")
    print(f"silently discarded before embedding — no warning, no error.{RESET}\n")

    print(f"{'chunk size':>11} {'chunks':>7} {'mean wp':>8} {'% over 256':>11} "
          f"{'chars lost':>11} {'R@5':>6} {'R@4000ch':>9}")
    print(f"{DIM}{'-'*11} {'-'*7} {'-'*8} {'-'*11} {'-'*11} {'-'*6} {'-'*9}{RESET}")
    for size in (400, 900, 1400, 2000, 3000):
        chunks = chunk_fixed(text, size, size // 6)
        wp = [n_word_pieces(c["text"]) for c in chunks]
        over = 100 * sum(w > 256 for w in wp) / len(chunks)
        met = evaluate(chunks, ks=(5,))
        bud = evaluate_budget(chunks, 4000)
        lost = met["truncated_chars"]
        c = RED if over > 50 else (YELLOW if over > 0 else GREEN)
        bc = GREEN if bud["recall_at_budget"] >= .8 else (
            YELLOW if bud["recall_at_budget"] >= .6 else RED)
        print(f"{size:>11} {len(chunks):>7} {int(statistics.mean(wp)):>8} "
              f"{c}{over:>10.0f}%{RESET} {lost:>11,} {DIM}{met['recall'][5]:>6.2f}{RESET} "
              f"{bc}{bud['recall_at_budget']:>9.2f}{RESET}")

    print(f"""
{BOLD}Read the last two columns against each other.{RESET}
{DIM}R@5 (dimmed) says bigger chunks are fine or better. R@5 IS LYING, and it is
worth understanding exactly how, because you will meet this bug in your own
evals: five chunks of 3000 characters is 15,000 characters of context, while
five chunks of 400 is 2,000. The big setting is not retrieving better, it is
retrieving MORE. You are measuring the budget, not the retriever.

R@4000ch holds constant the thing the LLM actually pays for — characters of
context — and fills it with top-ranked chunks. Now the comparison is honest.

Rule 1: your max chunk size is bounded by your ENCODER, not by your LLM's
        context window. Check `model.max_seq_length` before choosing.
Rule 2: when comparing two retrieval configs, ask what each is allowed to
        spend. If the budgets differ, the number is meaningless.{RESET}""")


def cmd_contextual(_args) -> None:
    """Contextual retrieval: prepend context to each chunk before embedding."""
    import aiconfig
    text = CORPUS.read_text(encoding="utf-8")
    rule("CONTEXTUAL RETRIEVAL")
    print(f"{DIM}Each chunk is embedded together with a short description of the document")
    print(f"and its section, so a chunk that says 'this is usually the highest-ROI'")
    print(f"carries WHAT IT IS ABOUT into its own vector.{RESET}")

    base = chunk_structural(text, 900)
    for c in base:
        m = re.search(r"(?m)^#{1,4} +(.+)$", text[:c["start"] + 1])
        heads = re.findall(r"(?m)^#{1,4} +(.+)$", text[:c["start"] + len(c["text"])])
        c["heading"] = heads[-1].strip() if heads else "(preamble)"

    client = aiconfig.client()
    print(f"\n{DIM}asking claude-shim for a one-sentence document description …{RESET}")
    t0 = time.perf_counter()
    doc_desc = client.chat.completions.create(
        model=aiconfig.MODEL,
        messages=[{"role": "user", "content":
                   "In ONE sentence, describe what this document is, for use as retrieval "
                   "context prepended to its chunks. No preamble.\n\n" + text[:6000]}],
    ).choices[0].message.content.strip()
    print(f"  {GREEN}{doc_desc}{RESET}  {DIM}({time.perf_counter()-t0:.1f}s, one call, ~$0.01){RESET}")

    ctx = [{"text": f"{doc_desc}\nSection: {c['heading']}\n\n{c['text']}", "start": c["start"]}
           for c in base]

    a, b = evaluate(base), evaluate(ctx)
    print(f"\n  {'variant':<28} {'R@1':>6} {'R@3':>6} {'R@5':>6} {'MRR':>7}")
    print(f"  {DIM}{'-'*28} {'-'*6} {'-'*6} {'-'*6} {'-'*7}{RESET}")
    print(f"  {'structural (baseline)':<28} {a['recall'][1]:>6.2f} {a['recall'][3]:>6.2f} "
          f"{a['recall'][5]:>6.2f} {a['mrr']:>7.3f}")
    d = b["recall"][5] - a["recall"][5]
    col = GREEN if d > 0 else (RED if d < 0 else DIM)
    print(f"  {'+ contextual prefix':<28} {b['recall'][1]:>6.2f} {b['recall'][3]:>6.2f} "
          f"{col}{b['recall'][5]:>6.2f}{RESET} {b['mrr']:>7.3f}")
    print(f"  {col}{'delta':<28} {b['recall'][1]-a['recall'][1]:>+6.2f} "
          f"{b['recall'][3]-a['recall'][3]:>+6.2f} {d:>+6.2f} {b['mrr']-a['mrr']:>+7.3f}{RESET}")

    print(f"""
{DIM}Anthropic's published version generates a per-chunk contextualisation with an
LLM (one cheap call PER CHUNK, made affordable by prompt caching) and reports
large recall gains. This lab uses the cheap approximation — one document-level
description plus the section heading — which costs a single call.

Whether the delta above is positive on THIS corpus is an empirical question, not
a matter of faith. Report what you measured. A technique that is famous for
working elsewhere and does nothing on your data is a finding, not a failure.{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("compare")
    pi = sub.add_parser("inspect")
    pi.add_argument("strategy", choices=list(STRATEGIES))
    sub.add_parser("cliff")
    sub.add_parser("contextual")
    args = p.parse_args()
    {"compare": cmd_compare, "inspect": cmd_inspect,
     "cliff": cmd_cliff, "contextual": cmd_contextual}[args.cmd](args)


if __name__ == "__main__":
    main()
