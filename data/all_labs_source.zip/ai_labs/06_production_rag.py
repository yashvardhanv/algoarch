"""Lab 06 — Production RAG: permissions, citations, groundedness, long context.

Lessons 01-05 built a system that retrieves well and can be measured. This lab
covers the four things that stand between that and something you can put in front
of real users with real data.

    python 06_production_rag.py acl       # A. pre-filter vs post-filter (a real leak)
    python 06_production_rag.py cite      # B. citation verification — programmatic
    python 06_production_rag.py ground    # C. groundedness as a post-step
    python 06_production_rag.py longctx   # D. long context vs RAG, priced

B/C/D call the LLM through claude-shim.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import re
import statistics
import sys
import time

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
spec = importlib.util.spec_from_file_location("lab4", HERE / "04_retrieval.py")
lab4 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab4)

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")


def rule(s: str) -> None:
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


def client():
    import aiconfig
    return aiconfig.client()


def ask(system: str, user: str, model: str = "sonnet") -> tuple[str, object]:
    r = client().chat.completions.create(
        model=model or aiconfig.MODEL,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
    return r.choices[0].message.content.strip(), r.usage


# =========================================================================== #
# A synthetic multi-tenant corpus. Small on purpose: the point is the ACL
# machinery, not retrieval quality, and you can read every document.
# =========================================================================== #

DOCS = [
    # (id, dept, text)
    ("eng-01", "engineering", "Deployment runbook: services are rolled out with a canary at 5% "
     "for 15 minutes, then 50%, then full. Rollback is automatic if error rate exceeds 2%."),
    ("eng-02", "engineering", "The ingest pipeline retries failed batches three times with "
     "exponential backoff and jitter, then routes them to the dead-letter queue."),
    ("eng-03", "engineering", "On-call rotation is weekly. The primary responder acknowledges "
     "pages within 5 minutes; the secondary is paged after 10 minutes of no acknowledgement."),
    ("eng-04", "engineering", "Postgres connection pooling uses PgBouncer in transaction mode "
     "with a pool size of 40 per service instance."),
    ("eng-05", "engineering", "The vector index is rebuilt nightly at 02:00 UTC. Rebuild takes "
     "approximately 40 minutes for 8 million chunks."),
    ("fin-01", "finance", "Q3 infrastructure spend was 412,000 USD, of which 61 percent was "
     "GPU compute for inference workloads."),
    ("fin-02", "finance", "The annual budget for the platform team is 2.4 million USD, "
     "allocated 70 percent to headcount and 30 percent to infrastructure."),
    ("fin-03", "finance", "Vendor contract with the observability provider renews in January "
     "at 180,000 USD per year, up 12 percent from the previous term."),
    ("hr-01", "hr", "Sarah Chen, staff engineer, has a base salary of 215,000 USD and is on a "
     "performance improvement plan starting in March."),
    ("hr-02", "hr", "The engineering compensation band for L5 is 180,000 to 240,000 USD base, "
     "plus equity refresh at 15 percent of base."),
    ("hr-03", "hr", "Two employees filed grievances in Q2 regarding the return-to-office "
     "policy; both were resolved through mediation."),
]

# Each user's permitted departments.
USERS = {
    "alice  (engineer)":        {"engineering"},
    "bob    (eng manager)":     {"engineering", "finance"},
    "carol  (head of people)":  {"engineering", "finance", "hr"},
}

QUERIES = [
    ("How does the deployment rollout work?", "engineering"),
    ("What did we spend on infrastructure last quarter?", "finance"),
    ("What is Sarah Chen's salary?", "hr"),
    ("What is the L5 compensation band?", "hr"),
    ("How often is the vector index rebuilt?", "engineering"),
]


class AclIndex:
    def __init__(self):
        self.docs = DOCS
        self.texts = [d[2] for d in DOCS]
        self.vecs = lab4.embed(self.texts)

    def rank_all(self, q: str) -> list[int]:
        """Rank EVERY document, ignoring permissions. This is what a naive
        implementation does before it remembers to filter."""
        return [int(i) for i in np.argsort(-(self.vecs @ lab4.embed([q])[0]))]

    def rank_prefiltered(self, q: str, allowed: set[str]) -> list[int]:
        """Restrict the candidate set BEFORE scoring. This is the correct design:
        the retriever never even sees documents the user may not read."""
        idxs = [i for i, d in enumerate(self.docs) if d[1] in allowed]
        if not idxs:
            return []
        sub = self.vecs[idxs]
        order = np.argsort(-(sub @ lab4.embed([q])[0]))
        return [idxs[int(i)] for i in order]


def cmd_acl(_a) -> None:
    idx = AclIndex()
    rule("A. PRE-FILTER vs POST-FILTER — the same bug, twice")
    K = 4

    print(f"{DIM}{len(DOCS)} documents across engineering / finance / hr. Three users with")
    print(f"different permissions. top-k = {K}.{RESET}")

    print(f"\n{BOLD}1. POST-FILTER BLOWS YOUR k{RESET}")
    print(f"{DIM}Retrieve the global top-{K}, then drop what the user may not see.{RESET}\n")
    print(f"  {'query':<44} {'user':<24} {'kept':>6} {'answerable':>11}")
    print(f"  {DIM}{'-'*44} {'-'*24} {'-'*6} {'-'*11}{RESET}")
    counts = {}
    for q, owner in QUERIES:
        for user, allowed in USERS.items():
            top = idx.rank_all(q)[:K]
            kept = [i for i in top if idx.docs[i][1] in allowed]
            ok = any(idx.docs[i][1] == owner for i in kept)
            counts.setdefault(q, []).append(len(kept))
            col = GREEN if len(kept) == K else (YELLOW if kept else RED)
            print(f"  {q[:44]:<44} {user:<24} {col}{len(kept)}/{K}{RESET} "
                  f"{(GREEN + 'yes' if ok else RED + 'no ') + RESET:>20}")
        print()

    print(f"{BOLD}2. THE RESULT COUNT ITSELF IS A LEAK{RESET}")
    print(f"{DIM}A user cannot read the restricted documents — but the NUMBER of results")
    print(f"they get back depends on how many restricted documents matched.{RESET}\n")
    for q, _ in QUERIES:
        c = counts[q]
        if len(set(c)) > 1:
            print(f"  {RED}LEAK{RESET}  {q[:52]:<52} counts by user: {c}")
            print(f"        {DIM}alice sees {c[0]}/{K} and carol sees {c[2]}/{K} → alice can infer "
                  f"{c[2]-c[0]} restricted document(s) exist and match her query{RESET}")
    print(f"\n  {DIM}This is an oracle. Repeat with crafted queries and you enumerate the")
    print(f"  restricted corpus without ever reading a byte of it.{RESET}")

    print(f"\n{BOLD}3. PRE-FILTER — the fix{RESET}")
    print(f"{DIM}Restrict the candidate set BEFORE scoring. Every user gets a full k of")
    print(f"documents they are allowed to read, and the count reveals nothing.{RESET}\n")
    print(f"  {'query':<44} {'user':<24} {'kept':>6} {'answerable':>11}")
    print(f"  {DIM}{'-'*44} {'-'*24} {'-'*6} {'-'*11}{RESET}")
    for q, owner in QUERIES[:3]:
        for user, allowed in USERS.items():
            got = idx.rank_prefiltered(q, allowed)[:K]
            ok = any(idx.docs[i][1] == owner for i in got)
            col = GREEN if len(got) == K else YELLOW
            print(f"  {q[:44]:<44} {user:<24} {col}{len(got)}/{K}{RESET} "
                  f"{(GREEN + 'yes' if ok else DIM + 'n/a') + RESET:>20}")
        print()

    print(f"""{BOLD}4. THE CATASTROPHIC VARIANT — filtering AFTER generation{RESET}
{DIM}Some systems retrieve without filtering, generate an answer, and then filter
the CITATIONS shown to the user. The model has already read the document. Watch
what the answer contains.{RESET}""")
    q = "What is Sarah Chen's salary?"
    top = idx.rank_all(q)[:3]
    block = "\n\n".join(f"[{n}] {idx.texts[i]}" for n, i in enumerate(top, 1))
    out, _ = ask("Answer using only the numbered context passages. Cite as [1], [2]. Be brief.",
                 f"Context:\n\n{block}\n\nQuestion: {q}")
    print(f"\n  {DIM}user:{RESET} alice (engineering only — must NOT see hr)")
    print(f"  {DIM}retrieved without filtering, generated, then citations hidden{RESET}")
    print(f"  {RED}ANSWER SHOWN TO ALICE:{RESET} {' '.join(out.split())[:200]}")
    leaked = "215" in out
    verdict = ("LEAKED — the restricted salary is in the answer text itself" if leaked
               else "no numeric leak in this sample (re-run: generation is stochastic)")
    print(f"\n  {RED if leaked else YELLOW}{verdict}{RESET}")
    print(f"""
{DIM}Hiding the citation does nothing. The content is in the prose. This is why the
rule is PRE-filter, not "filter somewhere": once a restricted document enters the
context window, it is in the answer, in your logs, in your traces, and in any
cache keyed on that context.

Design rule: permissions belong in the RETRIEVAL QUERY, enforced by the same
system that stores the vectors — a WHERE clause, not an application-layer list
comprehension that someone will forget on the third code path.{RESET}""")


# =========================================================================== #
# B. CITATION VERIFICATION — the thing the Lesson 05 judge missed
# =========================================================================== #

CITE_SYS = """Answer using ONLY the numbered context passages.
Every factual claim must carry an inline citation like [1] or [2].
If the passages do not contain the answer, reply exactly: Not in the provided context.
Be direct, three sentences maximum."""

CITE_RE = re.compile(r"\[(\d+)\]")


def verify_citations(answer: str, ctx: list[str]) -> dict:
    """Programmatic citation checks. No LLM call, no judgment, no ambiguity.

    Lesson 05 measured an LLM judge MISSING a mis-citation: it verified that the
    claims were supported and never checked that the cited index was right. That
    is because citation validity is not a judgment — it is three assertions:

      1. every cited id EXISTS in the context you supplied
      2. every claim-bearing sentence CARRIES a citation
      3. the cited passage actually contains the claim's distinctive content

    (1) and (2) are exact. (3) is approximated here with token overlap, which is
    crude but free, deterministic, and catches gross mis-attribution. Use a
    cross-encoder or an NLI model when you need it to be good.
    """
    ids = [int(x) for x in CITE_RE.findall(answer)]
    valid_range = set(range(1, len(ctx) + 1))
    dangling = sorted({i for i in ids if i not in valid_range})

    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", answer) if s.strip()]
    factual = [s for s in sentences if len(s.split()) > 4
               and "not in the provided context" not in s.lower()]
    uncited = [s for s in factual if not CITE_RE.search(s)]

    # (3) overlap between the sentence's content words and its cited passage
    stop = {"the", "a", "an", "is", "are", "was", "were", "of", "to", "in", "and", "for",
            "on", "at", "by", "with", "that", "this", "it", "as", "be", "from", "or"}
    weak = []
    for s in factual:
        cited = [int(x) for x in CITE_RE.findall(s) if int(x) in valid_range]
        if not cited:
            continue
        toks = {w.lower().strip(".,;:%") for w in s.split()} - stop
        toks = {t for t in toks if len(t) > 2 and not CITE_RE.fullmatch(f"[{t}]")}
        best = 0.0
        for c in cited:
            ct = {w.lower().strip(".,;:%") for w in ctx[c - 1].split()} - stop
            best = max(best, len(toks & ct) / max(1, len(toks)))
        if best < 0.30:
            weak.append((s, cited, best))

    return {"ids": ids, "dangling": dangling, "n_factual": len(factual),
            "uncited": uncited, "weak": weak,
            "valid": not dangling and not uncited and not weak}


def cmd_cite(_a) -> None:
    text = lab4.CORPUS.read_text(encoding="utf-8")
    lab4.check_gold(text)
    idx = lab4.Index(lab4.chunk_recursive(text))
    rule("B. CITATION VERIFICATION — a regex, not a judge")
    print(f"""{DIM}Lesson 05's judge missed a mis-citation because "is this citation correct"
is not a judgment call. It is three assertions you can run for free on every
single request in production — which an LLM judge is far too slow and expensive
to do.{RESET}""")

    subset = lab4.GOLD[:12]
    print(f"\n{DIM}generating {len(subset)} cited answers …{RESET}")
    rows = []
    t0 = time.perf_counter()
    for q, _tag, _ans in subset:
        order = lab4.p_hybrid_rerank(idx, q)
        ctx, spent = [], 0
        for ci in order:
            t = idx.texts[int(ci)]
            if spent + len(t) > lab4.BUDGET:
                break
            spent += len(t)
            ctx.append(t)
        block = "\n\n".join(f"[{i}] {t.strip()}" for i, t in enumerate(ctx, 1))
        out, _ = ask(CITE_SYS, f"Context passages:\n\n{block}\n\nQuestion: {q}")
        rows.append({"q": q, "out": out, "ctx": ctx, "check": verify_citations(out, ctx)})
    print(f"{DIM}{time.perf_counter()-t0:.0f}s{RESET}\n")

    print(f"  {'query':<46} {'cites':>6} {'dangling':>9} {'uncited':>8} {'weak':>6} {'ok':>4}")
    print(f"  {DIM}{'-'*46} {'-'*6} {'-'*9} {'-'*8} {'-'*6} {'-'*4}{RESET}")
    for r in rows:
        c = r["check"]
        ok = GREEN + "  ✓" if c["valid"] else RED + "  ✗"
        print(f"  {r['q'][:46]:<46} {len(c['ids']):>6} "
              f"{(RED if c['dangling'] else DIM)}{len(c['dangling']):>9}{RESET} "
              f"{(RED if c['uncited'] else DIM)}{len(c['uncited']):>8}{RESET} "
              f"{(YELLOW if c['weak'] else DIM)}{len(c['weak']):>6}{RESET} {ok}{RESET}")

    n = len(rows)
    valid = sum(r["check"]["valid"] for r in rows)
    dang = sum(len(r["check"]["dangling"]) for r in rows)
    unc = sum(len(r["check"]["uncited"]) for r in rows)
    weak = sum(len(r["check"]["weak"]) for r in rows)
    print(f"\n{BOLD}Citation validity: {valid}/{n} answers fully clean{RESET}")
    print(f"  dangling ids (cited a passage that doesn't exist) : {RED if dang else GREEN}{dang}{RESET}")
    print(f"  uncited factual sentences                          : {RED if unc else GREEN}{unc}{RESET}")
    print(f"  weak attribution (<30% token overlap with cited)   : {YELLOW if weak else GREEN}{weak}{RESET}")

    for r in rows:
        for s, cited, ov in r["check"]["weak"][:1]:
            print(f"\n  {YELLOW}weak attribution example{RESET}  {DIM}(overlap {ov:.0%}, cites {cited}){RESET}")
            print(f"    claim  : {' '.join(s.split())[:100]}")
            print(f"    cited  : {' '.join(r['ctx'][cited[0]-1].split())[:100]}")
            break
        else:
            continue
        break

    print(f"""
{DIM}Cost of this check: ~0 ms, no API call, fully deterministic, and it runs on
100% of production traffic. An LLM judge runs on a sample, costs seconds, and —
as Lesson 05 measured — misses exactly this class of error.

Ship BOTH. The regex is your always-on guard rail; the judge is your sampled
quality measurement. People reach for the judge first because it's the
interesting tool, and skip the one that would actually have caught the bug.{RESET}""")


# =========================================================================== #
# C. GROUNDEDNESS AS A POST-STEP
# =========================================================================== #

def cmd_ground(_a) -> None:
    text = lab4.CORPUS.read_text(encoding="utf-8")
    lab4.check_gold(text)
    idx = lab4.Index(lab4.chunk_recursive(text))
    rule("C. GROUNDEDNESS AS A POST-GENERATION STEP")
    print(f"""{DIM}A prompt that says "use only the context" makes grounding LIKELY. A
post-check makes it VERIFIED. The difference matters when the cost of a confident
wrong answer is high — which is most of the time in production.{RESET}""")

    # Force the failure mode: give the model context that does NOT contain the answer.
    probes = [
        ("What is the roadmap's advice on reranking?", True),
        ("What is the current price of Bitcoin?", False),
        ("How many employees does OpenAI have?", False),
        ("What does the roadmap say about evaluation?", True),
    ]
    print(f"\n  {'question':<46} {'in corpus':>10} {'refused':>8} {'grounded':>9}")
    print(f"  {DIM}{'-'*46} {'-'*10} {'-'*8} {'-'*9}{RESET}")
    for q, in_corpus in probes:
        order = lab4.p_hybrid_rerank(idx, q)
        ctx = [idx.texts[int(c)] for c in order[:4]]
        block = "\n\n".join(f"[{i}] {t.strip()}" for i, t in enumerate(ctx, 1))
        out, _ = ask(CITE_SYS, f"Context passages:\n\n{block}\n\nQuestion: {q}")
        refused = "not in the provided context" in out.lower()
        chk, _ = ask("You verify GROUNDEDNESS. Reply with exactly one word: GROUNDED if every "
                     "claim in the response is supported by the context, or UNGROUNDED if not. "
                     "A refusal counts as GROUNDED.",
                     f"CONTEXT:\n{block[:5000]}\n\nRESPONSE:\n{out}")
        grounded = "ungrounded" not in chk.lower()
        rcol = GREEN if refused == (not in_corpus) else YELLOW
        gcol = GREEN if grounded else RED
        print(f"  {q[:46]:<46} {str(in_corpus):>10} {rcol}{str(refused):>8}{RESET} "
              f"{gcol}{str(grounded):>9}{RESET}")

    print(f"""
{DIM}The escape hatch is what makes this work: when retrieval misses, the correct
output is a refusal, and a refusal is trivially grounded. A system WITHOUT an
escape hatch has no grounded option available when retrieval fails — so it
fabricates, and your groundedness metric collapses through no fault of the
checker.

Pipeline order in production:
  retrieve → generate → verify citations (regex, always) → check groundedness
  (judge, sampled or on high-stakes paths) → serve, or fall back to a refusal.{RESET}""")


# =========================================================================== #
# D. LONG CONTEXT vs RAG
# =========================================================================== #

def cmd_longctx(_a) -> None:
    text = lab4.CORPUS.read_text(encoding="utf-8")
    lab4.check_gold(text)
    idx = lab4.Index(lab4.chunk_recursive(text))
    rule("D. LONG CONTEXT vs RAG — priced, not argued")
    print(f"""{DIM}"Just put the whole document in the context window" is a real architectural
option now. Here it is against retrieval on the same questions, same model.{RESET}""")

    subset = lab4.GOLD[:8]
    PRICE_IN = 3.00 / 1e6      # $/token, mid-tier model

    def run(mode: str):
        hits, toks, lat = 0, [], []
        for q, _tag, ans in subset:
            if mode == "rag":
                order = lab4.p_hybrid_rerank(idx, q)
                ctx, spent = [], 0
                for ci in order:
                    t = idx.texts[int(ci)]
                    if spent + len(t) > lab4.BUDGET:
                        break
                    spent += len(t)
                    ctx.append(t)
                block = "\n\n".join(f"[{i}] {t.strip()}" for i, t in enumerate(ctx, 1))
            else:
                block = f"[1] {text}"
            t0 = time.perf_counter()
            out, usage = ask(CITE_SYS, f"Context passages:\n\n{block}\n\nQuestion: {q}")
            lat.append(time.perf_counter() - t0)
            toks.append(usage.prompt_tokens)
            key = " ".join(ans.split()[:4]).lower().strip("*")
            hits += key in out.lower()
        return {"acc": hits / len(subset), "tok": statistics.mean(toks),
                "lat": statistics.median(lat)}

    print(f"\n{DIM}running {len(subset)} questions through both …{RESET}")
    rag = run("rag")
    print(f"{DIM}  rag done{RESET}")
    full = run("full")
    print(f"{DIM}  long-context done{RESET}\n")

    print(f"  {'approach':<22} {'answered':>9} {'input tok':>11} {'p50 latency':>12} {'$/1k queries':>14}")
    print(f"  {DIM}{'-'*22} {'-'*9} {'-'*11} {'-'*12} {'-'*14}{RESET}")
    for name, m in (("RAG (retrieve top-k)", rag), ("stuff whole document", full)):
        print(f"  {name:<22} {m['acc']:>9.2f} {m['tok']:>11,.0f} {m['lat']:>11.1f}s "
              f"{m['tok']*1000*PRICE_IN:>13.2f}")

    ratio = full["tok"] / max(1, rag["tok"])
    same_acc = abs(full["acc"] - rag["acc"]) < 1e-9
    print(f"""
{BOLD}Long context costs {ratio:.1f}x the input tokens on a {len(text):,}-character document.{RESET}""")
    if same_acc:
        print(f"""{YELLOW}Note honestly: both scored {rag['acc']:.2f}. ACCURACY DOES NOT DISCRIMINATE HERE.{RESET}
{DIM}On a 30k-character corpus the whole thing fits comfortably and the model finds
the answer either way. Anyone running this experiment at this scale and concluding
"long context is just as good" would be right about the accuracy and wrong about
the decision, because the case against long context was never accuracy.{RESET}""")
    print(f"""{DIM}This document is TINY. A real corpus is 10,000x bigger and does not fit at
any price — which is the part the "long context kills RAG" argument keeps
skipping. Note also what the {ratio:.1f}x token bill buys you: nothing. Same answers.

Where each wins:
  LONG CONTEXT   one document, needs global understanding ("summarise this
                 contract", "what are the themes"), corpus fits, cost tolerable
  RAG            corpus larger than the window · per-user permissions · freshness
                 without re-sending · auditability via citations · cost at scale

These are not competitors so much as different tools. The senior answer to "should
we just use long context" is "how big is the corpus, who is allowed to see it, how
often does it change, and what does a wrong answer cost" — not a benchmark.{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for c in ("acl", "cite", "ground", "longctx"):
        sub.add_parser(c)
    a = p.parse_args()
    {"acl": cmd_acl, "cite": cmd_cite, "ground": cmd_ground, "longctx": cmd_longctx}[a.cmd](a)


if __name__ == "__main__":
    main()
