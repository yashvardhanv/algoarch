"""Generate real data for visuals/02-tokens-and-embeddings.html.

Everything the lesson page plots is computed here from the actual tokenizer and
the actual encoder. Nothing in that page is hand-authored illustration.

    python 02_make_viz_data.py   ->  ../visuals/02-viz-data.js
"""

from __future__ import annotations

import json
import pathlib

import numpy as np
import tiktoken
from rank_bm25 import BM25Okapi

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE.parent / "visuals" / "02-viz-data.js"

import importlib.util
spec = importlib.util.spec_from_file_location("lab2", HERE / "02_tokens_and_embeddings.py")
lab2 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab2)

PAIRS_A = [
    ("The feline rested on the rug.", "A cat slept on the carpet.",
     "Zero content words shared. The encoder sees them as near-paraphrase."),
    ("Revenue climbed sharply last quarter.", "Sales were up a lot in Q3.",
     "Business paraphrase with no lexical bridge at all."),
    ("How do I stop my agent looping forever?",
     "Add a step budget, a cost cap, and a loop detector.",
     "Question vs answer — the retrieval asymmetry, quantified."),
]
PAIRS_B = [
    ("The migration succeeded and no data was lost.",
     "The migration did not succeed and data was lost.",
     "NEGATION. One word flips the fact; cosine barely moves."),
    ("Alice sent the payment to Bob.", "Bob sent the payment to Alice.",
     "ROLE REVERSAL. Identical bag of words, inverted fact."),
    ("ERR_5521 is fixed by restarting the ingest worker.",
     "ERR_5522 is fixed by rotating the API credential.",
     "Near-identical identifiers, completely different remediation."),
]


def main() -> None:
    enc = tiktoken.get_encoding("o200k_base")

    # ---- tokenization ----
    samples = []
    base_ratio = None
    for name, text in lab2.SAMPLES:
        ids = enc.encode(text)
        pieces = [enc.decode([t]) for t in ids]
        ratio = len(text) / len(ids)
        if base_ratio is None:
            base_ratio = ratio
        samples.append({
            "name": name, "text": text, "chars": len(text), "tokens": len(ids),
            "chars_per_token": ratio, "cost_vs_english": base_ratio / ratio,
            "pieces": pieces,
        })

    # ---- similarity vs word overlap ----
    def pairblock(pairs):
        V = lab2.embed([t for p in pairs for t in p[:2]])
        return [{
            "a": p[0], "b": p[1], "note": p[2],
            "cosine": float(V[2 * i] @ V[2 * i + 1]),
            "overlap": lab2.word_overlap(p[0], p[1]),
        } for i, p in enumerate(pairs)]

    # ---- BM25 vs dense ----
    tok = lambda s: [w.strip(".,;:!?()").lower() for w in s.split()]
    bm25 = BM25Okapi([tok(c) for c in lab2.CORPUS])
    V = lab2.embed(lab2.CORPUS)
    probes = []
    for q, why in lab2.PROBES:
        b = np.array(bm25.get_scores(tok(q)), dtype=float)
        d = lab2.embed([q])[0] @ V.T
        probes.append({
            "q": q, "why": why,
            "bm25": [float(x) for x in b],
            "dense": [float(x) for x in d],
            "bm25_top": int(np.argmax(b)), "dense_top": int(np.argmax(d)),
            "bm25_all_zero": bool(b.max() == 0),
        })

    # ---- truncation curve ----
    idx = HERE.parent / "data" / "01_index.npz"
    trunc = []
    if idx.exists():
        z = np.load(idx, allow_pickle=False)
        chunks = json.loads(str(z["meta"]))["chunks"]
        full = lab2.embed([c["text"] for c in chunks])
        qs = ["What is reranking?", "How do I evaluate a RAG system?",
              "What defends against prompt injection?", "HNSW vs IVFFlat"]
        QF = lab2.embed(qs)
        gold = [set(np.argsort(-(QF[i] @ full.T))[:5].tolist()) for i in range(len(qs))]
        for d in (384, 256, 192, 128, 96, 64, 48, 32):
            A = full[:, :d]; A = A / np.linalg.norm(A, axis=1, keepdims=True)
            Q = QF[:, :d];   Q = Q / np.linalg.norm(Q, axis=1, keepdims=True)
            hits = sum(len(set(np.argsort(-(Q[i] @ A.T))[:5].tolist()) & gold[i])
                       for i in range(len(qs)))
            trunc.append({"dims": d, "recall": hits / (5 * len(qs)),
                          "bytes_per_vec": d * 4, "gb_per_1m": d * 4 / 1e9 * 1e6})

    data = {
        "samples": samples,
        "pairs_a": pairblock(PAIRS_A),
        "pairs_b": pairblock(PAIRS_B),
        "corpus": lab2.CORPUS,
        "probes": probes,
        "truncation": trunc,
        "meta": {"tokenizer": "o200k_base", "encoder": "all-MiniLM-L6-v2", "dims": 384},
    }
    OUT.write_text("window.VIZ2 = " + json.dumps(data) + ";\n", encoding="utf-8")
    print(f"wrote {OUT} ({OUT.stat().st_size/1024:.0f} KiB)")
    print(f"  samples={len(samples)} probes={len(probes)} trunc_points={len(trunc)}")


if __name__ == "__main__":
    main()
