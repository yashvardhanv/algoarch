"""Generate real data for visuals/03-ingestion-and-chunking.html.

    python 03_make_viz_data.py  ->  ../visuals/03-viz-data.js

Re-runs the same measurements the lab prints, and serialises them so the lesson
page plots your numbers rather than illustrative ones.
"""

from __future__ import annotations

import importlib.util
import json
import pathlib
import statistics

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE.parent / "visuals" / "03-viz-data.js"

spec = importlib.util.spec_from_file_location("lab3", HERE / "03_chunking.py")
lab3 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab3)


def main() -> None:
    text = lab3.CORPUS.read_text(encoding="utf-8")

    strategies = []
    for key, (label, fn) in lab3.STRATEGIES.items():
        chunks = fn(text)
        m = lab3.evaluate(chunks)
        m.update(lab3.evaluate_budget(chunks, 4000))
        strategies.append({
            "key": key, "label": label, "n": m["n"],
            "mean_chars": m["mean_chars"], "max_chars": m["max_chars"],
            "severed_pct": m["severed_pct"], "over_256wp_pct": m["over_256wp_pct"],
            "unreachable": m["unreachable"], "mrr": m["mrr"],
            "recall_at_5": m["recall"][5], "recall_at_1": m["recall"][1],
            "recall_at_budget": m["recall_at_budget"],
        })
        print(f"  {label:<22} R@5 {m['recall'][5]:.2f}  R@4000 {m['recall_at_budget']:.2f}")

    cliff = []
    for size in (400, 700, 900, 1100, 1400, 1700, 2000, 2500, 3000):
        chunks = lab3.chunk_fixed(text, size, size // 6)
        wp = [lab3.n_word_pieces(c["text"]) for c in chunks]
        m = lab3.evaluate(chunks, ks=(5,))
        b = lab3.evaluate_budget(chunks, 4000)
        cliff.append({
            "size": size, "n": len(chunks), "mean_wp": statistics.mean(wp),
            "over_pct": 100 * sum(w > 256 for w in wp) / len(chunks),
            "chars_lost": m["truncated_chars"],
            "recall_at_5": m["recall"][5], "recall_at_budget": b["recall_at_budget"],
        })
        print(f"  size {size:<5} over {cliff[-1]['over_pct']:5.0f}%  "
              f"R@5 {m['recall'][5]:.2f}  R@4000 {b['recall_at_budget']:.2f}")

    # budget sweep — does the winner change with the budget? (homework item 2)
    budgets = [1500, 2500, 4000, 6000, 9000]
    sweep = []
    for bch in budgets:
        row = {"budget": bch}
        for key, (label, fn) in lab3.STRATEGIES.items():
            row[key] = lab3.evaluate_budget(fn(text), bch)["recall_at_budget"]
        sweep.append(row)
        print(f"  budget {bch:<5} " + " ".join(f"{k}={row[k]:.2f}" for k in lab3.STRATEGIES))

    data = {
        "meta": {"corpus": lab3.CORPUS.name, "chars": len(text),
                 "gold": len(lab3.GOLD), "point_value": 100 / len(lab3.GOLD),
                 "encoder_max_wp": 256},
        "strategies": strategies,
        "cliff": cliff,
        "budget_sweep": sweep,
        "strategy_keys": [{"key": k, "label": v[0]} for k, v in lab3.STRATEGIES.items()],
        # measured in 03_parsing.py
        "parsing": {
            "naive":  {"probes": 4, "order_ok": True, "chrome_mid": True,
                       "noise_chars": 88, "welds": 1},
            "layout": {"probes": 1, "order_ok": True, "chrome_mid": False,
                       "noise_chars": 0, "welds": 3},
            "probe_total": 4,
        },
        "contextual": {
            "baseline": {"r1": 0.50, "r3": 0.67, "r5": 0.83, "mrr": 0.633},
            "context":  {"r1": 0.50, "r3": 0.83, "r5": 0.92, "mrr": 0.670},
        },
    }
    OUT.write_text("window.VIZ3 = " + json.dumps(data) + ";\n", encoding="utf-8")
    print(f"\nwrote {OUT} ({OUT.stat().st_size/1024:.0f} KiB)")


if __name__ == "__main__":
    main()
