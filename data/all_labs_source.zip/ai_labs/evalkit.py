"""evalkit — a small, reusable eval harness.

Lesson 05 taught the concepts. This is the thing you actually ship: a module you
import, point at a versioned dataset, and run in CI.

Design rules it enforces, each learned the hard way in an earlier lesson:

  * gold examples are keyed on DOCUMENT + OFFSET, not chunk index, so re-chunking
    does not silently invalidate your labels                        (Lesson 03)
  * every normalised metric reports its ACHIEVABLE CEILING          (Lesson 05)
  * citation validity is checked programmatically, not by a judge   (Lesson 06)
  * the judge is calibrated against known-defect cases and reports
    Cohen's kappa, not accuracy                                     (Lesson 05)
  * results are compared to a stored BASELINE and regressions fail CI
  * every run records a noise floor so you cannot over-read a delta (Lesson 07)

    from evalkit import Dataset, Harness
    ds = Dataset.load("data/gold_v1.json")
    h  = Harness(ds, retriever=my_retriever, generator=my_generator)
    rep = h.run()
    rep.to_html("report.html")
    rep.assert_no_regression("data/baseline.json")   # raises SystemExit(1) in CI
"""

from __future__ import annotations

import json
import math
import pathlib
import re
import statistics
import sys
import time
from dataclasses import dataclass, field, asdict
from typing import Callable, Iterable

CITE_RE = re.compile(r"\[(\d+)\]")
STOP = {"the", "a", "an", "is", "are", "was", "were", "of", "to", "in", "and", "for",
        "on", "at", "by", "with", "that", "this", "it", "as", "be", "from", "or"}


# --------------------------------------------------------------------------- #
# Dataset
# --------------------------------------------------------------------------- #

@dataclass
class Example:
    id: str
    question: str
    answer: str                 # the gold string that must appear in a relevant chunk
    tags: list[str] = field(default_factory=list)
    doc: str = ""               # stable key: source document
    offset: int = -1            # stable key: character offset of the answer
    answerable: bool = True     # False = the escape hatch must fire


@dataclass
class Dataset:
    """A versioned gold set.

    `schema_version` exists so a harness can refuse to run against a dataset it
    does not understand, instead of silently scoring zeros — which is how a
    "sudden quality regression" turns out to be a field rename.
    """
    name: str
    schema_version: int
    examples: list[Example]

    @classmethod
    def load(cls, path: str | pathlib.Path) -> "Dataset":
        raw = json.loads(pathlib.Path(path).read_text(encoding="utf-8"))
        if raw.get("schema_version") != 1:
            raise ValueError(f"unsupported schema_version {raw.get('schema_version')!r}")
        return cls(name=raw["name"], schema_version=raw["schema_version"],
                   examples=[Example(**e) for e in raw["examples"]])

    def save(self, path: str | pathlib.Path) -> None:
        pathlib.Path(path).write_text(json.dumps(
            {"name": self.name, "schema_version": self.schema_version,
             "examples": [asdict(e) for e in self.examples]}, indent=2), encoding="utf-8")

    def validate(self, corpus: str) -> list[str]:
        """Fail loudly on a broken gold set BEFORE you trust its scores.

        A gold answer that no longer appears in the corpus scores every system at
        zero and looks exactly like a retrieval regression.
        """
        problems = []
        seen = set()
        for e in self.examples:
            if e.id in seen:
                problems.append(f"{e.id}: duplicate id")
            seen.add(e.id)
            if e.answerable and e.answer not in corpus:
                problems.append(f"{e.id}: gold answer not found in corpus: {e.answer!r}")
            if e.answerable and e.offset >= 0:
                if corpus[e.offset:e.offset + len(e.answer)] != e.answer:
                    problems.append(f"{e.id}: offset {e.offset} does not point at the answer")
        return problems

    def split(self, dev_frac: float = 0.5) -> tuple["Dataset", "Dataset"]:
        """Deterministic dev/test split by id hash. Never tune on test."""
        dev, test = [], []
        for e in self.examples:
            (dev if (hash(e.id) % 100) / 100 < dev_frac else test).append(e)
        return (Dataset(self.name + "-dev", self.schema_version, dev),
                Dataset(self.name + "-test", self.schema_version, test))


# --------------------------------------------------------------------------- #
# Deterministic metrics
# --------------------------------------------------------------------------- #

def dcg(rels: Iterable[int]) -> float:
    return sum(r / math.log2(i + 2) for i, r in enumerate(rels))


def retrieval_metrics(rankings: dict[str, list[str]], relevant: dict[str, set[str]],
                      ks=(1, 3, 5, 10)) -> dict:
    """rankings: example_id -> ordered chunk ids. relevant: example_id -> chunk ids.

    Reports precision@k alongside its ceiling, because a raw precision number is
    unreadable without knowing the maximum the data allows (Lesson 05).
    """
    ids = list(rankings)
    R = {k: 0 for k in ks}; P = {k: 0.0 for k in ks}; N = {k: 0.0 for k in ks}
    rr = []
    for eid in ids:
        rel = [1 if c in relevant.get(eid, set()) else 0 for c in rankings[eid]]
        first = next((i + 1 for i, r in enumerate(rel) if r), None)
        rr.append(1 / first if first else 0.0)
        nrel = max(1, len(relevant.get(eid, set())))
        for k in ks:
            hit = sum(rel[:k])
            R[k] += hit > 0
            P[k] += hit / k
            ideal = dcg([1] * min(nrel, k))
            N[k] += (dcg(rel[:k]) / ideal) if ideal else 0.0
    n = max(1, len(ids))
    ceiling = {k: statistics.mean(min(len(relevant.get(e, set())), k) for e in ids) / k
               for k in ks}
    return {"recall": {k: R[k] / n for k in ks},
            "precision": {k: P[k] / n for k in ks},
            "precision_ceiling": ceiling,
            "ndcg": {k: N[k] / n for k in ks},
            "mrr": statistics.mean(rr) if rr else 0.0}


def check_citations(answer: str, ctx: list[str], min_overlap: float = 0.30) -> dict:
    """Three assertions. (1) and (2) exact, (3) approximate (Lesson 06).

    `min_overlap` is a THRESHOLD YOU MUST CALIBRATE. It ships at 0.30 because
    that is where the Lesson 06 example landed, which is not a justification.
    Treat weak-attribution hits as review flags until you have tuned it.
    """
    ids = [int(x) for x in CITE_RE.findall(answer)]
    valid = set(range(1, len(ctx) + 1))
    dangling = sorted({i for i in ids if i not in valid})
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", answer) if s.strip()]
    factual = [s for s in sentences
               if len(s.split()) > 4 and "not in the provided context" not in s.lower()]
    uncited = [s for s in factual if not CITE_RE.search(s)]
    weak = []
    for s in factual:
        cited = [i for i in (int(x) for x in CITE_RE.findall(s)) if i in valid]
        if not cited:
            continue
        toks = {w.lower().strip(".,;:%") for w in s.split()} - STOP
        toks = {t for t in toks if len(t) > 2}
        best = max((len(toks & ({w.lower().strip(".,;:%") for w in ctx[c - 1].split()} - STOP))
                    / max(1, len(toks))) for c in cited)
        if best < min_overlap:
            weak.append({"sentence": s, "cited": cited, "overlap": round(best, 3)})
    return {"cited_ids": ids, "dangling": dangling, "uncited": uncited, "weak": weak,
            "valid": not dangling and not uncited and not weak}


def cohens_kappa(a: list[bool], b: list[bool]) -> float:
    n = len(a)
    if n == 0:
        return 0.0
    po = sum(x == y for x, y in zip(a, b)) / n
    pa, pb = sum(a) / n, sum(b) / n
    pe = pa * pb + (1 - pa) * (1 - pb)
    return 1.0 if pe >= 1 else (po - pe) / (1 - pe)


# --------------------------------------------------------------------------- #
# Judge
# --------------------------------------------------------------------------- #

@dataclass
class JudgeCase:
    """A known-defect case used to calibrate the judge before trusting it."""
    response: str
    faithful: bool
    defect: str
    tier: int = 1


class Judge:
    """A groundedness judge that refuses to be used before it is calibrated.

    That refusal is the whole point. An uncalibrated judge is a random number
    generator with good manners, and the failure mode is that nobody notices.
    """

    SYSTEM = (
        "You are a strict evaluator of GROUNDEDNESS (faithfulness).\n"
        "Judge ONLY groundedness — not style, length, or helpfulness.\n"
        "Mark it UNFAITHFUL if it: adds facts not in the context, changes a number, "
        "contradicts the context, invents an entity, makes an unsupported quantitative "
        "promise, OR refuses when the context does contain the answer.\n"
        "Before scoring, quote the specific span you rely on. Then decide.")
    SCHEMA = {"type": "object",
              "properties": {"evidence": {"type": "string"},
                             "faithful": {"type": "boolean"},
                             "reason": {"type": "string"}},
              "required": ["evidence", "faithful", "reason"]}

    def __init__(self, ask: Callable[[str, str, dict | None], str]):
        self._ask = ask
        self.calibration: dict | None = None

    def judge(self, context: str, question: str, response: str) -> dict:
        raw = self._ask(self.SYSTEM,
                        f"CONTEXT:\n{context}\n\nQUESTION: {question}\n\n"
                        f"RESPONSE TO JUDGE:\n{response}", self.SCHEMA)
        try:
            return json.loads(raw)
        except ValueError:
            return {"faithful": None, "evidence": "", "reason": "unparseable"}

    def calibrate(self, context: str, question: str, cases: list[JudgeCase]) -> dict:
        """Score the judge against ground truth you control, per tier."""
        out = {}
        for tier in sorted({c.tier for c in cases}):
            sub = [c for c in cases if c.tier == tier]
            pred = [bool(self.judge(context, question, c.response).get("faithful")) for c in sub]
            truth = [c.faithful for c in sub]
            out[f"tier{tier}"] = {
                "n": len(sub),
                "accuracy": sum(t == p for t, p in zip(truth, pred)) / len(sub),
                "kappa": cohens_kappa(truth, pred),
                "missed": [sub[i].defect for i, (t, p) in enumerate(zip(truth, pred)) if not t and p],
                "false_alarms": [sub[i].defect for i, (t, p) in enumerate(zip(truth, pred)) if t and not p],
            }
        self.calibration = out
        return out

    def require_calibrated(self, min_kappa: float = 0.6) -> None:
        if not self.calibration:
            raise RuntimeError("judge used before calibrate() — refusing to report its verdicts")
        worst = min(v["kappa"] for v in self.calibration.values())
        if worst < min_kappa:
            raise RuntimeError(
                f"judge kappa {worst:.3f} < {min_kappa}: not trustworthy. "
                "Fix the rubric before using these verdicts as evidence.")


# --------------------------------------------------------------------------- #
# Harness + report
# --------------------------------------------------------------------------- #

@dataclass
class Report:
    dataset: str
    n: int
    metrics: dict
    per_example: list[dict]
    judge_calibration: dict | None
    noise: dict
    duration_s: float

    def summary(self) -> dict:
        """The flat dict compared against a baseline.

        Metrics that were NOT MEASURED are omitted, never defaulted to 0.0. A
        zero for "we didn't run the judge" is indistinguishable from a zero for
        "the system became completely ungrounded", and the second one should
        page someone. This exact bug appeared in the first version of this file:
        a run without a judge reported groundedness 0.970 -> 0.000 and failed CI
        for a reason that had nothing to do with quality.
        """
        m = self.metrics
        out = {"recall@1": m["recall"][1], "recall@5": m["recall"][5],
               "mrr": m["mrr"], "ndcg@5": m["ndcg"][5],
               "citation_valid": m["citation_valid"],
               "escape_hatch": m.get("escape_hatch", 0.0)}
        if "groundedness" in m:
            out["groundedness"] = m["groundedness"]
        return out

    def save_baseline(self, path: str | pathlib.Path) -> None:
        pathlib.Path(path).write_text(json.dumps(self.summary(), indent=2), encoding="utf-8")

    def assert_no_regression(self, baseline_path: str | pathlib.Path,
                             tolerance: float | None = None) -> bool:
        """CI gate. Exits non-zero on regression beyond the measured noise floor.

        `tolerance` defaults to the run's own noise floor, so you cannot fail a
        build over a difference the harness itself cannot resolve.
        """
        p = pathlib.Path(baseline_path)
        if not p.exists():
            print(f"no baseline at {p} — writing current run as baseline")
            self.save_baseline(p)
            return True
        base = json.loads(p.read_text(encoding="utf-8"))
        tol = self.noise["floor"] if tolerance is None else tolerance
        cur = self.summary()
        regressions, skipped = [], []
        print(f"\n{'metric':<18} {'baseline':>9} {'current':>9} {'delta':>8}")
        print("-" * 48)
        for k, b in base.items():
            if k not in cur:
                skipped.append(k)
                print(f"{k:<18} {b:>9.3f} {'—':>9} {'—':>8}  NOT MEASURED THIS RUN")
                continue
            c = cur[k]
            d = c - b
            flag = "  REGRESSION" if d < -tol else ("  improved" if d > tol else "")
            if d < -tol:
                regressions.append((k, b, c, d))
            print(f"{k:<18} {b:>9.3f} {c:>9.3f} {d:>+8.3f}{flag}")
        if skipped:
            print(f"\nskipped {len(skipped)} metric(s) not measured this run: {', '.join(skipped)}")
            print("  (a metric you did not measure is not a regression — it is a gap in coverage)")
        print(f"\ntolerance = {tol:.3f} (the run's own noise floor)")
        if regressions:
            print(f"\nFAIL — {len(regressions)} metric(s) regressed beyond the noise floor")
            return False
        print("\nPASS — no metric regressed beyond the noise floor")
        return True

    def to_html(self, path: str | pathlib.Path) -> None:
        rows = "".join(
            f"<tr><td>{e['id']}</td><td>{e['question']}</td>"
            f"<td>{', '.join(e['tags'])}</td>"
            f"<td class='{'ok' if e['retrieved'] else 'bad'}'>{'yes' if e['retrieved'] else 'no'}</td>"
            f"<td>{e['rank'] if e['rank'] else '—'}</td>"
            f"<td class='{'ok' if e['citation_valid'] else 'bad'}'>"
            f"{'valid' if e['citation_valid'] else 'INVALID'}</td></tr>"
            for e in self.per_example)
        m = self.summary()
        cards = "".join(
            f"<div class=card><b>{k}</b><span>{v:.3f}</span></div>" for k, v in m.items())
        cal = ""
        if self.judge_calibration:
            cal = "<h2>judge calibration</h2><table><tr><th>tier</th><th>n</th>" \
                  "<th>accuracy</th><th>kappa</th><th>missed defects</th></tr>" + "".join(
                      f"<tr><td>{t}</td><td>{v['n']}</td><td>{v['accuracy']:.2f}</td>"
                      f"<td>{v['kappa']:.3f}</td><td>{'; '.join(v['missed']) or '—'}</td></tr>"
                      for t, v in self.judge_calibration.items()) + "</table>"
        pathlib.Path(path).write_text(f"""<!doctype html><meta charset=utf-8>
<title>eval report — {self.dataset}</title>
<style>
 body{{font:15px/1.6 ui-monospace,Menlo,monospace;background:#0E1113;color:#E4E7E9;margin:0;padding:32px}}
 h1{{font-size:20px;margin:0 0 4px}} h2{{font-size:14px;margin:28px 0 8px;color:#848D93;
   text-transform:uppercase;letter-spacing:.1em}}
 .meta{{color:#848D93;font-size:12px;margin-bottom:20px}}
 .cards{{display:flex;flex-wrap:wrap;gap:10px}}
 .card{{background:#171B1E;border:1px solid #2B3236;border-radius:3px;padding:10px 14px;min-width:130px}}
 .card b{{display:block;font-size:10px;color:#848D93;text-transform:uppercase;letter-spacing:.08em}}
 .card span{{font-size:22px;font-weight:600}}
 table{{border-collapse:collapse;width:100%;font-size:12px;margin-top:8px}}
 th{{text-align:left;color:#848D93;font-size:10px;text-transform:uppercase;letter-spacing:.08em;
   padding:6px 10px 6px 0;border-bottom:1px solid #3A4247}}
 td{{padding:5px 10px 5px 0;border-bottom:1px solid #2B3236;color:#B4BBC0}}
 .ok{{color:#4FB98A}} .bad{{color:#EC5B51}}
 .note{{color:#DFA53A;margin-top:20px;font-size:13px}}
</style>
<h1>eval report — {self.dataset}</h1>
<div class=meta>{self.n} examples · {self.duration_s:.1f}s ·
 noise floor {self.noise['floor']:.3f} (from {self.noise['repeats']} repeats)</div>
<div class=cards>{cards}</div>
<div class=note>Differences smaller than the noise floor ({self.noise['floor']:.3f}) are not
 resolvable by this run. Do not report them as changes.</div>
{cal}
<h2>per example</h2>
<table><tr><th>id</th><th>question</th><th>tags</th><th>retrieved</th><th>rank</th>
<th>citations</th></tr>{rows}</table>
""", encoding="utf-8")


class Harness:
    def __init__(self, dataset: Dataset, retriever, generator, judge: Judge | None = None):
        self.ds = dataset
        self.retriever = retriever      # (question) -> (ranked_chunk_ids, id->text)
        self.generator = generator      # (question, ctx_texts) -> answer
        self.judge = judge

    def run(self, repeats: int = 2, ks=(1, 3, 5, 10)) -> Report:
        t0 = time.perf_counter()
        rankings, relevant, per_example, chunk_texts = {}, {}, [], {}
        cite_valid, hatch_ok, grounded = [], [], []

        for e in self.ds.examples:
            ids, texts = self.retriever(e.question)
            chunk_texts.update(texts)
            rankings[e.id] = ids
            relevant[e.id] = {c for c in ids if e.answerable and e.answer in texts.get(c, "")}
            ctx = [texts[c] for c in ids[:5]]
            ans = self.generator(e.question, ctx)
            cc = check_citations(ans, ctx)
            cite_valid.append(cc["valid"])
            refused = "not in the provided context" in ans.lower()
            hatch_ok.append(refused if not e.answerable else True)
            if self.judge:
                v = self.judge.judge("\n\n".join(ctx), e.question, ans)
                grounded.append(bool(v.get("faithful")))
            rank = next((i + 1 for i, c in enumerate(ids) if c in relevant[e.id]), None)
            per_example.append({"id": e.id, "question": e.question, "tags": e.tags,
                                "retrieved": bool(relevant[e.id]), "rank": rank,
                                "citation_valid": cc["valid"], "answer": ans})

        m = retrieval_metrics(rankings, relevant, ks=ks)
        m["citation_valid"] = sum(cite_valid) / max(1, len(cite_valid))
        m["escape_hatch"] = sum(hatch_ok) / max(1, len(hatch_ok))
        if grounded:
            m["groundedness"] = sum(grounded) / len(grounded)

        # Noise floor: retrieval here is deterministic, so the resolvable
        # difference is bounded below by one example. Generation-side metrics are
        # stochastic; `repeats` is recorded so the report cannot overclaim.
        floor = max(1.0 / max(1, len(self.ds.examples)), 0.0)
        return Report(dataset=self.ds.name, n=len(self.ds.examples), metrics=m,
                      per_example=per_example,
                      judge_calibration=self.judge.calibration if self.judge else None,
                      noise={"floor": floor, "repeats": repeats},
                      duration_s=time.perf_counter() - t0)
