"""Lab 03b — Parsing. Why ingestion, not retrieval, caps your quality ceiling.

Every RAG tutorial starts from clean markdown. Production starts from a PDF that
a human laid out for a human eye. This lab MAKES such a PDF (two columns, a
table, a header and footer), then extracts it with a normal text extractor and
shows you the damage.

You cannot fix this downstream. No chunker, no reranker and no frontier model
recovers a fact that parsing scrambled. That is what "garbage parsing caps your
ceiling" means, and it is why the roadmap puts parsing first.

    python 03_parsing.py make       # build the adversarial PDF
    python 03_parsing.py extract    # naive extraction — watch it break
    python 03_parsing.py compare    # what a layout-aware pass recovers
"""

from __future__ import annotations

import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
PDF = HERE.parent / "data" / "03_two_column.pdf"

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")

LEFT = """Retrieval quality is the ceiling of any
RAG system. If the passage is never
returned, no model can answer from it.
Hybrid search is the baseline: BM25 for
exact terms and identifiers, dense
vectors for paraphrase. Fuse the two
ranked lists with Reciprocal Rank
Fusion, which merges ranks rather than
scores and therefore needs no tuning."""

RIGHT = """Reranking is the highest-ROI upgrade.
Run a cross-encoder over the top 50 to
100 candidates: retrieve wide, rerank
narrow. Unlike raising k, it improves
quality without inflating the prompt.
Access control must be enforced as a
pre-filter at query time. Never
post-filter results, or you will leak
documents and blow your top-k budget."""

TABLE = [
    ["Index",    "Recall", "Latency", "Memory"],
    ["Flat",     "1.00",   "high",    "1.0x"],
    ["HNSW",     "0.95",   "low",     "1.8x"],
    ["IVFFlat",  "0.88",   "low",     "1.1x"],
]

# Facts a downstream question would need. Used to score the extraction.
PROBES = [
    ("Reciprocal Rank Fusion", "fusion method"),
    ("retrieve wide, rerank narrow", "the reranking rule"),
    ("Never\npost-filter", "the access-control rule (spans a line break)"),
    ("HNSW", "an index type from the table"),
]


def cmd_make(_) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    PDF.parent.mkdir(parents=True, exist_ok=True)
    fig = plt.figure(figsize=(8.27, 11.69))          # A4 portrait
    fig.patch.set_facecolor("white")

    fig.text(0.5, 0.965, "INTERNAL — RETRIEVAL ARCHITECTURE REVIEW",
             ha="center", fontsize=8, color="0.45")
    fig.text(0.5, 0.028, "Page 1 of 1  ·  Confidential  ·  rev 4",
             ha="center", fontsize=8, color="0.45")
    fig.text(0.08, 0.915, "4. Retrieval", fontsize=17, weight="bold")

    fig.text(0.08, 0.88, LEFT, fontsize=10.5, va="top", family="serif", linespacing=1.6)
    fig.text(0.54, 0.88, RIGHT, fontsize=10.5, va="top", family="serif", linespacing=1.6)

    fig.text(0.08, 0.60, "Table 4.1 — Index tradeoffs", fontsize=11, weight="bold")
    ax = fig.add_axes([0.08, 0.42, 0.84, 0.16]); ax.axis("off")
    t = ax.table(cellText=TABLE[1:], colLabels=TABLE[0], loc="center", cellLoc="center")
    t.auto_set_font_size(False); t.set_fontsize(10); t.scale(1, 1.6)

    fig.text(0.08, 0.36, "Figure 4.2 — recall vs latency", fontsize=11, weight="bold")
    ax2 = fig.add_axes([0.08, 0.10, 0.5, 0.24])
    ax2.plot([1, 2, 3], [1.00, 0.95, 0.88], "o-", color="#BE2F27")
    for x, y, s in zip([1, 2, 3], [1.00, 0.95, 0.88], ["Flat", "HNSW", "IVFFlat"]):
        ax2.annotate(s, (x, y), textcoords="offset points", xytext=(6, 6), fontsize=9)
    ax2.set_xlabel("relative speed"); ax2.set_ylabel("recall"); ax2.set_ylim(0.8, 1.05)

    fig.savefig(PDF, format="pdf")
    print(f"wrote {PDF}  ({PDF.stat().st_size/1024:.0f} KiB)")
    print(f"{DIM}Two text columns, a table, a figure, a running header and a footer —")
    print(f"i.e. an entirely ordinary business document.{RESET}")


def naive_extract() -> str:
    from pypdf import PdfReader
    return "\n".join(p.extract_text() or "" for p in PdfReader(str(PDF)).pages)


HEADER = "INTERNAL — RETRIEVAL ARCHITECTURE REVIEW"
FOOTER = "Page 1 of 1"
# Axis ticks and legend text the chart emits as loose "words".
NOISE = re.compile(r"(?m)^\s*(?:\d\.\d{2}\s*)+[a-z]*\s*$|^\s*relative speed\s*$")


def damage_report(text: str, label: str) -> dict:
    """Measure what ACTUALLY broke, rather than what a tutorial says breaks.

    Note for the student: when this lab was first written it asserted that the
    two text columns would interleave. They did not — this PDF's generator emits
    each text block as a unit, so every probe string survived intact. The
    assertion was wrong and the measurement caught it. What genuinely breaks
    here is READING ORDER and NOISE INJECTION, which is subtler and, in a real
    corpus, worse: nothing looks broken.
    """
    flat = " ".join(text.split())
    print(f"\n{BOLD}{label}{RESET}")

    ok = sum(" ".join(p.split()) in flat for p, _ in PROBES)
    print(f"  {GREEN if ok == len(PROBES) else RED}{ok}/{len(PROBES)}{RESET} probe strings survive "
          f"verbatim {DIM}(substring survival is NOT the failure mode here){RESET}")

    # 1. reading order: does a heading precede the body it introduces?
    h, body = text.find("4. Retrieval"), text.find("Retrieval quality is the ceiling")
    order_ok = 0 <= h < body
    print(f"  {GREEN + 'PASS' if order_ok else RED + 'FAIL'}{RESET} reading order — heading "
          f"'4. Retrieval' {'precedes' if order_ok else 'comes AFTER'} its own body text"
          f" {DIM}(char {h} vs {body}){RESET}")

    # 2. chrome contamination inside the body
    hp, fp = text.find(HEADER), text.find(FOOTER)
    chrome_mid = 0 < hp < len(text) * 0.9
    print(f"  {RED + 'FAIL' if chrome_mid else GREEN + 'PASS'}{RESET} page chrome — running header "
          f"at char {hp}, footer at char {fp} of {len(text)} "
          f"{DIM}{'(landed mid-document; will be chunked and indexed)' if chrome_mid else ''}{RESET}")

    # 3. figure noise
    noise = "".join(NOISE.findall(text)) if NOISE.findall(text) else ""
    noise_lines = [l for l in text.splitlines() if NOISE.match(l)]
    noise_chars = sum(len(l) for l in noise_lines)
    print(f"  {RED + 'FAIL' if noise_chars else GREEN + 'PASS'}{RESET} figure noise — "
          f"{len(noise_lines)} lines / {noise_chars} chars of axis ticks extracted as text")

    # 4. glyph welding (two runs drawn adjacently, no space between)
    welds = re.findall(r"\d[a-z]{3,}", text)
    print(f"  {RED + 'FAIL' if welds else GREEN + 'PASS'}{RESET} glyph welding — "
          f"{len(welds)} occurrence(s){(' e.g. ' + repr(welds[0])) if welds else ''}")

    # 5. table header/value association
    hi, vi = text.find("Recall"), text.find("0.95")
    dist = abs(vi - hi) if hi >= 0 and vi >= 0 else -1
    print(f"  {DIM}table — 'Recall' at {hi}, its value '0.95' at {vi} (distance {dist} chars); "
          f"a chunk boundary between them destroys the association{RESET}")

    return {"probes": ok, "order_ok": order_ok, "chrome_mid": chrome_mid,
            "noise_chars": noise_chars, "welds": len(welds)}


def cmd_extract(_) -> None:
    if not PDF.exists():
        sys.exit(f"run `python {pathlib.Path(__file__).name} make` first")
    raw = naive_extract()

    print(f"{CYAN}━━━ RAW EXTRACTION — first 900 chars ━━━{RESET}")
    print(f"{DIM}{raw[:900]}{RESET}")
    print(f"{CYAN}━━━ end ━━━{RESET}")

    damage_report(raw, "Damage report — naive extract_text()")

    print(f"""
{BOLD}What actually went wrong{RESET}
{DIM}Every probe string survived. If you had only checked "is the text still in
there", you would have concluded parsing was fine and gone looking for the bug
in your retriever. It is not fine.

1. DOCUMENT ORDER IS SCRAMBLED. A PDF stores positioned glyphs plus a draw
   order, and the draw order is whatever the generator felt like. Here the TABLE
   and the FIGURE are emitted FIRST, then the page header and footer, and only
   then the section heading and its body — even though on the printed page the
   table sits below the prose. (The local heading→body order does survive; the
   check above passes. It is the document-level order that is wrong.) Chunk this
   sequentially — which every chunker does — and chunk 0 staples a table
   fragment to axis ticks to a page footer.

2. FIGURE AXES BECOME NOISE. The chart's tick labels extract as bare numbers:
   "1.00 1.25 1.50 …" and "0.80 0.85 0.90 0.95 1.00 1.05recall". That last one is
   a GLYPH WELD — two separately-drawn runs with no space between them, producing
   a token that exists in no language. Meanwhile the figure's actual claim
   (recall falls as speed rises) is nowhere in the text at all.

3. HEADER/FOOTER CONTAMINATION. "Page 1 of 1 · Confidential · rev 4" is now
   inside your corpus. It will be chunked, embedded, and can be returned as an
   answer. Across 400 pages it also becomes the single most frequent string in
   your index — which quietly poisons BM25's IDF statistics.

4. TABLE ASSOCIATION IS FRAGILE. "Recall" and its value "0.95" survive, but on
   different lines. One chunk boundary between them and the number is orphaned:
   the digits are present and the fact is gone.{RESET}

{BOLD}The point{RESET}
{DIM}Nothing downstream fixes this. Not a better chunker, not a reranker, not a
frontier model. And note the trap you just watched: the naive check said 4/4.
Parsing failures do not announce themselves — you have to measure the RIGHT
thing, which is why this lab's first version was wrong and the measurement
corrected it.{RESET}""")


def layout_extract() -> str:
    """A crude layout-aware pass: split each page by x-position into columns,
    read the left column top-to-bottom, then the right.

    Real systems use a document-layout model (or a vision model) to detect
    regions, reading order, tables and figures. The point here is not that this
    heuristic is good — it is that column-awareness ALONE recovers facts that
    naive extraction destroys, which tells you where the leverage is.
    """
    from pypdf import PdfReader
    reader = PdfReader(str(PDF))
    out = []
    for page in reader.pages:
        width = float(page.mediabox.width)
        parts: list[tuple[float, float, str]] = []

        def visitor(text, cm, tm, font_dict, font_size):
            if text and text.strip():
                parts.append((tm[4], tm[5], text))

        page.extract_text(visitor_text=visitor)
        mid = width / 2
        for col in (0, 1):
            sel = [p for p in parts if (p[0] < mid) == (col == 0)]
            sel.sort(key=lambda p: (-p[1], p[0]))       # top→bottom, left→right
            line, last_y, buf = [], None, []
            for x, y, t in sel:
                if last_y is not None and abs(y - last_y) > 1.5:
                    buf.append("".join(line)); line = []
                line.append(t); last_y = y
            if line:
                buf.append("".join(line))
            out.append("\n".join(b for b in buf if b.strip()))
    return "\n".join(out)


def cmd_compare(_) -> None:
    if not PDF.exists():
        sys.exit(f"run `python {pathlib.Path(__file__).name} make` first")
    naive, layout = naive_extract(), layout_extract()
    print(f"{CYAN}━━━ NAIVE vs POSITION-AWARE ━━━{RESET}")
    a = damage_report(naive, "Naive extract_text() — draw order")
    b = damage_report(layout, "Position-aware — sort by (column, y descending)")

    def verdict(k, better_is):
        av, bv = a[k], b[k]
        good = (bv == better_is) if isinstance(better_is, bool) else (bv < av)
        return f"{GREEN if good else DIM}{av} → {bv}{RESET}"

    print(f"""
{BOLD}Result — and it is not the result the heuristic was hoping for{RESET}
  probe strings intact  : {RED}{a['probes']}/{len(PROBES)} → {b['probes']}/{len(PROBES)}{RESET}   {RED}◀ REGRESSION{RESET}
  figure-noise chars    : {verdict('noise_chars', None)}
  page chrome in body   : {GREEN}yes → no{RESET}
  glyph welds           : {RED}{a['welds']} → {b['welds']}{RESET}

{YELLOW}THE HAND-ROLLED FIX MADE IT WORSE.{RESET}
{DIM}Splitting by x-position stripped the figure noise and the running header — real
wins — and simultaneously destroyed three of the four facts, because reassembling
lines from raw glyph runs requires knowing where spaces belong, and my 15-line
heuristic does not. It welded more tokens than the naive path it replaced.

Keep this result. It is the honest shape of ingestion work:

  * the obvious heuristic is usually a REGRESSION in some dimension you weren't
    watching, which is why you need a damage report and not an eyeball
  * "we wrote a custom PDF parser" is a common and expensive mistake
  * the reason production teams pay for a layout model is not sophistication —
    it is that the naive version quietly loses facts

Do NOT ship the position-aware path from this file. Reach for a real one:
Docling, Unstructured, LayoutLMv3, or a vision model, plus:
  * OCR fallback for scanned pages, with a confidence threshold
  * table extraction to markdown so headers stay attached to cells
  * figure summarisation with a vision model, stored as text
  * header/footer detection by finding text that repeats across pages
  * reading-order detection rather than a hard x-split{RESET}""")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "make"
    {"make": cmd_make, "extract": cmd_extract, "compare": cmd_compare}[cmd](None)
