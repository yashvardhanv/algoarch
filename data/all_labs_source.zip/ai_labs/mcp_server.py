"""A real MCP server over stdio — no SDK, so nothing is hidden.

MCP (Model Context Protocol) is JSON-RPC 2.0 over a transport (stdio here).
That is the whole protocol. Writing one by hand is ~200 lines and removes all
the mystery; after this you can read any MCP SDK's source.

    # talk to it by hand:
    echo '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}' | python mcp_server.py

    # or use the client:
    python 12_mcp.py handshake

THE THREE PRIMITIVES, and the distinction that actually matters:

  TOOLS      model-controlled. The model decides to call them. Side effects live
             here, which is why they need approval gates and argument validation.
  RESOURCES  application-controlled. The HOST decides what to attach to context.
             The model cannot fetch one on its own — it can only use what it was
             given. This is a security boundary, not a naming convention.
  PROMPTS    user-controlled. Templates a user explicitly invokes (slash commands).

Most people ship everything as a tool. That collapses three different trust
levels into one, and it is the first thing to look at in an MCP threat model.
"""

from __future__ import annotations

import json
import pathlib
import re
import sys
import traceback

HERE = pathlib.Path(__file__).resolve().parent
CORPUS = HERE.parent.parent / "ai-engineer-roadmap.md"
PROTOCOL_VERSION = "2024-11-05"

# --------------------------------------------------------------------------- #
# Capabilities
# --------------------------------------------------------------------------- #

TOOLS = [
    {
        "name": "search_roadmap",
        "description": "Search the AI engineering roadmap for a phrase. Returns matching sections.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "phrase to search for"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 10, "default": 3},
            },
            "required": ["query"],
        },
    },
    {
        "name": "count_mentions",
        "description": "Count how many times a literal string appears in the roadmap.",
        "inputSchema": {
            "type": "object",
            "properties": {"pattern": {"type": "string"}},
            "required": ["pattern"],
        },
    },
]

RESOURCES = [
    {"uri": "roadmap://phases", "name": "Roadmap phase list",
     "description": "The phase headings, application-controlled", "mimeType": "text/plain"},
    {"uri": "roadmap://full", "name": "Full roadmap text",
     "description": "The entire document", "mimeType": "text/markdown"},
]

PROMPTS = [
    {"name": "explain_phase",
     "description": "Explain one phase of the roadmap to a specific audience",
     "arguments": [{"name": "phase", "description": "phase number or name", "required": True},
                   {"name": "audience", "description": "who it's for", "required": False}]},
]


def _text() -> str:
    return CORPUS.read_text(encoding="utf-8")


# --------------------------------------------------------------------------- #
# Handlers
# --------------------------------------------------------------------------- #

def call_tool(name: str, args: dict) -> dict:
    """Every tool validates its own arguments. The schema advertised in
    tools/list is a HINT to the model, not enforcement — the client may be
    buggy, the model may hallucinate, and a hostile client may lie. Validate
    server-side, always."""
    if name == "search_roadmap":
        q = args.get("query")
        if not isinstance(q, str) or not q.strip():
            raise ValueError("query must be a non-empty string")
        limit = args.get("limit", 3)
        if not isinstance(limit, int) or not 1 <= limit <= 10:
            raise ValueError("limit must be an integer between 1 and 10")
        text = _text()
        sections = re.split(r"(?m)^(?=#{2,3} )", text)
        hits = [s for s in sections if q.lower() in s.lower()][:limit]
        if not hits:
            return {"content": [{"type": "text", "text": f"No matches for {q!r}."}]}
        body = "\n\n---\n\n".join(" ".join(h.split())[:400] for h in hits)
        return {"content": [{"type": "text", "text": body}]}

    if name == "count_mentions":
        p = args.get("pattern")
        if not isinstance(p, str) or not p:
            raise ValueError("pattern must be a non-empty string")
        n = _text().lower().count(p.lower())
        return {"content": [{"type": "text", "text": json.dumps({"pattern": p, "count": n})}]}

    raise ValueError(f"unknown tool {name!r}")


def read_resource(uri: str) -> dict:
    if uri == "roadmap://phases":
        heads = re.findall(r"(?m)^## (Phase .+)$", _text())
        return {"contents": [{"uri": uri, "mimeType": "text/plain", "text": "\n".join(heads)}]}
    if uri == "roadmap://full":
        return {"contents": [{"uri": uri, "mimeType": "text/markdown", "text": _text()}]}
    raise ValueError(f"unknown resource {uri!r}")


def get_prompt(name: str, args: dict) -> dict:
    if name != "explain_phase":
        raise ValueError(f"unknown prompt {name!r}")
    phase = args.get("phase", "1")
    audience = args.get("audience", "a senior backend engineer")
    return {
        "description": f"Explain phase {phase}",
        "messages": [{"role": "user", "content": {"type": "text", "text":
                      f"Explain phase {phase} of the AI engineering roadmap to {audience}. "
                      f"Be concrete about what to build."}}],
    }


# --------------------------------------------------------------------------- #
# JSON-RPC plumbing — this is all MCP is
# --------------------------------------------------------------------------- #

def handle(req: dict) -> dict | None:
    method, rid, params = req.get("method"), req.get("id"), req.get("params") or {}

    # A NOTIFICATION has no id and MUST NOT get a response. Replying to one is
    # the single most common hand-rolled-server bug: the client is not waiting
    # for it, so your reply desynchronises the stream and every later response
    # is read as the answer to the wrong request.
    if rid is None:
        return None

    try:
        if method == "initialize":
            return ok(rid, {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {"tools": {}, "resources": {}, "prompts": {}},
                "serverInfo": {"name": "roadmap-mcp", "version": "1.0.0"},
            })
        if method == "tools/list":
            return ok(rid, {"tools": TOOLS})
        if method == "tools/call":
            return ok(rid, call_tool(params.get("name", ""), params.get("arguments") or {}))
        if method == "resources/list":
            return ok(rid, {"resources": RESOURCES})
        if method == "resources/read":
            return ok(rid, read_resource(params.get("uri", "")))
        if method == "prompts/list":
            return ok(rid, {"prompts": PROMPTS})
        if method == "prompts/get":
            return ok(rid, get_prompt(params.get("name", ""), params.get("arguments") or {}))
        if method == "ping":
            return ok(rid, {})
        return err(rid, -32601, f"method not found: {method}")
    except ValueError as e:
        # A TOOL ERROR is not a PROTOCOL ERROR. Returning isError inside a
        # successful result lets the model see and recover from it (Lesson 10);
        # a JSON-RPC error is for malformed requests the model cannot fix.
        if method == "tools/call":
            return ok(rid, {"isError": True,
                            "content": [{"type": "text", "text": f"Tool error: {e}"}]})
        return err(rid, -32602, str(e))
    except Exception as e:  # noqa: BLE001
        return err(rid, -32603, f"internal error: {type(e).__name__}: {e}")


def ok(rid, result):
    return {"jsonrpc": "2.0", "id": rid, "result": result}


def err(rid, code, message):
    return {"jsonrpc": "2.0", "id": rid, "error": {"code": code, "message": message}}


def main() -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError:
            print(json.dumps(err(None, -32700, "parse error")), flush=True)
            continue
        try:
            resp = handle(req)
        except Exception:  # noqa: BLE001
            traceback.print_exc(file=sys.stderr)
            resp = err(req.get("id"), -32603, "unhandled server exception")
        if resp is not None:
            print(json.dumps(resp), flush=True)


if __name__ == "__main__":
    main()
