"""Lab 13 — Multi-agent: measure the tax before you pay it.

The roadmap's honest take: "most 'multi-agent' systems should be one agent with
better tools. Use multiple agents mainly for CONTEXT ISOLATION and ROLE
SEPARATION."

This lab tests that claim on the same task three ways, and reports cost, latency
and quality for each. If multi-agent wins, the numbers will say so.

    python 13_multi_agent.py compare     # A. 1 agent vs supervisor/worker vs critic
    python 13_multi_agent.py isolation   # B. the case where multi-agent genuinely wins
"""

from __future__ import annotations

import argparse
import concurrent.futures as cf
import importlib.util
import json
import pathlib
import statistics
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
spec = importlib.util.spec_from_file_location("lab10", HERE / "10_agent_loop.py")
lab10 = importlib.util.module_from_spec(spec)
sys.modules["lab10"] = lab10
spec.loader.exec_module(lab10)

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")


def rule(s):
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


def ask(system, user):
    import aiconfig
    c = aiconfig.client()
    r = c.chat.completions.create(model=aiconfig.MODEL,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
    u = r.usage
    return r.choices[0].message.content.strip(), (u.prompt_tokens * 3 + u.completion_tokens * 15) / 1e6


TASK = ("Summarise what the AI engineering roadmap says about retrieval, evaluation, "
        "and agents — one paragraph each.")

# Facts that a good answer must contain. Scored programmatically, so "quality"
# is a number and not an impression.
RUBRIC = {
    "retrieval": ["hybrid", "rerank"],
    "evaluation": ["golden", "judge"],
    "agents": ["loop", "tool"],
}


def score(text: str) -> tuple[int, int]:
    t = text.lower()
    hits = sum(1 for terms in RUBRIC.values() for k in terms if k in t)
    total = sum(len(v) for v in RUBRIC.values())
    return hits, total


# --------------------------------------------------------------------------- #
# Three architectures
# --------------------------------------------------------------------------- #

def single_agent() -> dict:
    """One agent, all three subtopics, sequential tool use."""
    t0 = time.perf_counter()
    tr = lab10.run_agent(TASK, lab10.Limits(max_steps=10), verbose=False)
    hits, total = score(tr.answer or "")
    return {"name": "1. single agent", "cost": tr.cost, "wall": time.perf_counter() - t0,
            "steps": len(tr.steps), "calls": len(tr.steps), "hits": hits, "total": total,
            "answer": tr.answer or ""}


def supervisor_workers() -> dict:
    """A supervisor splits the task, three workers run in PARALLEL, supervisor merges."""
    t0 = time.perf_counter()
    subtasks = ["retrieval", "evaluation", "agents"]
    cost = 0.0

    def worker(topic):
        tr = lab10.run_agent(f"What does the AI engineering roadmap say about {topic}? "
                             f"Answer in one paragraph.",
                             lab10.Limits(max_steps=5), verbose=False)
        return tr.answer or "", tr.cost, len(tr.steps)

    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        results = list(ex.map(worker, subtasks))
    cost += sum(r[1] for r in results)
    steps = sum(r[2] for r in results)

    merged, c = ask("Merge these three sections into one answer. Keep all substance. "
                    "Do not add anything not present.",
                    "\n\n".join(f"## {t}\n{r[0]}" for t, r in zip(subtasks, results)))
    cost += c
    hits, total = score(merged)
    return {"name": "2. supervisor + 3 workers", "cost": cost, "wall": time.perf_counter() - t0,
            "steps": steps + 1, "calls": steps + 1, "hits": hits, "total": total, "answer": merged}


def generator_critic() -> dict:
    """One generator, one critic, one revision. ROLE separation, not task splitting."""
    t0 = time.perf_counter()
    tr = lab10.run_agent(TASK, lab10.Limits(max_steps=10), verbose=False)
    cost, steps = tr.cost, len(tr.steps)
    draft = tr.answer or ""

    critique, c = ask("You are a critic. List concrete factual gaps or vague claims in this "
                      "summary of an AI engineering roadmap. Bullet points, no praise.", draft)
    cost += c
    revised, c = ask("Revise the summary to address the critique. Keep it to three paragraphs.",
                     f"SUMMARY:\n{draft}\n\nCRITIQUE:\n{critique}")
    cost += c
    hits, total = score(revised)
    return {"name": "3. generator + critic", "cost": cost, "wall": time.perf_counter() - t0,
            "steps": steps + 2, "calls": steps + 2, "hits": hits, "total": total, "answer": revised}


def cmd_compare(_a) -> None:
    rule("A. ONE AGENT vs MULTI-AGENT — the same task, measured")
    print(f"{DIM}task: {TASK}")
    print(f"quality = how many of {sum(len(v) for v in RUBRIC.values())} required concepts appear "
          f"in the final answer.{RESET}\n")

    REPEATS = 2
    print(f"{DIM}{REPEATS} runs per architecture — the agent's step count is stochastic, so a")
    print(f"single run cannot separate architecture from luck.{RESET}\n")
    agg = []
    for fn in (single_agent, supervisor_workers, generator_critic):
        runs = []
        for i in range(REPEATS):
            print(f"{DIM}  {fn.__name__} run {i+1}/{REPEATS} …{RESET}")
            runs.append(fn())
        agg.append({
            "name": runs[0]["name"], "total": runs[0]["total"],
            "hits": statistics.mean(r["hits"] for r in runs),
            "hits_lo": min(r["hits"] for r in runs), "hits_hi": max(r["hits"] for r in runs),
            "cost": statistics.mean(r["cost"] for r in runs),
            "cost_lo": min(r["cost"] for r in runs), "cost_hi": max(r["cost"] for r in runs),
            "wall": statistics.mean(r["wall"] for r in runs),
            "calls": statistics.mean(r["calls"] for r in runs),
        })

    print(f"\n  {'architecture':<26} {'quality':>11} {'calls':>6} {'cost (range)':>22} {'wall':>8}")
    print(f"  {DIM}{'-'*26} {'-'*11} {'-'*6} {'-'*22} {'-'*8}{RESET}")
    base = agg[0]
    for r in agg:
        q = r["hits"] / r["total"]
        col = GREEN if q >= 0.83 else (YELLOW if q >= 0.6 else RED)
        qs = f"{r['hits']:.1f}/{r['total']} ({r['hits_lo']:.0f}-{r['hits_hi']:.0f})"
        cs = f"${r['cost']:.4f} (${r['cost_lo']:.4f}-${r['cost_hi']:.4f})"
        print(f"  {r['name']:<26} {col}{qs:>11}{RESET} {r['calls']:>6.1f} {cs:>22} "
              f"{r['wall']:>7.1f}s")

    cost_noise = max(r["cost_hi"] - r["cost_lo"] for r in agg)
    q_noise = max(r["hits_hi"] - r["hits_lo"] for r in agg)
    best = max(agg, key=lambda r: r["hits"])
    print(f"""
{YELLOW}NOISE FIRST. Widest cost spread within one architecture: ${cost_noise:.4f}.
Widest quality spread: {q_noise:.0f} concepts.{RESET}
{DIM}Any difference smaller than that is the agent's step count varying, not the
architecture. With {REPEATS} runs this lab cannot resolve small gaps — treat the table as
separating LARGE effects only.{RESET}

{BOLD}A three-act story about n=1, which is the real lesson here{RESET}
{DIM}ACT 1. This lab was written asserting "multi-agent does not buy quality here".

ACT 2. The first run, n=1, said the opposite and said it loudly:
         single agent 3/6 · supervisor 5/6 · generator+critic 6/6 AND cheapest.
       I began rewriting the conclusion.

ACT 3. With {REPEATS} runs per architecture, all three score {base['hits']:.1f}/{base['total']} — quality spread
       {q_noise:.0f} — and the single agent is the CHEAPEST at ${base['cost']:.4f}. The act-2 result
       was the agent's step count varying between 4 and 8 steps, nothing more.

{BOLD}One run nearly made me reverse a correct conclusion.{RESET}{DIM} The cost spread WITHIN a
single architecture (${cost_noise:.4f}) is larger than the gap between architectures. That is
the whole reason Lesson 07 made you measure a noise floor before ranking anything.

{BOLD}What survives{RESET}
  quality      no architecture beat a single agent — the bottleneck was retrieval,
               not coordination, and adding coordinators does not fix retrieval
  cost         single agent cheapest; every extra agent is extra tokens, always
  wall clock   supervisor was FASTEST ({agg[1]['wall']:.0f}s vs {base['wall']:.0f}s) because its workers run in
               parallel — a different budget, and the one that matters if a human
               is waiting

The roadmap's claim holds: most multi-agent systems should be one agent with
better tools. Section B shows the shape where splitting genuinely wins.{RESET}""")


def cmd_isolation(_a) -> None:
    """The case where multi-agent genuinely wins: context isolation."""
    rule("B. WHERE MULTI-AGENT GENUINELY WINS — context isolation")
    print(f"""{DIM}Section A used a task one agent handles. Here is the shape where splitting is
not a tax: each sub-investigation would POISON the others' context.

Three independent research questions. A single agent accumulates all three
transcripts in one window; three isolated agents each see only their own.{RESET}""")

    topics = ["vector index internals", "LLM-as-judge calibration", "prompt injection defence"]

    # single agent, all three sequentially — context grows
    t0 = time.perf_counter()
    tr = lab10.run_agent("Research all three of these and report on each: "
                         + "; ".join(topics), lab10.Limits(max_steps=9), verbose=False)
    single_ctx = sum(len(m["content"]) for m in
                     [{"content": json.dumps(s)} for s in tr.steps])
    single = {"cost": tr.cost, "wall": time.perf_counter() - t0, "ctx": single_ctx,
              "steps": len(tr.steps)}

    # isolated agents
    t0 = time.perf_counter()

    def one(t):
        r = lab10.run_agent(f"Research this and report: {t}", lab10.Limits(max_steps=4),
                            verbose=False)
        ctx = sum(len(json.dumps(s)) for s in r.steps)
        return r.cost, ctx, len(r.steps)

    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        res = list(ex.map(one, topics))
    iso = {"cost": sum(r[0] for r in res), "wall": time.perf_counter() - t0,
           "ctx": max(r[1] for r in res), "steps": sum(r[2] for r in res)}

    print(f"\n  {'approach':<28} {'steps':>6} {'peak ctx':>10} {'cost':>9} {'wall':>8}")
    print(f"  {DIM}{'-'*28} {'-'*6} {'-'*10} {'-'*9} {'-'*8}{RESET}")
    print(f"  {'single agent, 3 topics':<28} {single['steps']:>6} "
          f"{RED}{single['ctx']:>10,}{RESET} ${single['cost']:>8.4f} {single['wall']:>7.1f}s")
    print(f"  {'3 isolated agents':<28} {iso['steps']:>6} "
          f"{GREEN}{iso['ctx']:>10,}{RESET} ${iso['cost']:>8.4f} {iso['wall']:>7.1f}s")

    print(f"""
{BOLD}Peak context per agent is the number that matters{RESET}
{DIM}The single agent carries every topic's transcript in one window: {single['ctx']:,} chars at
peak. Each isolated agent peaks at {iso['ctx']:,} — {single['ctx']/max(1,iso['ctx']):.1f}x smaller. That is the
real argument for splitting, and it is NOT about parallelism:

  * context exhaustion is bounded per agent, so the run can go deeper
  * findings from topic 1 cannot bias the search for topic 3
  * a failure in one branch does not poison the others
  * you can run more topics without redesigning anything

{BOLD}The two legitimate reasons to use multiple agents{RESET}
  CONTEXT ISOLATION  parallel research where each branch's transcript would
                     pollute the others (this section)
  ROLE SEPARATION    generator vs critic — the critic must NOT see the
                     generator's reasoning, or it inherits its blind spots

{BOLD}Everything else{RESET}{DIM} — "an agent per microservice", "a planner agent and an executor
agent", "a team of specialists" — is usually one agent with better tools, paying
coordination cost and a larger failure surface for an org-chart metaphor.{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for c in ("compare", "isolation"):
        sub.add_parser(c)
    a = p.parse_args()
    {"compare": cmd_compare, "isolation": cmd_isolation}[a.cmd](a)


if __name__ == "__main__":
    main()
