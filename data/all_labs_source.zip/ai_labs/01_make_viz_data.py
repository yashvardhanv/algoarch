"""Generate the real data that visuals/01-rag-from-scratch.html renders.

The benches in the HTML are NOT illustrative cartoons — they plot your actual
384-dim MiniLM vectors over ai-engineer-roadmap.md, projected to 2D with PCA.
This script produces that JSON.

    python 01_make_viz_data.py    ->  ../visuals/01-viz-data.json

Why PCA and not t-SNE/UMAP: PCA is a linear projection, so distances in the plot
correspond (lossily but honestly) to distances in the real space. t-SNE would
produce prettier clusters that MEAN NOTHING metrically — it optimises neighbour
preservation, not distance. Showing a t-SNE plot and then talking about cosine
distance would be teaching a falsehood.

Note the variance-explained number the script prints: two dimensions capture only
a fraction of a 384-dim space. The plot is a shadow, not the object. That caveat
is rendered in the HTML too.
"""

from __future__ import annotations

import json
import pathlib

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE.parent / "visuals" / "01-viz-data.json"

import importlib.util
spec = importlib.util.spec_from_file_location("rag", HERE / "01_rag_from_scratch.py")
rag = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rag)

# Queries chosen to demonstrate specific pedagogical points.
QUERIES = [
    ("What is reranking and why is it high ROI?",
     "Dense-only retrieval RANKS THE WRONG CHUNK FIRST. 'Reranking' is a rare exact "
     "token — precisely the case BM25 wins and embeddings lose."),
    ("What defends against indirect prompt injection?",
     "A query the retriever handles well: high score, wide spread, correct chunk first. "
     "Compare the spread to the reranking query."),
    ("How do I stop an agent looping forever?",
     "Question↔passage asymmetry. The corpus says 'step budget, loop detector' — "
     "related in meaning, disjoint in words."),
    ("HNSW vs IVFFlat",
     "Bare technical identifiers. Almost no natural language for the encoder to work with."),
    ("What should I cook for dinner?",
     "OUT OF DOMAIN. Watch the scores: they are LOW BUT NOT ZERO. Cosine similarity always "
     "returns a nearest neighbour, even when nothing is relevant. This is why an absolute "
     "threshold is meaningless and why the escape hatch exists."),
    ("golden dataset",
     "Short keyword-style query — closer to how people actually type."),
]


def main() -> None:
    index = rag.load_index()
    vecs, chunks = index["vecs"], index["chunks"]
    n = len(chunks)

    qtexts = [q for q, _ in QUERIES]
    qvecs = rag.embed(qtexts)

    # PCA fitted on the CHUNKS only, then queries projected into that same basis —
    # so query positions are comparable to chunk positions rather than co-fitted.
    mean = vecs.mean(axis=0)
    centred = vecs - mean
    U, S, Vt = np.linalg.svd(centred, full_matrices=False)
    basis = Vt[:2]                                   # (2, 384)
    coords = centred @ basis.T                       # (n, 2)
    qcoords = (qvecs - mean) @ basis.T               # (q, 2)

    var_explained = float((S[:2] ** 2).sum() / (S ** 2).sum())
    print(f"chunks={n}  PCA variance explained by 2 dims = {var_explained:.1%}")

    # Normalise plot coords to [0,1] over the union of chunk+query points.
    allc = np.vstack([coords, qcoords])
    lo, hi = allc.min(axis=0), allc.max(axis=0)
    span = np.where(hi - lo == 0, 1, hi - lo)
    norm = lambda a: ((a - lo) / span).tolist()

    sims = vecs @ vecs.T
    np.fill_diagonal(sims, -1.0)

    data = {
        "meta": {
            "corpus": "ai-engineer-roadmap.md",
            "model": rag.EMBED_MODEL,
            "dims": int(vecs.shape[1]),
            "n_chunks": n,
            "chunk_size": index["meta"]["chunk_size"],
            "overlap": index["meta"]["overlap"],
            "pca_variance_explained": var_explained,
        },
        "chunks": [
            {
                "id": c["id"],
                "heading": c["heading"],
                "preview": " ".join(c["text"].split())[:260],
                "chars": len(c["text"]),
                "xy": norm(coords[i]),
                "nearest": int(np.argmax(sims[i])),
                "nearest_score": float(sims[i].max()),
            }
            for i, c in enumerate(chunks)
        ],
        "queries": [
            {
                "text": qtexts[i],
                "note": QUERIES[i][1],
                "xy": norm(qcoords[i]),
                "scores": [float(s) for s in (vecs @ qvecs[i])],
            }
            for i in range(len(QUERIES))
        ],
        "chunk_sim_stats": {
            "mean": float(sims[np.triu_indices(n, 1)].mean()),
            "p95": float(np.percentile(sims[np.triu_indices(n, 1)], 95)),
            "max": float(sims[np.triu_indices(n, 1)].max()),
        },
    }

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(data), encoding="utf-8")
    print(f"wrote {OUT}  ({OUT.stat().st_size/1024:.0f} KiB)")

    # Also emit a .js file. The HTML loads THIS, not the .json, because browsers
    # block fetch()/XHR against file:// URLs (opaque origin) while still allowing
    # <script src="...">. So the lesson page works by double-clicking it, with no
    # local web server. Small detail, saves a real support headache.
    js = OUT.with_name("01-viz-data.js")
    js.write_text("window.VIZ_DATA = " + json.dumps(data) + ";\n", encoding="utf-8")
    print(f"wrote {js}  ({js.stat().st_size/1024:.0f} KiB)")


if __name__ == "__main__":
    main()
