"""Lab 02 — Tokenization & Embeddings. What the model actually sees, and what
"similar" actually means.

This lab exists to kill one specific misconception, because it is the single most
common wrong mental model in applied AI:

    WRONG:  "an embedding measures how many words two texts share, roughly
             word frequency and theme"
    RIGHT:  word frequency IS a real technique — it is called BM25/TF-IDF, it is
            SPARSE and LEXICAL, and it is a DIFFERENT SYSTEM from embeddings.
            An embedding is a dense learned coordinate that can score two texts
            as near-identical WHEN THEY SHARE NO WORDS AT ALL.

Section 3 proves this with texts that share zero content words and still score
high, and texts that share almost every word and score as opposites.

    python 02_tokens_and_embeddings.py            # everything
    python 02_tokens_and_embeddings.py tokens     # 1. tokenization
    python 02_tokens_and_embeddings.py letters    # 2. why it can't count letters
    python 02_tokens_and_embeddings.py meaning    # 3. embeddings != word overlap
    python 02_tokens_and_embeddings.py blindspots # 4. what embeddings CANNOT do
    python 02_tokens_and_embeddings.py lexical    # 5. BM25 vs dense, head to head
    python 02_tokens_and_embeddings.py dims       # 6. Matryoshka truncation
"""

from __future__ import annotations

import sys

import numpy as np

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")


def rule(label: str) -> None:
    print(f"\n{CYAN}{'━' * 3} {label} {'━' * max(0, 72 - len(label))}{RESET}")


def sub(label: str) -> None:
    print(f"\n{BOLD}{label}{RESET}")


# --------------------------------------------------------------------------- #
# 1. TOKENIZATION
# --------------------------------------------------------------------------- #

SAMPLES = [
    ("English prose", "The quick brown fox jumps over the lazy dog near the river bank."),
    ("Hindi", "तेज़ भूरी लोमड़ी नदी के किनारे आलसी कुत्ते के ऊपर से कूद जाती है।"),
    ("Gujarati", "ઝડપી કથ્થઈ શિયાળ નદી કિનારે આળસુ કૂતરા ઉપરથી કૂદી જાય છે."),
    ("Python code", "def get_user(user_id: int) -> User:\n    return db.query(User).get(user_id)"),
    ("JSON", '{"user_id": 4211, "status": "active", "roles": ["admin", "billing"]}'),
    ("UUIDs", "3f2504e0-4f89-11d3-9a0c-0305e82c3301 8c1e4b2a-9d77-4f11-b3c2-1a2b3c4d5e6f"),
    ("Whitespace-heavy", "col1        col2        col3\nval1        val2        val3"),
]


def cmd_tokens() -> None:
    import tiktoken
    enc = tiktoken.get_encoding("o200k_base")

    rule("1. TOKENIZATION — what the model actually reads")
    print(f"{DIM}Tokenizer: tiktoken o200k_base (OpenAI). Claude and Llama use different")
    print(f"vocabularies, so exact counts differ — the RATIOS below are the lesson,")
    print(f"not the absolute numbers.{RESET}\n")

    print(f"{'sample':<20} {'chars':>6} {'tokens':>7} {'chars/tok':>10}  {'cost vs English':>16}")
    print(f"{DIM}{'-'*20} {'-'*6} {'-'*7} {'-'*10}  {'-'*16}{RESET}")
    base = None
    for name, text in SAMPLES:
        toks = enc.encode(text)
        ratio = len(text) / len(toks)
        if base is None:
            base = ratio
        rel = base / ratio
        colour = RED if rel > 1.8 else (YELLOW if rel > 1.25 else GREEN)
        print(f"{name:<20} {len(text):>6} {len(toks):>7} {ratio:>10.2f}  "
              f"{colour}{rel:>15.2f}×{RESET}")

    sub("Why this matters, concretely")
    print(f"""\
{DIM}Every API bills per TOKEN, not per character. The same sentence in Hindi or
Gujarati costs multiple times what it costs in English, because those scripts are
under-represented in the BPE merge table — the tokenizer falls back to near-byte-level
splitting. Consequences you will actually hit:

  * a 100k-token context window holds far LESS Gujarati text than English text
  * a per-user token quota silently discriminates by language
  * a translation feature's margin differs per target language{RESET}""")

    sub("Look at the actual pieces")
    for name, text in [SAMPLES[0], SAMPLES[1], SAMPLES[5]]:
        toks = enc.encode(text)[:14]
        pieces = [enc.decode([t]).replace("\n", "\\n") for t in toks]
        print(f"  {name:<18} {DIM}|{RESET}" + f"{DIM}|{RESET}".join(f"{p}" for p in pieces) + f"{DIM}|…{RESET}")
    print(f"\n{DIM}Notice the UUID row: a UUID is a wall of tokens carrying almost no meaning.")
    print(f"Dumping raw IDs into a prompt is one of the cheapest wins to find in an audit.{RESET}")


# --------------------------------------------------------------------------- #
# 2. WHY THE MODEL CAN'T COUNT LETTERS
# --------------------------------------------------------------------------- #

def cmd_letters() -> None:
    import tiktoken
    enc = tiktoken.get_encoding("o200k_base")

    rule("2. WHY THE MODEL CAN'T COUNT LETTERS")
    for word in ["strawberry", "unbelievable", "Mississippi"]:
        toks = enc.encode(word)
        pieces = [enc.decode([t]) for t in toks]
        print(f"  {word:<14} → {len(toks)} token(s): " +
              " ".join(f"{YELLOW}[{p}]{RESET}" for p in pieces))
    print(f"""
{DIM}"strawberry" is not a sequence of 10 letters to the model. It is 2-3 opaque
integers. Asking how many r's it contains is like asking you how many times the
letter 'e' appears in the *bit pattern* of a JPEG — the information is technically
in there, but not in the representation the system operates on.

This is why character-level tasks (counting, reversing, acrostics, precise string
slicing) fail in ways that look like stupidity and are actually a representation
mismatch. THE FIX IS NEVER A BETTER PROMPT. The fix is to do character work in
code, and let the model orchestrate the code.{RESET}""")


# --------------------------------------------------------------------------- #
# shared embedding helper
# --------------------------------------------------------------------------- #

_m = None


def embed(texts: list[str], dims: int | None = None) -> np.ndarray:
    global _m
    if _m is None:
        from sentence_transformers import SentenceTransformer
        print(f"{DIM}loading all-MiniLM-L6-v2 …{RESET}", end="", flush=True)
        _m = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        print(f"{DIM} ok{RESET}")
    v = _m.encode(texts, convert_to_numpy=True, normalize_embeddings=(dims is None))
    if dims is not None:                    # truncate THEN renormalise (Matryoshka)
        v = v[:, :dims]
        v = v / np.linalg.norm(v, axis=1, keepdims=True)
    return v.astype(np.float32)


def word_overlap(a: str, b: str) -> float:
    """Jaccard overlap on content words — a crude stand-in for 'word frequency'."""
    stop = {"the", "a", "an", "is", "was", "were", "of", "to", "in", "and", "it",
            "did", "not", "for", "on", "at", "by", "we", "our", "this", "that", "has"}
    ta = {w.strip(".,;:!?()").lower() for w in a.split()} - stop
    tb = {w.strip(".,;:!?()").lower() for w in b.split()} - stop
    return len(ta & tb) / max(1, len(ta | tb))


def compare(pairs, header: str) -> None:
    texts = [t for p in pairs for t in p[:2]]
    V = embed(texts)
    print(f"\n  {'':<3}{'cosine':>8} {'word-overlap':>14}   {header}")
    print(f"  {DIM}{'-'*3}{'-'*8} {'-'*14}   {'-'*40}{RESET}")
    for i, p in enumerate(pairs):
        a, b = p[0], p[1]
        cos = float(V[2 * i] @ V[2 * i + 1])
        ov = word_overlap(a, b)
        gap = cos - ov
        flag = f"{RED}◀ divergent{RESET}" if abs(gap) > 0.35 else ""
        print(f"  {GREEN if cos > .6 else (YELLOW if cos > .4 else RED)}{cos:>11.3f}{RESET} "
              f"{ov:>14.3f}   {flag}")
        print(f"     {DIM}A: {a}{RESET}")
        print(f"     {DIM}B: {b}{RESET}")
        if len(p) > 2:
            print(f"     {YELLOW}→ {p[2]}{RESET}")
        print()


# --------------------------------------------------------------------------- #
# 3. EMBEDDINGS ARE NOT WORD OVERLAP
# --------------------------------------------------------------------------- #

def cmd_meaning() -> None:
    rule("3. EMBEDDINGS ARE NOT WORD FREQUENCY")
    print(f"""{DIM}Two columns below. `cosine` is the embedding. `word-overlap` is Jaccard over
content words — a crude stand-in for the "word frequency" model of similarity.
If embeddings were about shared words, the two columns would track each other.
Watch them come apart.{RESET}""")

    sub("A · Zero shared words, high similarity")
    compare([
        ("The feline rested on the rug.",
         "A cat slept on the carpet.",
         "0 content words shared. Embedding says near-identical. Word overlap says 0.00."),
        ("Revenue climbed sharply last quarter.",
         "Sales were up a lot in Q3.",
         "Business paraphrase — no lexical bridge at all."),
        ("How do I stop my agent looping forever?",
         "Add a step budget, a cost cap, and a loop detector.",
         "QUESTION vs ANSWER. This is the asymmetry from Lesson 01, quantified."),
    ], "A / B")

    sub("B · Many shared words, opposite meaning")
    compare([
        ("The migration succeeded and no data was lost.",
         "The migration did not succeed and data was lost.",
         "NEGATION. Nearly every word shared. Meanings are opposite. Cosine barely moves."),
        ("Alice sent the payment to Bob.",
         "Bob sent the payment to Alice.",
         "ROLE REVERSAL. Identical bag of words, inverted fact."),
    ], "A / B")

    print(f"""{DIM}
Read the two blocks together and the correct mental model falls out:

  an embedding scores MEANING-AS-USED-IN-CONTEXT, learned from data.
  It is not counting anything.

Block A is why dense retrieval exists at all: it finds the answer when the user's
words and the document's words have nothing in common.
Block B is why dense retrieval alone is never enough: it is nearly blind to
negation and to argument order, which are exactly the things that flip a fact.{RESET}""")


# --------------------------------------------------------------------------- #
# 4. BLIND SPOTS
# --------------------------------------------------------------------------- #

def cmd_blindspots() -> None:
    rule("4. WHAT EMBEDDINGS CANNOT DO")

    sub("A · Near-identical identifiers, different meaning")
    ids = ["ERR_5521", "ERR_5522", "ERR_9834", "invoice INV-2024-0001", "invoice INV-2024-0002"]
    V = embed(ids)
    print()
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            c = float(V[i] @ V[j])
            if c > 0.85:
                print(f"  {RED}{c:.3f}{RESET}  {ids[i]:<24} ≈ {ids[j]}")
    print(f"""
{DIM}These score as near-duplicates. If a user asks about ERR_5521 you may confidently
retrieve the ERR_5522 doc and answer with the wrong remediation. Exact tokens are
where dense retrieval structurally fails — and where BM25 is perfect, because BM25
does an exact term match. THIS IS THE WHOLE ARGUMENT FOR HYBRID SEARCH.{RESET}""")

    sub("B · Topical ≠ answer-bearing")
    q = "What is the capital of Australia?"
    cands = [
        "Canberra is the capital of Australia.",
        "Australia is a country famous for its capital cities, beaches and wildlife; "
        "many travellers ask about capitals when visiting Australia.",
        "Sydney is Australia's largest city and is often mistaken for the capital.",
    ]
    V = embed([q] + cands)
    print()
    for i, c in enumerate(cands):
        print(f"  {V[0] @ V[i+1]:.3f}  {c[:76]}")
    print(f"""
{DIM}The chunk that merely TALKS ABOUT capitals can outrank or nearly tie the chunk
that ANSWERS. Cosine measures aboutness, not answerhood. A cross-encoder reranker
(Lesson 04) is the fix: it reads the query and the passage TOGETHER and scores
"does this answer that", which a bi-encoder structurally cannot do.{RESET}""")

    sub("C · Out-of-domain queries still return a confident nearest neighbour")
    q2 = "What should I cook for dinner tonight?"
    V = embed([q2] + cands)
    print()
    for i, c in enumerate(cands):
        print(f"  {V[0] @ V[i+1]:.3f}  {c[:76]}")
    print(f"""
{DIM}Nothing here is relevant. The scores are low but NOT zero, and argsort still
returns a ranked top-k. Retrieval has no concept of "no result". This is why an
absolute threshold is a bug and why the escape hatch is the highest-ROI line in a
RAG prompt.{RESET}""")


# --------------------------------------------------------------------------- #
# 5. BM25 vs DENSE, HEAD TO HEAD
# --------------------------------------------------------------------------- #

CORPUS = [
    "To resolve ERR_5521, restart the ingest worker and clear the staging bucket.",
    "To resolve ERR_5522, rotate the API credential; the worker restart does nothing.",
    "The feline rested on the rug in the afternoon sun.",
    "Our revenue climbed sharply last quarter across every product line.",
    "Add a step budget, a cost cap, and a loop detector to bound agent execution.",
    "HNSW builds a navigable small-world graph; IVFFlat partitions vectors into lists.",
    "Reciprocal Rank Fusion merges two ranked lists without tuning score scales.",
]

PROBES = [
    ("ERR_5522", "exact rare identifier"),
    ("how do I stop an agent from looping forever", "paraphrase, no shared words"),
    ("a cat slept on the carpet", "paraphrase, no shared words"),
    ("RRF", "acronym the encoder has never meaningfully seen"),
]


def cmd_lexical() -> None:
    from rank_bm25 import BM25Okapi

    rule("5. BM25 vs DENSE — the same corpus, opposite failures")
    tok = lambda s: [w.strip(".,;:!?()").lower() for w in s.split()]
    bm25 = BM25Okapi([tok(c) for c in CORPUS])
    V = embed(CORPUS)

    for q, why in PROBES:
        b = np.array(bm25.get_scores(tok(q)), dtype=float)
        d = embed([q])[0] @ V.T
        bi, di = int(np.argmax(b)), int(np.argmax(d))
        agree = bi == di
        print(f"\n  {BOLD}{q!r}{RESET}  {DIM}({why}){RESET}")
        print(f"    BM25  → {GREEN if agree else YELLOW}#{bi}{RESET} score {b[bi]:6.2f}  "
              f"{DIM}{CORPUS[bi][:58]}{RESET}")
        print(f"    dense → {GREEN if agree else YELLOW}#{di}{RESET} score {d[di]:6.3f}  "
              f"{DIM}{CORPUS[di][:58]}{RESET}")
        if b.max() == 0:
            print(f"    {RED}BM25 scored ZERO on every document — no query term appears "
                  f"anywhere. Lexical search cannot degrade gracefully.{RESET}")
        elif not agree:
            print(f"    {YELLOW}DISAGREE — this is exactly the case hybrid search exists for.{RESET}")

    print(f"""
{DIM}Summary you should be able to give cold:

  BM25 wins   exact terms, IDs, error codes, product names, acronyms, rare tokens.
              It is also fully explainable and needs no model.
  BM25 loses  any query that shares no words with the answer (returns 0.00 for
              everything — total failure, not graceful degradation).
  Dense wins  paraphrase, synonyms, question→answer, cross-lingual.
  Dense loses exact identifiers, negation, argument order, out-of-domain jargon.

They fail on DISJOINT query sets. That is why you run both and fuse — and why the
roadmap calls hybrid the BASELINE, not an optimisation.{RESET}""")


# --------------------------------------------------------------------------- #
# 6. DIMENSION TRUNCATION
# --------------------------------------------------------------------------- #

def cmd_dims() -> None:
    rule("6. DIMENSION TRUNCATION — the memory/quality knob")
    import pathlib
    import json
    idx = pathlib.Path(__file__).resolve().parent.parent / "data" / "01_index.npz"
    if not idx.exists():
        print(f"{YELLOW}Run `python 01_rag_from_scratch.py index` first — this section "
              f"reuses that corpus.{RESET}")
        return
    z = np.load(idx, allow_pickle=False)
    chunks = json.loads(str(z["meta"]))["chunks"]
    texts = [c["text"] for c in chunks]

    full = embed(texts)
    queries = ["What is reranking?", "How do I evaluate a RAG system?",
               "What defends against prompt injection?", "HNSW vs IVFFlat"]
    QF = embed(queries)
    gold = [list(np.argsort(-(QF[i] @ full.T))[:5]) for i in range(len(queries))]

    print(f"\n  {'dims':>5} {'bytes/vec':>10} {'1M chunks':>11} {'recall@5 vs full':>18}")
    print(f"  {DIM}{'-'*5} {'-'*10} {'-'*11} {'-'*18}{RESET}")
    for d in (384, 256, 128, 64, 32):
        V = full[:, :d]
        V = V / np.linalg.norm(V, axis=1, keepdims=True)
        Q = QF[:, :d]
        Q = Q / np.linalg.norm(Q, axis=1, keepdims=True)
        hits = 0
        for i in range(len(queries)):
            top = list(np.argsort(-(Q[i] @ V.T))[:5])
            hits += len(set(top) & set(gold[i]))
        rec = hits / (5 * len(queries))
        col = GREEN if rec >= .9 else (YELLOW if rec >= .7 else RED)
        print(f"  {d:>5} {d*4:>10} {d*4/1e9*1e6:>10.2f}GB {col}{rec:>17.0%}{RESET}")

    print(f"""
{DIM}all-MiniLM is NOT a Matryoshka model, so this truncation is unusually lossy —
that is itself the lesson. Models trained with Matryoshka Representation Learning
(e.g. the text-embedding-3 family, nomic-embed) pack the most important information
into the LEADING dimensions on purpose, so you can slice 3072 → 256 and lose only a
few points of recall while cutting memory 12×.

The senior move: don't ask "which embedding model scores highest on a leaderboard".
Ask "at what dimension does recall@k fall below my threshold ON MY CORPUS" — then
buy the memory saving. That is a measurement, and it takes ten minutes.{RESET}""")


CMDS = {"tokens": cmd_tokens, "letters": cmd_letters, "meaning": cmd_meaning,
        "blindspots": cmd_blindspots, "lexical": cmd_lexical, "dims": cmd_dims}

if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    # Warm the encoder BEFORE any section prints, so the load message never lands
    # in the middle of a table.
    if which in ("all", "meaning", "blindspots", "lexical", "dims"):
        embed(["warm up"])
    if which == "all":
        for fn in CMDS.values():
            fn()
    elif which in CMDS:
        CMDS[which]()
    else:
        sys.exit(f"unknown section {which!r}. options: {', '.join(CMDS)}")
