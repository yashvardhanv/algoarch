"""Lab 05 — Evaluation. The phase that makes you senior.

Lessons 01-04 built four retrieval systems and ranked them on recall. Recall says
NOTHING about whether the model actually used what you retrieved. This lab closes
that gap and then turns the instrument on itself: an LLM judge is a measuring
device, and an uncalibrated measuring device is a random number generator with
good manners.

    python 05_evaluation.py metrics     # A. the retrieval metric suite (local, fast)
    python 05_evaluation.py failures    # B. retrieval failure vs generation failure
    python 05_evaluation.py judge       # C. judge calibration vs known ground truth
    python 05_evaluation.py bias        # D. position and verbosity bias, measured

B/C/D call the LLM through claude-shim. Start it first:
    python ../tools/claude_shim/server.py
"""

from __future__ import annotations

import argparse
import concurrent.futures as cf
import importlib.util
import json
import math
import pathlib
import re
import statistics
import sys
import time

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("lab4", HERE / "04_retrieval.py")
lab4 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab4)

DIM, BOLD, CYAN, YELLOW, GREEN, RED, RESET = (
    "\033[2m", "\033[1m", "\033[36m", "\033[33m", "\033[32m", "\033[31m", "\033[0m")

sys.path.insert(0, str(HERE))
import aiconfig                      # noqa: E402  provider comes from env
SHIM, MODEL = aiconfig.BASE_URL, aiconfig.MODEL
WORKERS = 4          # matches claude-shim's default concurrency cap


def rule(s: str) -> None:
    print(f"\n{CYAN}{'━' * 3} {s} {'━' * max(0, 74 - len(s))}{RESET}")


def client():
    return aiconfig.client()


def ask(system: str, user: str, schema: dict | None = None) -> str:
    kw = {}
    if schema:
        kw["response_format"] = {"type": "json_schema",
                                 "json_schema": {"name": "verdict", "schema": schema}}
    r = client().chat.completions.create(
        model=MODEL,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
        **kw)
    return r.choices[0].message.content.strip()


def parallel(fn, items, workers=WORKERS):
    """Run fn over items concurrently. The shim spawns one `claude` process per
    request and caps at 4, so more workers just queue."""
    out = [None] * len(items)
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(fn, it): i for i, it in enumerate(items)}
        done = 0
        for f in cf.as_completed(futs):
            out[futs[f]] = f.result()
            done += 1
            # progress goes to stderr so piping stdout to a file or a grep keeps
            # the tables clean
            print(f"\r  {done}/{len(items)} …", end="", file=sys.stderr, flush=True)
    print("\r" + " " * 30 + "\r", end="", file=sys.stderr, flush=True)
    return out


# =========================================================================== #
# A. THE RETRIEVAL METRIC SUITE
# =========================================================================== #

def dcg(rels: list[int]) -> float:
    return sum(r / math.log2(i + 2) for i, r in enumerate(rels))


def retrieval_metrics(idx, fn, ks=(1, 3, 5, 10)) -> dict:
    """recall@k, precision@k, MRR, NDCG@k — computed from the same rankings.

    WHY EACH ONE EXISTS (this is the part people skip):

      recall@k     did I get the answer AT ALL within k?  → the ceiling on quality
      precision@k  what fraction of what I retrieved was relevant? → the cost of noise
      MRR          how high did the FIRST correct one land? → survives a budget?
      NDCG@k       like MRR but credits multiple relevant docs, discounted by rank

    precision@k is bounded above by mean(min(n_relevant, k)) / k, which on a
    gold set with few relevant chunks per question is a SMALL number. So the lab
    COMPUTES that ceiling and prints it beside the score.

    This is not pedantry. The first version of this lab asserted "one relevant
    chunk per question, so P@5 tops out at 0.20" — and then measured P@5 = 0.23,
    which is impossible under that assumption. Counting revealed 23 questions
    with 1 relevant chunk, 6 with 2, and 1 with 3. Never quote a normalised
    metric without knowing its achievable maximum on YOUR data.
    """
    R = {k: 0 for k in ks}
    P = {k: 0.0 for k in ks}
    N = {k: 0.0 for k in ks}
    rr = []
    for q, _tag, ans in lab4.GOLD:
        order = fn(idx, q)
        rel = [1 if ans in idx.texts[int(c)] else 0 for c in order]
        first = next((i + 1 for i, r in enumerate(rel) if r), None)
        rr.append(1 / first if first else 0.0)
        n_rel = sum(rel)
        for k in ks:
            hit = sum(rel[:k])
            R[k] += (hit > 0)
            P[k] += hit / k
            ideal = dcg([1] * min(n_rel, k))
            N[k] += (dcg(rel[:k]) / ideal) if ideal else 0.0
    n = len(lab4.GOLD)
    n_rel_each = [sum(1 for t in idx.texts if ans in t) for _q, _t, ans in lab4.GOLD]
    return {"recall": {k: R[k] / n for k in ks},
            "precision": {k: P[k] / n for k in ks},
            "ndcg": {k: N[k] / n for k in ks},
            "mrr": statistics.mean(rr),
            # achievable maximum for precision@k on THIS gold set
            "p_ceiling": {k: statistics.mean(min(r, k) for r in n_rel_each) / k for k in ks},
            "rel_dist": {r: n_rel_each.count(r) for r in sorted(set(n_rel_each))}}


def cmd_metrics(_a) -> None:
    text = lab4.CORPUS.read_text(encoding="utf-8")
    lab4.check_gold(text)
    idx = lab4.Index(lab4.chunk_recursive(text))
    rule("A. THE RETRIEVAL METRIC SUITE")

    results = {}
    for key, (label, fn) in lab4.PIPELINES.items():
        results[key] = retrieval_metrics(idx, fn)
    any_m = next(iter(results.values()))
    dist = any_m["rel_dist"]
    ceil5 = any_m["p_ceiling"][5]

    print(f"{DIM}{len(lab4.GOLD)} questions · relevant chunks per question: "
          f"{', '.join(f'{v}q have {k}' for k, v in dist.items())}")
    print(f"⇒ precision@5 cannot exceed {ceil5:.3f} on this gold set{RESET}\n")

    print(f"{'pipeline':<26} {'R@1':>6} {'R@5':>6} {'R@10':>6} {'P@5':>6} {'%ceil':>6} "
          f"{'NDCG@5':>7} {'MRR':>7}")
    print(f"{DIM}{'-'*26} {'-'*6} {'-'*6} {'-'*6} {'-'*6} {'-'*6} {'-'*7} {'-'*7}{RESET}")
    for key, (label, _fn) in lab4.PIPELINES.items():
        m = results[key]
        pct = m["precision"][5] / ceil5
        col = GREEN if pct >= 0.85 else (YELLOW if pct >= 0.6 else RED)
        print(f"{label.strip():<26} {m['recall'][1]:>6.2f} {m['recall'][5]:>6.2f} "
              f"{m['recall'][10]:>6.2f} {m['precision'][5]:>6.2f} {col}{pct:>5.0%}{RESET} "
              f"{m['ndcg'][5]:>7.3f} {m['mrr']:>7.3f}")

    r = results["hybrid+rerank"]
    d = results["dense"]
    print(f"""
{BOLD}How to read this{RESET}
{DIM}P@5 is NOT bad at {r['precision'][5]:.2f} — it is {r['precision'][5]/ceil5:.0%} of the {ceil5:.3f} maximum this gold set
allows. A raw precision number is meaningless without its ceiling. (The first
version of this lab asserted a 0.20 ceiling, then measured 0.23. Counting fixed
the claim; asserting would have shipped a wrong lesson.)

THE GAP BETWEEN R@1 AND R@10 IS A DIAGNOSIS.
  dense          R@1 {d['recall'][1]:.2f} → R@10 {d['recall'][10]:.2f}   gap {d['recall'][10]-d['recall'][1]:.2f}
  hybrid+rerank  R@1 {r['recall'][1]:.2f} → R@10 {r['recall'][10]:.2f}   gap {r['recall'][10]-r['recall'][1]:.2f}
A LARGE gap means the answer is being retrieved and merely RANKED badly — a
reranking problem, and the cheapest kind to fix. Reranking closed most of dense's
gap, which is exactly what it is for. A system with a SMALL gap and low R@10 has
a genuine retrieval problem instead, and no reranker will save it.

MRR and NDCG@5 track closely here because most questions have one relevant chunk.
On corpora where several chunks are relevant they diverge, and NDCG is the one
you want because it credits finding more than one.{RESET}""")


# =========================================================================== #
# B. RETRIEVAL FAILURE vs GENERATION FAILURE
# =========================================================================== #

ANSWER_SYS = """You answer using ONLY the numbered context passages.
- Cite passages inline as [1], [2].
- If the passages do not contain the answer, reply exactly: Not in the provided context.
- Be direct. Two sentences maximum."""


def cmd_failures(_a) -> None:
    text = lab4.CORPUS.read_text(encoding="utf-8")
    lab4.check_gold(text)
    idx = lab4.Index(lab4.chunk_recursive(text))
    rule("B. RETRIEVAL FAILURE vs GENERATION FAILURE")
    print(f"""{DIM}The single most valuable diagnostic in RAG. For each question ask two
independent yes/no questions:

    (1) was the answer PRESENT in the retrieved context?   → retrieval
    (2) did the final answer actually contain it?           → generation

That 2x2 tells you which half of the system to work on. Conflating them is how
teams spend two weeks on prompts to fix a chunking bug.{RESET}""")

    pipe = lab4.p_dense           # deliberately the WEAK retriever, to get failures
    subset = lab4.GOLD[:16]

    def one(item):
        q, tag, ans = item
        order = pipe(idx, q)
        ctx, spent = [], 0
        for r, ci in enumerate(order, 1):
            t = idx.texts[int(ci)]
            if spent + len(t) > lab4.BUDGET:
                break
            spent += len(t)
            ctx.append((r, t))
        present = any(ans in t for _, t in ctx)
        block = "\n\n".join(f"[{i}] {t.strip()}" for i, (_, t) in enumerate(ctx, 1))
        out = ask(ANSWER_SYS, f"Context passages:\n\n{block}\n\nQuestion: {q}")
        # "used" = the answer string (or its distinctive head) appears in the output
        key = " ".join(ans.split()[:4]).lower().strip("*")
        used = key in out.lower()
        refused = "not in the provided context" in out.lower()
        return {"q": q, "tag": tag, "ans": ans, "present": present, "ctx_block": block,
                "used": used, "refused": refused, "out": out}

    print(f"{DIM}generating {len(subset)} answers via claude-shim …{RESET}")
    t0 = time.perf_counter()
    rows = parallel(one, subset)
    print(f"{DIM}{time.perf_counter()-t0:.0f}s total{RESET}\n")

    quad = {"ok": [], "gen_fail": [], "ret_fail_honest": [], "ret_fail_halluc": []}
    for r in rows:
        if r["present"] and r["used"]:
            quad["ok"].append(r)
        elif r["present"] and not r["used"]:
            quad["gen_fail"].append(r)
        elif not r["present"] and r["refused"]:
            quad["ret_fail_honest"].append(r)
        else:
            quad["ret_fail_halluc"].append(r)

    n = len(rows)
    print(f"                          {BOLD}answer used in output?{RESET}")
    print(f"                          {'YES':>12} {'NO':>12}")
    print(f"  {BOLD}context had it   YES{RESET}   {GREEN}{len(quad['ok']):>12}{RESET} "
          f"{YELLOW}{len(quad['gen_fail']):>12}{RESET}   {DIM}← GENERATION failure{RESET}")
    print(f"  {BOLD}                  NO{RESET}   {RED}{len(quad['ret_fail_halluc']):>12}{RESET} "
          f"{DIM}{len(quad['ret_fail_honest']):>12}{RESET}   {DIM}← RETRIEVAL failure{RESET}")
    print(f"                          {DIM}↑ hallucinated{RESET}  {DIM}↑ refused (correct!){RESET}")

    print(f"\n{BOLD}Interpretation{RESET}")
    print(f"  {GREEN}{len(quad['ok'])}/{n} correct{RESET} — retrieval and generation both did their job")
    print(f"  {YELLOW}{len(quad['gen_fail'])}/{n} GENERATION failures{RESET} — the answer was RIGHT THERE and the model")
    print(f"       missed it. Fix: prompt, context ordering, a stronger model. Retrieval is fine.")
    print(f"  {DIM}{len(quad['ret_fail_honest'])}/{n} honest refusals{RESET} — retrieval missed, model correctly said so.")
    print(f"       {DIM}This is a RETRIEVAL bug and a GENERATION SUCCESS. The escape hatch worked.{RESET}")
    print(f"  {RED}{len(quad['ret_fail_halluc'])}/{n} silent failures{RESET} — retrieval missed AND the model answered anyway.")
    print(f"       {RED}These are the dangerous ones. Nothing in the output says it's wrong.{RESET}")

    for label, key in (("GENERATION failures", "gen_fail"), ("FLAGGED as silent failures", "ret_fail_halluc")):
        if quad[key]:
            print(f"\n{BOLD}{label}{RESET}")
            for r in quad[key][:4]:
                print(f"  {DIM}Q:{RESET} {r['q'][:70]}")
                print(f"  {DIM}A:{RESET} {' '.join(r['out'].split())[:110]}…")

    # ---- VERIFY THE ALARMING CELL -------------------------------------------
    # The 2x2 above is built from SUBSTRING matching, which is cheap, fast, and
    # wrong at the edges: the gold string is "loop detection" and a perfectly
    # correct answer saying "loop detector" scores as a miss. So triage with the
    # cheap check, then spend a real judge call ONLY on the cell that would make
    # you change something.
    if quad["ret_fail_halluc"]:
        print(f"\n{BOLD}VERIFYING the {len(quad['ret_fail_halluc'])} flagged silent failure(s) with a groundedness judge{RESET}")
        print(f"{DIM}substring matching is brittle; before acting on an alarming number, check it{RESET}")

        def verify(r):
            v = ask("You check GROUNDEDNESS. Given a context and a response, decide whether "
                    "every factual claim in the response is supported by the context. "
                    "Answer with JSON only.",
                    f"CONTEXT:\n{r['ctx_block'][:6000]}\n\nRESPONSE:\n{r['out']}",
                    schema={"type": "object",
                            "properties": {"grounded": {"type": "boolean"},
                                           "reason": {"type": "string"}},
                            "required": ["grounded", "reason"]})
            try:
                return json.loads(v)
            except ValueError:
                return {"grounded": None, "reason": "unparseable"}

        checks = parallel(verify, quad["ret_fail_halluc"])
        real = sum(1 for c in checks if c.get("grounded") is False)
        mislabelled = sum(1 for c in checks if c.get("grounded") is True)
        for r, c in zip(quad["ret_fail_halluc"], checks):
            mark = f"{RED}TRUE hallucination{RESET}" if c.get("grounded") is False else \
                   f"{GREEN}grounded — substring check was WRONG{RESET}"
            print(f"  {mark}  {r['q'][:56]}")
            print(f"    {DIM}{c.get('reason','')[:100]}{RESET}")
        print(f"\n  {RED}{real}{RESET} genuine silent failures · "
              f"{GREEN}{mislabelled}{RESET} mislabelled by the substring heuristic")

    print(f"""
{DIM}Two lessons, and the second is the bigger one.

1. The bottom-right cell is a SUCCESS, not a failure, even though the user got no
   answer. A refusal looks bad in a demo and is the correct behaviour. Optimise
   refusals away without fixing retrieval and you convert that cell into the red
   one — which is strictly worse and invisible.

2. YOUR CHEAP METRIC MISLABELS. Substring matching called correct answers
   hallucinations because the gold string said "loop detection" and the model
   wrote "loop detector". If you had reported the raw red-cell count to a
   stakeholder you would have raised a false alarm about hallucination and sent
   the team to fix a problem that does not exist.

   The pattern to keep: CHEAP HEURISTIC TO TRIAGE, EXPENSIVE JUDGE TO CONFIRM,
   and only on the cell whose value would change a decision.{RESET}""")


# =========================================================================== #
# C. JUDGE CALIBRATION
# =========================================================================== #

# Ground truth by CONSTRUCTION: each answer is built to be faithful or to carry a
# specific, known defect. No human labelling needed, and no ambiguity about the
# label — which is exactly what you want when calibrating the instrument.
CONTEXT = """[1] Reranking: a cross-encoder over the top ~50-100 candidates. Retrieve wide,
rerank narrow. This is usually the highest-ROI single upgrade to a mediocre RAG system.

[2] Hybrid search is the baseline, not an optimisation. BM25/sparse for exact terms, IDs,
and rare tokens; dense vectors for paraphrase and concept. Fuse with Reciprocal Rank Fusion.

[3] Vector stores: pgvector (default — you probably already have Postgres), Qdrant, Weaviate,
Milvus, Pinecone, Vespa, Turbopuffer."""

QUESTION = "How should I improve a mediocre RAG system, and what should I use to store vectors?"

CASES = [
    # (answer, is_faithful, defect)
    ("Add a cross-encoder reranker over the top 50-100 candidates — retrieve wide, rerank "
     "narrow [1]. For storage, pgvector is the sensible default [3].", True, "—"),
    ("Use hybrid search with BM25 and dense vectors fused by Reciprocal Rank Fusion [2], and "
     "store vectors in pgvector [3].", True, "—"),
    ("Reranking with a cross-encoder is the highest-ROI single upgrade [1]. pgvector, Qdrant "
     "and Milvus are all listed as options [3].", True, "—"),
    ("Retrieve wide and rerank narrow with a cross-encoder [1]; hybrid search with RRF is the "
     "baseline [2].", True, "—"),
    ("Add a cross-encoder reranker [1] and store vectors in pgvector [3], which benchmarks show "
     "is 3x faster than Pinecone.", False, "unsupported claim (the 3x benchmark)"),
    ("Rerank the top 5-10 candidates with a cross-encoder [1] and use pgvector [3].",
     False, "number changed (50-100 -> 5-10)"),
    ("Hybrid search is an optional optimisation you can skip [2]; just use pgvector [3].",
     False, "contradicts the context (it says baseline, NOT optional)"),
    ("Not in the provided context.", False, "false refusal — the answer IS in the context"),
    ("Use a cross-encoder reranker [1]. For storage you should use Chroma, which is the "
     "industry standard [3].", False, "fabricated entity (Chroma is not listed)"),
    ("Retrieve wide and rerank narrow [1]. Store vectors in pgvector [3]. This will typically "
     "double your recall within two weeks.", False, "unsupported quantitative promise"),
    ("Fuse BM25 and dense retrieval with Reciprocal Rank Fusion [2]; pgvector is the default "
     "choice [3].", True, "—"),
    ("Reranking is usually the highest-ROI upgrade [1], and Turbopuffer is listed among the "
     "vector stores [3].", True, "—"),
]

# TIER 2 — subtle defects. The blatant tier above is a smoke test; a judge that
# fails it is unusable. THIS tier is where judges actually differ, and where an
# unreliable judge quietly passes bad output in production.
HARD_CASES = [
    ("Add a cross-encoder reranker over the top 50-100 candidates [2], and store vectors in "
     "pgvector [3].", False, "MIS-CITATION: claim is true and supported, but cites [2] not [1]"),
    ("Reranking is the highest-ROI upgrade [1]. pgvector is the default, and it is probably "
     "sufficient for most teams [3].", False,
     "HEDGED EXTRAPOLATION: 'probably sufficient for most teams' is not in the context"),
    ("Use a cross-encoder reranker [1] and store vectors in pgvector [3], which is open "
     "source.", False, "TRUE-IN-THE-WORLD but not in the context (pgvector's licence)"),
    ("Hybrid search fusing BM25 and dense vectors is the baseline [2]; pgvector is the "
     "suggested default [3].", True, "— (paraphrases without adding anything)"),
    ("Retrieve wide and rerank narrow with a cross-encoder [1]. Among the listed stores, "
     "Qdrant is the best choice [3].", False,
     "UNSUPPORTED RANKING: context lists Qdrant but never calls it best"),
    ("Reranking a shortlist with a cross-encoder is the single highest-ROI upgrade to a "
     "mediocre RAG system [1]; pgvector is the default vector store [3].", True,
     "— (near-verbatim, correctly cited)"),
]

JUDGE_SYS = """You are a strict evaluator of GROUNDEDNESS (faithfulness).

A response is FAITHFUL only if every factual claim it makes is supported by the
provided context passages. Judge ONLY groundedness — not style, length, or helpfulness.

Mark it UNFAITHFUL if it: adds facts not in the context, changes a number, contradicts
the context, invents an entity, makes an unsupported quantitative promise, OR refuses
when the context actually does contain the answer.

Before scoring, quote the specific span you are relying on. Then decide."""

JUDGE_SCHEMA = {
    "type": "object",
    "properties": {
        "evidence": {"type": "string", "description": "the span you relied on"},
        "faithful": {"type": "boolean"},
        "reason": {"type": "string"},
    },
    "required": ["evidence", "faithful", "reason"],
}


def cohens_kappa(a: list[bool], b: list[bool]) -> float:
    """Agreement corrected for agreement-by-chance.

    Raw accuracy flatters a judge on an unbalanced set: label everything
    "faithful" on a set that is 80% faithful and you score 80% while having
    learned nothing. Kappa subtracts the agreement you'd get by guessing with the
    same marginal rates.

        kappa = (p_observed - p_chance) / (1 - p_chance)

    Rough reading: <0.2 poor · 0.2-0.4 fair · 0.4-0.6 moderate ·
                   0.6-0.8 substantial · >0.8 near-perfect
    """
    n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    pa1, pb1 = sum(a) / n, sum(b) / n
    pe = pa1 * pb1 + (1 - pa1) * (1 - pb1)
    return (po - pe) / (1 - pe) if pe < 1 else 1.0


def cmd_judge(_a) -> None:
    rule("C. JUDGE CALIBRATION — is your measuring device any good?")
    print(f"""{DIM}Ground truth here is known BY CONSTRUCTION: each answer was written to be
faithful, or to carry one specific defect. No human labelling, no ambiguity.
That is the right way to smoke-test a judge before you trust it on real data.{RESET}""")

    def one(case):
        ans, _truth, _defect = case
        raw = ask(JUDGE_SYS,
                  f"CONTEXT:\n{CONTEXT}\n\nQUESTION: {QUESTION}\n\nRESPONSE TO JUDGE:\n{ans}",
                  schema=JUDGE_SCHEMA)
        try:
            return json.loads(raw)
        except ValueError:
            return {"faithful": None, "evidence": "", "reason": f"unparseable: {raw[:80]}"}

    def run_tier(cases, name):
        print(f"\n{BOLD}{name}{RESET}  {DIM}({len(cases)} responses){RESET}")
        verdicts = parallel(one, cases)
        truth = [c[1] for c in cases]
        pred = [bool(v.get("faithful")) for v in verdicts]
        print(f"  {'truth':>9} {'judge':>9}  {'defect injected':<58}")
        print(f"  {DIM}{'-'*9} {'-'*9}  {'-'*58}{RESET}")
        for case, p, v in zip(cases, pred, verdicts):
            mark = GREEN if case[1] == p else RED
            print(f"  {str(case[1]):>9} {mark}{str(p):>9}{RESET}  {DIM}{case[2][:58]}{RESET}")
        acc = sum(t == p for t, p in zip(truth, pred)) / len(truth)
        k = cohens_kappa(truth, pred)
        fn = [i for i, (t, p) in enumerate(zip(truth, pred)) if not t and p]
        fp = [i for i, (t, p) in enumerate(zip(truth, pred)) if t and not p]
        kcol = GREEN if k > 0.6 else (YELLOW if k > 0.4 else RED)
        print(f"  accuracy {acc:.0%} · kappa {kcol}{k:.3f}{RESET} · "
              f"missed defects {RED}{len(fn)}{RESET} · false alarms {YELLOW}{len(fp)}{RESET}")
        if fn:
            print(f"  {RED}NOT caught:{RESET}")
            for i in fn:
                print(f"    · {cases[i][2]}")
                print(f"      {DIM}judge: {verdicts[i].get('reason','')[:96]}{RESET}")
        if fp:
            print(f"  {YELLOW}False alarms:{RESET}")
            for i in fp:
                print(f"    · {cases[i][2]}")
                print(f"      {DIM}judge: {verdicts[i].get('reason','')[:96]}{RESET}")
        return acc, k, len(fn)

    t0 = time.perf_counter()
    a1, k1, fn1 = run_tier(CASES, "TIER 1 — blatant defects (a smoke test)")
    a2, k2, fn2 = run_tier(HARD_CASES, "TIER 2 — subtle defects (where judges actually differ)")
    print(f"\n{DIM}{time.perf_counter()-t0:.0f}s total{RESET}")

    print(f"""
{BOLD}The two tiers exist because a single number hides where a judge breaks{RESET}
  tier 1 (blatant) accuracy {a1:.0%} · kappa {k1:.3f} · missed {fn1}
  tier 2 (subtle)  accuracy {a2:.0%} · kappa {k2:.3f} · missed {fn2}
{DIM}A judge that aces tier 1 is merely USABLE. Tier 2 is the one that predicts
whether it will catch the failures you actually ship: mis-citations, hedged
extrapolation, and claims that are true in the world but absent from the context.
Report both, and build your tier 2 from the disagreements you find in production.{RESET}""")

    print(f"""
{DIM}Why kappa and not accuracy: this set is 50/50, so they nearly agree. On a
realistic set that is 90% faithful, a judge that says "faithful" every single
time scores 90% accuracy and has kappa 0.0 — it has learned nothing and will
never flag a real failure. ALWAYS report kappa.

Q10 from your diagnostic — "your judge agrees with human labels 60% of the time,
what now?" — the answer is NOT "use a better model". It is:
  1. compute kappa; 60% raw agreement on an unbalanced set may be kappa ~0
  2. read the DISAGREEMENTS — they are usually a rubric ambiguity, not model error
  3. make the rubric concrete and require evidence BEFORE the verdict (as above)
  4. split the task: judging groundedness and helpfulness at once causes blending
  5. only then consider a stronger judge model — and never the model under test{RESET}""")


# =========================================================================== #
# D. JUDGE BIASES
# =========================================================================== #

PAIR_SYS = """Compare two answers to the same question and pick the better one.
Judge accuracy and usefulness. Reply with a JSON verdict only."""

PAIR_SCHEMA = {"type": "object",
               "properties": {"winner": {"type": "string", "enum": ["A", "B", "tie"]},
                              "why": {"type": "string"}},
               "required": ["winner", "why"]}

GOOD = ("Add a cross-encoder reranker over the top 50-100 candidates: retrieve wide, "
        "rerank narrow. It is the highest-ROI single upgrade. Store vectors in pgvector.")
WEAK = ("You could try improving your retrieval somehow, and pick whichever vector "
        "database seems popular.")

# Two answers of comparable quality — both correct, different emphasis. This is
# where position bias actually shows, because the judge has no strong basis to
# prefer either and any systematic tilt is the bias itself.
CLOSE_A = ("Add a cross-encoder reranker over the top 50-100 candidates — retrieve wide, "
           "rerank narrow. It is the highest-ROI single upgrade. Use pgvector for storage.")
CLOSE_B = ("Use hybrid search: BM25 for exact terms and dense vectors for paraphrase, fused "
           "with Reciprocal Rank Fusion. It is the baseline, not an optimisation. Store "
           "vectors in pgvector.")

PAD = (" It is worth emphasising that this recommendation reflects widely-held best "
       "practice in the field. Many practitioners have found this approach valuable "
       "across a variety of settings and workloads. Careful consideration of your own "
       "requirements remains important, and results may vary depending on context, "
       "corpus characteristics, and the specific demands of your application.")


def judge_pair(a: str, b: str) -> str:
    raw = ask(PAIR_SYS, f"QUESTION: {QUESTION}\n\nANSWER A:\n{a}\n\nANSWER B:\n{b}",
              schema=PAIR_SCHEMA)
    try:
        return json.loads(raw).get("winner", "?")
    except ValueError:
        return "?"


def cmd_bias(_a) -> None:
    rule("D. JUDGE BIASES — measured, not asserted")
    N = 6

    print(f"\n{BOLD}1. POSITION BIAS{RESET}")
    print(f"{DIM}Same two answers, presented in both orders, {N} trials each. A judge with no")
    print(f"position bias picks the SAME answer regardless of slot.{RESET}")
    fwd = parallel(lambda _: judge_pair(GOOD, WEAK), list(range(N)))
    rev = parallel(lambda _: judge_pair(WEAK, GOOD), list(range(N)))
    good_fwd = sum(w == "A" for w in fwd)          # good was in slot A
    good_rev = sum(w == "B" for w in rev)          # good was in slot B
    consistent = good_fwd + good_rev
    print(f"  good answer in slot A → picked {good_fwd}/{N}")
    print(f"  good answer in slot B → picked {good_rev}/{N}")
    col = GREEN if consistent >= 2 * N - 1 else (YELLOW if consistent >= 1.5 * N else RED)
    print(f"  {col}consistent {consistent}/{2*N}{RESET}"
          f"{'' if consistent >= 2*N-1 else '  ← position affected the verdict'}")

    print(f"\n{BOLD}1b. POSITION BIAS ON A CLOSE CALL{RESET}")
    print(f"{DIM}The test above used a strong answer against an obviously weak one — the EASY")
    print(f"case. Bias surfaces when the two are near-equivalent and the judge has no real")
    print(f"basis to choose. Two correct answers, different emphasis, both orders.{RESET}")
    fwd2 = parallel(lambda _: judge_pair(CLOSE_A, CLOSE_B), list(range(N)))
    rev2 = parallel(lambda _: judge_pair(CLOSE_B, CLOSE_A), list(range(N)))
    a_first = sum(w == "A" for w in fwd2)      # CLOSE_A in slot A
    a_second = sum(w == "B" for w in rev2)     # CLOSE_A in slot B
    slot_a_wins = sum(w == "A" for w in fwd2) + sum(w == "A" for w in rev2)
    ties2 = sum(w == "tie" for w in fwd2 + rev2)
    decisive = 2 * N - ties2
    print(f"  answer A picked when it was in slot A → {a_first}/{N}")
    print(f"  answer A picked when it was in slot B → {a_second}/{N}")
    print(f"  ties {ties2}/{2*N} · decisive verdicts {decisive}/{2*N} "
          f"(slot-A wins {slot_a_wins})")
    if ties2 >= 1.5 * N:
        print(f"  {GREEN}NO POSITION BIAS DETECTABLE — the judge mostly declared a tie{RESET}")
        print(f"  {DIM}That is the correct response to two equally good answers, and it also")
        print(f"  means this test cannot measure position bias: there are too few decisive")
        print(f"  verdicts to tilt. A judge FORCED to choose (no tie option) is the harsher")
        print(f"  test, and is what most eval harnesses actually do.{RESET}")
    else:
        tilt = abs(slot_a_wins - decisive / 2) / max(1, decisive)
        col2 = RED if tilt > 0.25 else GREEN
        print(f"  {col2}slot-A share of decisive verdicts: {slot_a_wins}/{decisive}{RESET} "
              f"{DIM}(50% = unbiased; a large tilt IS the position bias){RESET}")

    print(f"\n{BOLD}2. VERBOSITY BIAS{RESET}")
    print(f"{DIM}Same correct answer vs. itself + {len(PAD)} chars of confident filler that adds")
    print(f"NO information. A judge scoring content should call this a tie.{RESET}")
    verb = parallel(lambda _: judge_pair(GOOD, GOOD + PAD), list(range(N)))
    padded_wins = sum(w == "B" for w in verb)
    ties = sum(w == "tie" for w in verb)
    col = GREEN if padded_wins == 0 else (YELLOW if padded_wins <= N // 3 else RED)
    print(f"  padded answer won {col}{padded_wins}/{N}{RESET} · tie {ties}/{N} · "
          f"concise won {N - padded_wins - ties}/{N}")
    if padded_wins:
        print(f"  {RED}verbosity bias present — length bought score with zero added information{RESET}")

    print(f"""
{DIM}The four biases to know cold:
  POSITION      order changes the verdict → always run both orders and average
  VERBOSITY     longer looks better → control length, or judge on a rubric
  SELF-PREFERENCE  a model prefers its own outputs → never judge with the model
                   under test
  LENIENCY DRIFT  scores creep upward over a long run → shuffle, batch, re-baseline
                  periodically against a fixed anchor set

Mitigations that actually work: pairwise instead of 1-5 scoring; a concrete
rubric; require evidence BEFORE the verdict; randomise order and average; a
different (usually stronger) model as judge than the one under test.{RESET}""")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for c in ("metrics", "failures", "judge", "bias"):
        sub.add_parser(c)
    a = p.parse_args()
    {"metrics": cmd_metrics, "failures": cmd_failures,
     "judge": cmd_judge, "bias": cmd_bias}[a.cmd](a)


if __name__ == "__main__":
    main()
