"""Generate real data for visuals/05-evaluation.html.

    python 05_make_viz_data.py  ->  ../visuals/05-viz-data.js

Retrieval metrics are recomputed. Judge/bias/failure numbers are pasted from
measured runs (they cost ~60 LLM calls) and are marked as such below.
"""

from __future__ import annotations

import importlib.util
import json
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE.parent / "visuals" / "05-viz-data.js"

spec4 = importlib.util.spec_from_file_location("lab4", HERE / "04_retrieval.py")
lab4 = importlib.util.module_from_spec(spec4)
spec4.loader.exec_module(lab4)
spec5 = importlib.util.spec_from_file_location("lab5", HERE / "05_evaluation.py")
lab5 = importlib.util.module_from_spec(spec5)
spec5.loader.exec_module(lab5)


def main() -> None:
    text = lab4.CORPUS.read_text(encoding="utf-8")
    lab4.check_gold(text)
    idx = lab4.Index(lab4.chunk_recursive(text))

    KS = (1, 2, 3, 5, 8, 10, 15, 20)
    pipes = []
    for key, (label, fn) in lab4.PIPELINES.items():
        m = lab5.retrieval_metrics(idx, fn, ks=KS)
        pipes.append({
            "key": key, "label": label.strip(),
            "recall": {str(k): m["recall"][k] for k in KS},
            "precision": {str(k): m["precision"][k] for k in KS},
            "ndcg": {str(k): m["ndcg"][k] for k in KS},
            "p_ceiling": {str(k): m["p_ceiling"][k] for k in KS},
            "mrr": m["mrr"],
            "gap": m["recall"][10] - m["recall"][1],
        })
        print(f"  {label.strip():<26} R@1 {m['recall'][1]:.2f} R@10 {m['recall'][10]:.2f} "
              f"gap {pipes[-1]['gap']:.2f}")

    any_m = pipes[0]
    data = {
        "meta": {"gold": len(lab4.GOLD), "chunks": len(idx.chunks),
                 "ks": list(KS),
                 "rel_dist": lab5.retrieval_metrics(idx, lab4.p_dense, ks=(5,))["rel_dist"]},
        "pipelines": pipes,
        # --- measured: python 05_evaluation.py failures (16 questions, dense retriever)
        "failure_2x2": {"ok": 8, "gen_fail": 4, "ret_fail_halluc": 2, "ret_fail_honest": 2,
                        "n": 16,
                        "verified_true_halluc": 0, "verified_mislabelled": 2,
                        "examples": {
                            "gen_fail": ["HNSW", "IVFFlat", "What is HyDE?", "QLoRA"],
                            "flagged": ["How do I keep my agent from running in circles forever?",
                                        "What should I do when the model makes things up confidently?"]}},
        # --- measured: python 05_evaluation.py judge
        "judge": {
            "tier1": {"n": 12, "accuracy": 1.00, "kappa": 1.000, "missed": 0, "false_alarms": 0},
            "tier2": {"n": 6, "accuracy": 0.83, "kappa": 0.667, "missed": 1, "false_alarms": 0,
                      "missed_defect": "MIS-CITATION: claim is true and supported, but cites [2] not [1]"},
            "tier1_defects": [c[2] for c in lab5.CASES],
            "tier2_defects": [c[2] for c in lab5.HARD_CASES],
        },
        # --- measured: python 05_evaluation.py bias
        "bias": {"position_obvious": {"trials": 12, "consistent": 12},
                 "position_close": {"trials": 12, "ties": 8, "decisive": 4, "slot_a_wins": 2},
                 "verbosity": {"trials": 6, "padded_wins": 0, "ties": 0, "concise_wins": 6,
                               "pad_chars": 374}},
    }
    OUT.write_text("window.VIZ5 = " + json.dumps(data) + ";\n", encoding="utf-8")
    print(f"\nwrote {OUT} ({OUT.stat().st_size/1024:.0f} KiB)")


if __name__ == "__main__":
    main()
