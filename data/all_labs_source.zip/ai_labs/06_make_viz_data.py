"""Generate real data for visuals/06-production-rag.html.

    python 06_make_viz_data.py  ->  ../visuals/06-viz-data.js

ACL numbers are recomputed (local, free). Citation / groundedness / long-context
numbers are pasted from measured runs and marked below.
"""

from __future__ import annotations

import importlib.util
import json
import pathlib

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE.parent / "visuals" / "06-viz-data.js"

spec = importlib.util.spec_from_file_location("lab6", HERE / "06_production_rag.py")
lab6 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab6)


def main() -> None:
    idx = lab6.AclIndex()
    K = 4
    users = list(lab6.USERS.items())

    rows = []
    for q, owner in lab6.QUERIES:
        top = idx.rank_all(q)[:K]
        per_user = []
        for user, allowed in users:
            kept = [i for i in top if idx.docs[i][1] in allowed]
            pre = idx.rank_prefiltered(q, allowed)[:K]
            per_user.append({
                "user": user.strip(),
                "allowed": sorted(allowed),
                "post_kept": len(kept),
                "post_answerable": any(idx.docs[i][1] == owner for i in kept),
                "pre_kept": len(pre),
                "pre_answerable": any(idx.docs[i][1] == owner for i in pre),
            })
        counts = [u["post_kept"] for u in per_user]
        rows.append({"q": q, "owner": owner, "users": per_user,
                     "leak": len(set(counts)) > 1,
                     "inferable": max(counts) - min(counts)})
        print(f"  {q[:44]:<44} post {counts} leak={rows[-1]['leak']}")

    data = {
        "meta": {"docs": len(lab6.DOCS), "k": K,
                 "depts": sorted({d[1] for d in lab6.DOCS})},
        "docs": [{"id": d[0], "dept": d[1], "text": d[2]} for d in lab6.DOCS],
        "users": [{"user": u.strip(), "allowed": sorted(a)} for u, a in users],
        "acl": rows,
        # --- measured: python 06_production_rag.py acl (section 4)
        "leak_demo": {
            "user": "alice (engineering only)",
            "question": "What is Sarah Chen's salary?",
            "answer": "Sarah Chen's base salary is $215,000 USD [1].",
            "leaked": True,
        },
        # --- measured: python 06_production_rag.py cite (12 answers)
        "citations": {"n": 12, "clean": 7, "dangling": 0, "uncited": 3, "weak": 4,
                      "example": {"overlap": 0.28, "cites": [2],
                                  "claim": "IVFFlat is one of the vector index types discussed alongside HNSW and flat indexes…",
                                  "cited": "### 4.2 Retrieval - Hybrid search is the baseline, not an optimization. BM25/sparse for exact te…"}},
        # --- measured: python 06_production_rag.py ground
        "ground": [
            {"q": "What is the roadmap's advice on reranking?", "in_corpus": True, "refused": False, "grounded": True},
            {"q": "What is the current price of Bitcoin?", "in_corpus": False, "refused": True, "grounded": True},
            {"q": "How many employees does OpenAI have?", "in_corpus": False, "refused": True, "grounded": True},
            {"q": "What does the roadmap say about evaluation?", "in_corpus": True, "refused": False, "grounded": True},
        ],
        # --- measured: python 06_production_rag.py longctx (8 questions)
        "longctx": {"corpus_chars": 30116, "price_in_per_mtok": 3.00,
                    "rag": {"acc": 1.00, "tok": 1672, "lat": 4.2},
                    "full": {"acc": 1.00, "tok": 11212, "lat": 4.8}},
    }
    OUT.write_text("window.VIZ6 = " + json.dumps(data) + ";\n", encoding="utf-8")
    print(f"\nwrote {OUT} ({OUT.stat().st_size/1024:.0f} KiB)")


if __name__ == "__main__":
    main()
