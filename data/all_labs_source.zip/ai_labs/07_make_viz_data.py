"""Generate data for visuals/07-context-engineering.html.

All numbers below are pasted from measured runs of 07_context_engineering.py
(each section costs 30-150 LLM calls, so they are not recomputed here).
Re-run the lab and update this file if you change the experiments.
"""
import json, pathlib
OUT = pathlib.Path(__file__).resolve().parent.parent / "visuals" / "07-viz-data.js"

data = {
  "variants": {
    "cap_chars": 300, "questions": 14, "repeats": 2, "noise": 0.14,
    "rows": [
      {"name": "V1 minimal", "sys": 38, "raw": 0.89, "capped": 0.79, "lo": 0.71, "hi": 0.86, "cite": 0.43, "out_tok": 466},
      {"name": "V2 role+task", "sys": 154, "raw": 0.82, "capped": 0.75, "lo": 0.71, "hi": 0.79, "cite": 0.43, "out_tok": 630},
      {"name": "V3 structured", "sys": 291, "raw": 0.71, "capped": 0.68, "lo": 0.64, "hi": 0.71, "cite": 0.93, "out_tok": 98},
      {"name": "V4 structured+examples", "sys": 528, "raw": 0.71, "capped": 0.68, "lo": 0.64, "hi": 0.71, "cite": 0.86, "out_tok": 86},
      {"name": "V5 kitchen sink", "sys": 636, "raw": 0.82, "capped": 0.75, "lo": 0.71, "hi": 0.79, "cite": 1.00, "out_tok": 202}]},
  "hatch": {"n": 6,
    "with": {"declined": 1.00, "exact": 1.00},
    "without": {"declined": 1.00, "exact": 0.00},
    "phrasings": ["This question isn't addressed in the provided context passages",
                  "The context does not specify a particular Postgres version",
                  "I don't have real-time data access, so I can't provide..."],
    "first_matcher_score": 0.50},
  "structured": {"n": 8,
    "prose": {"parsed": 2, "keys": 2, "enums": 2},
    "schema": {"parsed": 8, "keys": 8, "enums": 8},
    "failure": "JSONDecodeError — ```json\\n{\"technique\": \"Prompt injection\", ..."},
  "order": {"distractors": 14, "questions": 10,
    "points": [{"pos": 0, "acc": 0.60, "note": "first — primacy edge"},
               {"pos": 3, "acc": 0.50, "note": "middle"},
               {"pos": 7, "acc": 0.80, "note": "middle"},
               {"pos": 11, "acc": 0.70, "note": "middle"},
               {"pos": 14, "acc": 0.80, "note": "last — recency edge"}],
    "edges": 0.70, "middle": 0.67},
  "memory": [
    {"strategy": "full history", "chars": 582, "tok": 431, "kept": 3, "of": 3},
    {"strategy": "sliding window (4)", "chars": 221, "tok": 291, "kept": 0, "of": 3},
    {"strategy": "running summary", "chars": 346, "tok": 344, "kept": 3, "of": 3},
    {"strategy": "no history", "chars": 0, "tok": 197, "kept": 0, "of": 3}],
  "budget": [{"slice": "system / instructions", "lo": 5, "hi": 15, "note": "stable → first → cacheable"},
             {"slice": "retrieved context", "lo": 40, "hi": 60, "note": "the RAG tax"},
             {"slice": "conversation history", "lo": 10, "hi": 30, "note": "grows without bound if unmanaged"},
             {"slice": "output reserve", "lo": 10, "hi": 20, "note": "reserved, not discovered"}],
}
OUT.write_text("window.VIZ7 = " + json.dumps(data) + ";\n", encoding="utf-8")
print(f"wrote {OUT} ({OUT.stat().st_size/1024:.0f} KiB)")
