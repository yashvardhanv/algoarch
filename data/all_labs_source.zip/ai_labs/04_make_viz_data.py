"""Generate real data for visuals/04-retrieval.html.

    python 04_make_viz_data.py  ->  ../visuals/04-viz-data.js

HyDE numbers are pasted from a measured run rather than recomputed, because that
section costs 14 LLM calls (~84s). Everything else is recomputed here.
"""

from __future__ import annotations

import importlib.util
import json
import pathlib

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE.parent / "visuals" / "04-viz-data.js"

spec = importlib.util.spec_from_file_location("lab4", HERE / "04_retrieval.py")
lab4 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab4)


def main() -> None:
    text = lab4.CORPUS.read_text(encoding="utf-8")
    lab4.check_gold(text)
    chunks = lab4.chunk_recursive(text)
    idx = lab4.Index(chunks)

    ladder, per_q = [], {}
    for key, (label, fn) in lab4.PIPELINES.items():
        m = lab4.eval_pipeline(idx, fn)
        ladder.append({"key": key, "label": label.strip(), "recall": m["recall"],
                       "mrr": m["mrr"], "p50_ms": m["p50_ms"], "by_tag": m["by_tag"]})
        per_q[key] = [{"found": r["found"], "rank": r["rank"]} for r in m["per_q"]]
        print(f"  {label:<28} recall {m['recall']:.2f}  mrr {m['mrr']:.3f}  {m['p50_ms']:.0f}ms")

    # RRF worked example
    q = "What is RRF?"
    dsc, ssc = idx.dense(q), idx.sparse(q)
    d = [int(x) for x in np.argsort(-dsc)[:8]]
    s = [int(x) for x in np.argsort(-ssc)[:8]]
    fused = lab4.rrf([d, s])[:8]
    rrf_demo = {
        "query": q,
        "dense_range": [float(dsc.min()), float(dsc.max())],
        "bm25_range": [float(ssc.min()), float(ssc.max())],
        "rows": [{
            "chunk": c,
            "dense_rank": (d.index(c) + 1) if c in d else None,
            "bm25_rank": (s.index(c) + 1) if c in s else None,
            "score": sum(1 / (60 + r) for r in
                         [(d.index(c) + 1) if c in d else None,
                          (s.index(c) + 1) if c in s else None] if r),
            "preview": " ".join(idx.texts[c].split())[:70],
        } for c in fused],
    }

    # ANN curve
    from sklearn.cluster import KMeans
    V, n = idx.vecs, len(chunks)
    nlist = max(4, int(np.sqrt(n)))
    km = KMeans(n_clusters=nlist, n_init=10, random_state=0).fit(V)
    Q = lab4.embed([g[0] for g in lab4.GOLD])
    exact = [set(np.argsort(-(V @ Q[i]))[:10].tolist()) for i in range(len(lab4.GOLD))]
    ann = []
    for nprobe in range(1, nlist + 1):
        hits, scanned = 0, 0
        for i in range(len(lab4.GOLD)):
            dists = np.linalg.norm(km.cluster_centers_ - Q[i], axis=1)
            lists = np.argsort(dists)[:nprobe]
            cand = np.where(np.isin(km.labels_, lists))[0]
            scanned += len(cand)
            sub = cand[np.argsort(-(V[cand] @ Q[i]))[:10]]
            hits += len(set(sub.tolist()) & exact[i])
        avg = scanned / len(lab4.GOLD)
        ann.append({"nprobe": nprobe, "scanned": avg, "speedup": n / max(1, avg),
                    "recall": hits / (10 * len(lab4.GOLD))})
    print(f"  ANN: nprobe 1 -> recall {ann[0]['recall']:.0%}, {ann[0]['speedup']:.1f}x")

    data = {
        "meta": {"corpus": lab4.CORPUS.name, "chunks": n, "gold": len(lab4.GOLD),
                 "budget": lab4.BUDGET, "point_value": 100 / len(lab4.GOLD),
                 "nlist": nlist},
        "gold": [{"q": q, "tag": t, "answer": a} for q, t, a in lab4.GOLD],
        "ladder": ladder,
        "per_q": per_q,
        "rrf_demo": rrf_demo,
        "ann": ann,
        # measured by `python 04_retrieval.py hyde` — 14 para/multi questions
        "hyde": {"n": 14, "gen_s_per_query": 6.0, "total_s": 84.0,
                 "baseline": {"recall": 0.71, "mrr": 0.502},
                 "hyde": {"recall": 0.86, "mrr": 0.658}},
    }
    OUT.write_text("window.VIZ4 = " + json.dumps(data) + ";\n", encoding="utf-8")
    print(f"\nwrote {OUT} ({OUT.stat().st_size/1024:.0f} KiB)")


if __name__ == "__main__":
    main()
